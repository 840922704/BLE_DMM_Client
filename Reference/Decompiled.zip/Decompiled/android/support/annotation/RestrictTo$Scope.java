package android.support.annotation;

public enum Scope {
  GROUP_ID, LIBRARY, LIBRARY_GROUP, SUBCLASSES, TESTS;
  
  static {
    GROUP_ID = new Scope("GROUP_ID", 2);
    TESTS = new Scope("TESTS", 3);
    SUBCLASSES = new Scope("SUBCLASSES", 4);
    $VALUES = new Scope[] { LIBRARY, LIBRARY_GROUP, GROUP_ID, TESTS, SUBCLASSES };
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\annotation\RestrictTo$Scope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */