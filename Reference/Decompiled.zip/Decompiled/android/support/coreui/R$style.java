package android.support.coreui;

public final class style {
  public static final int TextAppearance_Compat_Notification = 2131755290;
  
  public static final int TextAppearance_Compat_Notification_Info = 2131755291;
  
  public static final int TextAppearance_Compat_Notification_Line2 = 2131755292;
  
  public static final int TextAppearance_Compat_Notification_Time = 2131755293;
  
  public static final int TextAppearance_Compat_Notification_Title = 2131755294;
  
  public static final int Widget_Compat_NotificationActionContainer = 2131755460;
  
  public static final int Widget_Compat_NotificationActionText = 2131755461;
  
  public static final int Widget_Support_CoordinatorLayout = 2131755508;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreui\R$style.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */