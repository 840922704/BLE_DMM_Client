package android.support.coreui;

public final class string {
  public static final int status_bar_notification_info_overflow = 2131689760;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreui\R$string.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */