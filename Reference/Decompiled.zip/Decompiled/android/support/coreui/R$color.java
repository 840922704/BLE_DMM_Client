package android.support.coreui;

public final class color {
  public static final int notification_action_color_filter = 2131034242;
  
  public static final int notification_icon_bg_color = 2131034243;
  
  public static final int ripple_material_light = 2131034255;
  
  public static final int secondary_text_default_material_light = 2131034257;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreui\R$color.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */