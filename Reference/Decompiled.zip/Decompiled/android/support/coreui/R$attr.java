package android.support.coreui;

public final class attr {
  public static final int alpha = 2130903079;
  
  public static final int coordinatorLayoutStyle = 2130903210;
  
  public static final int font = 2130903263;
  
  public static final int fontProviderAuthority = 2130903265;
  
  public static final int fontProviderCerts = 2130903266;
  
  public static final int fontProviderFetchStrategy = 2130903267;
  
  public static final int fontProviderFetchTimeout = 2130903268;
  
  public static final int fontProviderPackage = 2130903269;
  
  public static final int fontProviderQuery = 2130903270;
  
  public static final int fontStyle = 2130903271;
  
  public static final int fontVariationSettings = 2130903272;
  
  public static final int fontWeight = 2130903273;
  
  public static final int keylines = 2130903319;
  
  public static final int layout_anchor = 2130903324;
  
  public static final int layout_anchorGravity = 2130903325;
  
  public static final int layout_behavior = 2130903326;
  
  public static final int layout_dodgeInsetEdges = 2130903370;
  
  public static final int layout_insetEdge = 2130903379;
  
  public static final int layout_keyline = 2130903380;
  
  public static final int statusBarBackground = 2130903545;
  
  public static final int ttcIndex = 2130903645;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreui\R$attr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */