package android.support.constraint;

public final class styleable {
  public static final int[] ConstraintLayout_Layout = new int[] { 
      16842948, 16843039, 16843040, 16843071, 16843072, 2130903095, 2130903096, 2130903138, 2130903193, 2130903194, 
      2130903329, 2130903330, 2130903331, 2130903332, 2130903333, 2130903334, 2130903335, 2130903336, 2130903337, 2130903338, 
      2130903339, 2130903340, 2130903341, 2130903342, 2130903343, 2130903344, 2130903345, 2130903346, 2130903347, 2130903348, 
      2130903349, 2130903350, 2130903351, 2130903352, 2130903353, 2130903354, 2130903355, 2130903356, 2130903357, 2130903358, 
      2130903359, 2130903360, 2130903361, 2130903362, 2130903363, 2130903364, 2130903365, 2130903366, 2130903367, 2130903368, 
      2130903369, 2130903371, 2130903372, 2130903373, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378, 2130903381 };
  
  public static final int ConstraintLayout_Layout_android_maxHeight = 2;
  
  public static final int ConstraintLayout_Layout_android_maxWidth = 1;
  
  public static final int ConstraintLayout_Layout_android_minHeight = 4;
  
  public static final int ConstraintLayout_Layout_android_minWidth = 3;
  
  public static final int ConstraintLayout_Layout_android_orientation = 0;
  
  public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
  
  public static final int ConstraintLayout_Layout_barrierDirection = 6;
  
  public static final int ConstraintLayout_Layout_chainUseRtl = 7;
  
  public static final int ConstraintLayout_Layout_constraintSet = 8;
  
  public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
  
  public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
  
  public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
  
  public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
  
  public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
  
  public static final int[] ConstraintLayout_placeholder = new int[] { 2130903195, 2130903236 };
  
  public static final int ConstraintLayout_placeholder_content = 0;
  
  public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
  
  public static final int[] ConstraintSet = new int[] { 
      16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
      16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
      16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903095, 2130903096, 2130903138, 
      2130903194, 2130903329, 2130903330, 2130903331, 2130903332, 2130903333, 2130903334, 2130903335, 2130903336, 2130903337, 
      2130903338, 2130903339, 2130903340, 2130903341, 2130903342, 2130903343, 2130903344, 2130903345, 2130903346, 2130903347, 
      2130903348, 2130903349, 2130903350, 2130903351, 2130903352, 2130903353, 2130903354, 2130903355, 2130903356, 2130903357, 
      2130903358, 2130903359, 2130903360, 2130903361, 2130903362, 2130903363, 2130903364, 2130903365, 2130903366, 2130903367, 
      2130903368, 2130903369, 2130903371, 2130903372, 2130903373, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378 };
  
  public static final int ConstraintSet_android_alpha = 13;
  
  public static final int ConstraintSet_android_elevation = 26;
  
  public static final int ConstraintSet_android_id = 1;
  
  public static final int ConstraintSet_android_layout_height = 4;
  
  public static final int ConstraintSet_android_layout_marginBottom = 8;
  
  public static final int ConstraintSet_android_layout_marginEnd = 24;
  
  public static final int ConstraintSet_android_layout_marginLeft = 5;
  
  public static final int ConstraintSet_android_layout_marginRight = 7;
  
  public static final int ConstraintSet_android_layout_marginStart = 23;
  
  public static final int ConstraintSet_android_layout_marginTop = 6;
  
  public static final int ConstraintSet_android_layout_width = 3;
  
  public static final int ConstraintSet_android_maxHeight = 10;
  
  public static final int ConstraintSet_android_maxWidth = 9;
  
  public static final int ConstraintSet_android_minHeight = 12;
  
  public static final int ConstraintSet_android_minWidth = 11;
  
  public static final int ConstraintSet_android_orientation = 0;
  
  public static final int ConstraintSet_android_rotation = 20;
  
  public static final int ConstraintSet_android_rotationX = 21;
  
  public static final int ConstraintSet_android_rotationY = 22;
  
  public static final int ConstraintSet_android_scaleX = 18;
  
  public static final int ConstraintSet_android_scaleY = 19;
  
  public static final int ConstraintSet_android_transformPivotX = 14;
  
  public static final int ConstraintSet_android_transformPivotY = 15;
  
  public static final int ConstraintSet_android_translationX = 16;
  
  public static final int ConstraintSet_android_translationY = 17;
  
  public static final int ConstraintSet_android_translationZ = 25;
  
  public static final int ConstraintSet_android_visibility = 2;
  
  public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
  
  public static final int ConstraintSet_barrierDirection = 28;
  
  public static final int ConstraintSet_chainUseRtl = 29;
  
  public static final int ConstraintSet_constraint_referenced_ids = 30;
  
  public static final int ConstraintSet_layout_constrainedHeight = 31;
  
  public static final int ConstraintSet_layout_constrainedWidth = 32;
  
  public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
  
  public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
  
  public static final int ConstraintSet_layout_constraintBottom_creator = 35;
  
  public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
  
  public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
  
  public static final int ConstraintSet_layout_constraintCircle = 38;
  
  public static final int ConstraintSet_layout_constraintCircleAngle = 39;
  
  public static final int ConstraintSet_layout_constraintCircleRadius = 40;
  
  public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
  
  public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
  
  public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
  
  public static final int ConstraintSet_layout_constraintGuide_begin = 44;
  
  public static final int ConstraintSet_layout_constraintGuide_end = 45;
  
  public static final int ConstraintSet_layout_constraintGuide_percent = 46;
  
  public static final int ConstraintSet_layout_constraintHeight_default = 47;
  
  public static final int ConstraintSet_layout_constraintHeight_max = 48;
  
  public static final int ConstraintSet_layout_constraintHeight_min = 49;
  
  public static final int ConstraintSet_layout_constraintHeight_percent = 50;
  
  public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
  
  public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
  
  public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
  
  public static final int ConstraintSet_layout_constraintLeft_creator = 54;
  
  public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
  
  public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
  
  public static final int ConstraintSet_layout_constraintRight_creator = 57;
  
  public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
  
  public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
  
  public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
  
  public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
  
  public static final int ConstraintSet_layout_constraintTop_creator = 62;
  
  public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
  
  public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
  
  public static final int ConstraintSet_layout_constraintVertical_bias = 65;
  
  public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
  
  public static final int ConstraintSet_layout_constraintVertical_weight = 67;
  
  public static final int ConstraintSet_layout_constraintWidth_default = 68;
  
  public static final int ConstraintSet_layout_constraintWidth_max = 69;
  
  public static final int ConstraintSet_layout_constraintWidth_min = 70;
  
  public static final int ConstraintSet_layout_constraintWidth_percent = 71;
  
  public static final int ConstraintSet_layout_editor_absoluteX = 72;
  
  public static final int ConstraintSet_layout_editor_absoluteY = 73;
  
  public static final int ConstraintSet_layout_goneMarginBottom = 74;
  
  public static final int ConstraintSet_layout_goneMarginEnd = 75;
  
  public static final int ConstraintSet_layout_goneMarginLeft = 76;
  
  public static final int ConstraintSet_layout_goneMarginRight = 77;
  
  public static final int ConstraintSet_layout_goneMarginStart = 78;
  
  public static final int ConstraintSet_layout_goneMarginTop = 79;
  
  public static final int[] LinearConstraintLayout = new int[] { 16842948 };
  
  public static final int LinearConstraintLayout_android_orientation = 0;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\R$styleable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */