package android.support.constraint;

public final class id {
  public static final int bottom = 2131230773;
  
  public static final int end = 2131230846;
  
  public static final int gone = 2131230871;
  
  public static final int invisible = 2131230888;
  
  public static final int left = 2131230896;
  
  public static final int packed = 2131230956;
  
  public static final int parent = 2131230958;
  
  public static final int percent = 2131230961;
  
  public static final int right = 2131230996;
  
  public static final int spread = 2131231044;
  
  public static final int spread_inside = 2131231045;
  
  public static final int start = 2131231055;
  
  public static final int top = 2131231093;
  
  public static final int wrap = 2131231134;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\R$id.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */