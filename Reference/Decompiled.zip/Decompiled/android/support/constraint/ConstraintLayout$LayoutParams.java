package android.support.constraint;

import android.content.Context;
import android.support.constraint.solver.widgets.ConstraintWidget;
import android.support.constraint.solver.widgets.Guideline;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.ViewGroup;

public class LayoutParams extends ViewGroup.MarginLayoutParams {
  public static final int BASELINE = 5;
  
  public static final int BOTTOM = 4;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static final int END = 7;
  
  public static final int HORIZONTAL = 0;
  
  public static final int LEFT = 1;
  
  public static final int MATCH_CONSTRAINT = 0;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  public static final int PARENT_ID = 0;
  
  public static final int RIGHT = 2;
  
  public static final int START = 6;
  
  public static final int TOP = 3;
  
  public static final int UNSET = -1;
  
  public static final int VERTICAL = 1;
  
  public int baselineToBaseline = -1;
  
  public int bottomToBottom = -1;
  
  public int bottomToTop = -1;
  
  public float circleAngle = 0.0F;
  
  public int circleConstraint = -1;
  
  public int circleRadius = 0;
  
  public boolean constrainedHeight = false;
  
  public boolean constrainedWidth = false;
  
  public String dimensionRatio = null;
  
  int dimensionRatioSide = 1;
  
  float dimensionRatioValue = 0.0F;
  
  public int editorAbsoluteX = -1;
  
  public int editorAbsoluteY = -1;
  
  public int endToEnd = -1;
  
  public int endToStart = -1;
  
  public int goneBottomMargin = -1;
  
  public int goneEndMargin = -1;
  
  public int goneLeftMargin = -1;
  
  public int goneRightMargin = -1;
  
  public int goneStartMargin = -1;
  
  public int goneTopMargin = -1;
  
  public int guideBegin = -1;
  
  public int guideEnd = -1;
  
  public float guidePercent = -1.0F;
  
  public boolean helped = false;
  
  public float horizontalBias = 0.5F;
  
  public int horizontalChainStyle = 0;
  
  boolean horizontalDimensionFixed = true;
  
  public float horizontalWeight = -1.0F;
  
  boolean isGuideline = false;
  
  boolean isHelper = false;
  
  boolean isInPlaceholder = false;
  
  public int leftToLeft = -1;
  
  public int leftToRight = -1;
  
  public int matchConstraintDefaultHeight = 0;
  
  public int matchConstraintDefaultWidth = 0;
  
  public int matchConstraintMaxHeight = 0;
  
  public int matchConstraintMaxWidth = 0;
  
  public int matchConstraintMinHeight = 0;
  
  public int matchConstraintMinWidth = 0;
  
  public float matchConstraintPercentHeight = 1.0F;
  
  public float matchConstraintPercentWidth = 1.0F;
  
  boolean needsBaseline = false;
  
  public int orientation = -1;
  
  int resolveGoneLeftMargin = -1;
  
  int resolveGoneRightMargin = -1;
  
  int resolvedGuideBegin;
  
  int resolvedGuideEnd;
  
  float resolvedGuidePercent;
  
  float resolvedHorizontalBias = 0.5F;
  
  int resolvedLeftToLeft = -1;
  
  int resolvedLeftToRight = -1;
  
  int resolvedRightToLeft = -1;
  
  int resolvedRightToRight = -1;
  
  public int rightToLeft = -1;
  
  public int rightToRight = -1;
  
  public int startToEnd = -1;
  
  public int startToStart = -1;
  
  public int topToBottom = -1;
  
  public int topToTop = -1;
  
  public float verticalBias = 0.5F;
  
  public int verticalChainStyle = 0;
  
  boolean verticalDimensionFixed = true;
  
  public float verticalWeight = -1.0F;
  
  ConstraintWidget widget = new ConstraintWidget();
  
  public LayoutParams(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public LayoutParams(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   6: aload_0
    //   7: iconst_m1
    //   8: putfield guideBegin : I
    //   11: aload_0
    //   12: iconst_m1
    //   13: putfield guideEnd : I
    //   16: aload_0
    //   17: ldc -1.0
    //   19: putfield guidePercent : F
    //   22: aload_0
    //   23: iconst_m1
    //   24: putfield leftToLeft : I
    //   27: aload_0
    //   28: iconst_m1
    //   29: putfield leftToRight : I
    //   32: aload_0
    //   33: iconst_m1
    //   34: putfield rightToLeft : I
    //   37: aload_0
    //   38: iconst_m1
    //   39: putfield rightToRight : I
    //   42: aload_0
    //   43: iconst_m1
    //   44: putfield topToTop : I
    //   47: aload_0
    //   48: iconst_m1
    //   49: putfield topToBottom : I
    //   52: aload_0
    //   53: iconst_m1
    //   54: putfield bottomToTop : I
    //   57: aload_0
    //   58: iconst_m1
    //   59: putfield bottomToBottom : I
    //   62: aload_0
    //   63: iconst_m1
    //   64: putfield baselineToBaseline : I
    //   67: aload_0
    //   68: iconst_m1
    //   69: putfield circleConstraint : I
    //   72: aload_0
    //   73: iconst_0
    //   74: putfield circleRadius : I
    //   77: aload_0
    //   78: fconst_0
    //   79: putfield circleAngle : F
    //   82: aload_0
    //   83: iconst_m1
    //   84: putfield startToEnd : I
    //   87: aload_0
    //   88: iconst_m1
    //   89: putfield startToStart : I
    //   92: aload_0
    //   93: iconst_m1
    //   94: putfield endToStart : I
    //   97: aload_0
    //   98: iconst_m1
    //   99: putfield endToEnd : I
    //   102: aload_0
    //   103: iconst_m1
    //   104: putfield goneLeftMargin : I
    //   107: aload_0
    //   108: iconst_m1
    //   109: putfield goneTopMargin : I
    //   112: aload_0
    //   113: iconst_m1
    //   114: putfield goneRightMargin : I
    //   117: aload_0
    //   118: iconst_m1
    //   119: putfield goneBottomMargin : I
    //   122: aload_0
    //   123: iconst_m1
    //   124: putfield goneStartMargin : I
    //   127: aload_0
    //   128: iconst_m1
    //   129: putfield goneEndMargin : I
    //   132: aload_0
    //   133: ldc 0.5
    //   135: putfield horizontalBias : F
    //   138: aload_0
    //   139: ldc 0.5
    //   141: putfield verticalBias : F
    //   144: aload_0
    //   145: aconst_null
    //   146: putfield dimensionRatio : Ljava/lang/String;
    //   149: aload_0
    //   150: fconst_0
    //   151: putfield dimensionRatioValue : F
    //   154: aload_0
    //   155: iconst_1
    //   156: putfield dimensionRatioSide : I
    //   159: aload_0
    //   160: ldc -1.0
    //   162: putfield horizontalWeight : F
    //   165: aload_0
    //   166: ldc -1.0
    //   168: putfield verticalWeight : F
    //   171: aload_0
    //   172: iconst_0
    //   173: putfield horizontalChainStyle : I
    //   176: aload_0
    //   177: iconst_0
    //   178: putfield verticalChainStyle : I
    //   181: aload_0
    //   182: iconst_0
    //   183: putfield matchConstraintDefaultWidth : I
    //   186: aload_0
    //   187: iconst_0
    //   188: putfield matchConstraintDefaultHeight : I
    //   191: aload_0
    //   192: iconst_0
    //   193: putfield matchConstraintMinWidth : I
    //   196: aload_0
    //   197: iconst_0
    //   198: putfield matchConstraintMinHeight : I
    //   201: aload_0
    //   202: iconst_0
    //   203: putfield matchConstraintMaxWidth : I
    //   206: aload_0
    //   207: iconst_0
    //   208: putfield matchConstraintMaxHeight : I
    //   211: aload_0
    //   212: fconst_1
    //   213: putfield matchConstraintPercentWidth : F
    //   216: aload_0
    //   217: fconst_1
    //   218: putfield matchConstraintPercentHeight : F
    //   221: aload_0
    //   222: iconst_m1
    //   223: putfield editorAbsoluteX : I
    //   226: aload_0
    //   227: iconst_m1
    //   228: putfield editorAbsoluteY : I
    //   231: aload_0
    //   232: iconst_m1
    //   233: putfield orientation : I
    //   236: aload_0
    //   237: iconst_0
    //   238: putfield constrainedWidth : Z
    //   241: aload_0
    //   242: iconst_0
    //   243: putfield constrainedHeight : Z
    //   246: aload_0
    //   247: iconst_1
    //   248: putfield horizontalDimensionFixed : Z
    //   251: aload_0
    //   252: iconst_1
    //   253: putfield verticalDimensionFixed : Z
    //   256: aload_0
    //   257: iconst_0
    //   258: putfield needsBaseline : Z
    //   261: aload_0
    //   262: iconst_0
    //   263: putfield isGuideline : Z
    //   266: aload_0
    //   267: iconst_0
    //   268: putfield isHelper : Z
    //   271: aload_0
    //   272: iconst_0
    //   273: putfield isInPlaceholder : Z
    //   276: aload_0
    //   277: iconst_m1
    //   278: putfield resolvedLeftToLeft : I
    //   281: aload_0
    //   282: iconst_m1
    //   283: putfield resolvedLeftToRight : I
    //   286: aload_0
    //   287: iconst_m1
    //   288: putfield resolvedRightToLeft : I
    //   291: aload_0
    //   292: iconst_m1
    //   293: putfield resolvedRightToRight : I
    //   296: aload_0
    //   297: iconst_m1
    //   298: putfield resolveGoneLeftMargin : I
    //   301: aload_0
    //   302: iconst_m1
    //   303: putfield resolveGoneRightMargin : I
    //   306: aload_0
    //   307: ldc 0.5
    //   309: putfield resolvedHorizontalBias : F
    //   312: aload_0
    //   313: new android/support/constraint/solver/widgets/ConstraintWidget
    //   316: dup
    //   317: invokespecial <init> : ()V
    //   320: putfield widget : Landroid/support/constraint/solver/widgets/ConstraintWidget;
    //   323: aload_0
    //   324: iconst_0
    //   325: putfield helped : Z
    //   328: aload_1
    //   329: aload_2
    //   330: getstatic android/support/constraint/R$styleable.ConstraintLayout_Layout : [I
    //   333: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   336: astore_1
    //   337: aload_1
    //   338: invokevirtual getIndexCount : ()I
    //   341: istore_3
    //   342: iconst_0
    //   343: istore #4
    //   345: iload #4
    //   347: iload_3
    //   348: if_icmpge -> 2040
    //   351: aload_1
    //   352: iload #4
    //   354: invokevirtual getIndex : (I)I
    //   357: istore #5
    //   359: getstatic android/support/constraint/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
    //   362: iload #5
    //   364: invokevirtual get : (I)I
    //   367: tableswitch default -> 584, 0 -> 2034, 1 -> 2020, 2 -> 1984, 3 -> 1967, 4 -> 1919, 5 -> 1902, 6 -> 1885, 7 -> 1868, 8 -> 1832, 9 -> 1796, 10 -> 1760, 11 -> 1724, 12 -> 1688, 13 -> 1652, 14 -> 1616, 15 -> 1580, 16 -> 1544, 17 -> 1508, 18 -> 1472, 19 -> 1436, 20 -> 1400, 21 -> 1383, 22 -> 1366, 23 -> 1349, 24 -> 1332, 25 -> 1315, 26 -> 1298, 27 -> 1281, 28 -> 1264, 29 -> 1247, 30 -> 1230, 31 -> 1198, 32 -> 1166, 33 -> 1124, 34 -> 1082, 35 -> 1061, 36 -> 1019, 37 -> 977, 38 -> 956, 39 -> 2034, 40 -> 2034, 41 -> 2034, 42 -> 2034, 43 -> 584, 44 -> 683, 45 -> 666, 46 -> 649, 47 -> 635, 48 -> 621, 49 -> 604, 50 -> 587
    //   584: goto -> 2034
    //   587: aload_0
    //   588: aload_1
    //   589: iload #5
    //   591: aload_0
    //   592: getfield editorAbsoluteY : I
    //   595: invokevirtual getDimensionPixelOffset : (II)I
    //   598: putfield editorAbsoluteY : I
    //   601: goto -> 2034
    //   604: aload_0
    //   605: aload_1
    //   606: iload #5
    //   608: aload_0
    //   609: getfield editorAbsoluteX : I
    //   612: invokevirtual getDimensionPixelOffset : (II)I
    //   615: putfield editorAbsoluteX : I
    //   618: goto -> 2034
    //   621: aload_0
    //   622: aload_1
    //   623: iload #5
    //   625: iconst_0
    //   626: invokevirtual getInt : (II)I
    //   629: putfield verticalChainStyle : I
    //   632: goto -> 2034
    //   635: aload_0
    //   636: aload_1
    //   637: iload #5
    //   639: iconst_0
    //   640: invokevirtual getInt : (II)I
    //   643: putfield horizontalChainStyle : I
    //   646: goto -> 2034
    //   649: aload_0
    //   650: aload_1
    //   651: iload #5
    //   653: aload_0
    //   654: getfield verticalWeight : F
    //   657: invokevirtual getFloat : (IF)F
    //   660: putfield verticalWeight : F
    //   663: goto -> 2034
    //   666: aload_0
    //   667: aload_1
    //   668: iload #5
    //   670: aload_0
    //   671: getfield horizontalWeight : F
    //   674: invokevirtual getFloat : (IF)F
    //   677: putfield horizontalWeight : F
    //   680: goto -> 2034
    //   683: aload_0
    //   684: aload_1
    //   685: iload #5
    //   687: invokevirtual getString : (I)Ljava/lang/String;
    //   690: putfield dimensionRatio : Ljava/lang/String;
    //   693: aload_0
    //   694: ldc_w NaN
    //   697: putfield dimensionRatioValue : F
    //   700: aload_0
    //   701: iconst_m1
    //   702: putfield dimensionRatioSide : I
    //   705: aload_0
    //   706: getfield dimensionRatio : Ljava/lang/String;
    //   709: astore_2
    //   710: aload_2
    //   711: ifnull -> 2034
    //   714: aload_2
    //   715: invokevirtual length : ()I
    //   718: istore #6
    //   720: aload_0
    //   721: getfield dimensionRatio : Ljava/lang/String;
    //   724: bipush #44
    //   726: invokevirtual indexOf : (I)I
    //   729: istore #5
    //   731: iload #5
    //   733: ifle -> 795
    //   736: iload #5
    //   738: iload #6
    //   740: iconst_1
    //   741: isub
    //   742: if_icmpge -> 795
    //   745: aload_0
    //   746: getfield dimensionRatio : Ljava/lang/String;
    //   749: iconst_0
    //   750: iload #5
    //   752: invokevirtual substring : (II)Ljava/lang/String;
    //   755: astore_2
    //   756: aload_2
    //   757: ldc_w 'W'
    //   760: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   763: ifeq -> 774
    //   766: aload_0
    //   767: iconst_0
    //   768: putfield dimensionRatioSide : I
    //   771: goto -> 789
    //   774: aload_2
    //   775: ldc_w 'H'
    //   778: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   781: ifeq -> 789
    //   784: aload_0
    //   785: iconst_1
    //   786: putfield dimensionRatioSide : I
    //   789: iinc #5, 1
    //   792: goto -> 798
    //   795: iconst_0
    //   796: istore #5
    //   798: aload_0
    //   799: getfield dimensionRatio : Ljava/lang/String;
    //   802: bipush #58
    //   804: invokevirtual indexOf : (I)I
    //   807: istore #7
    //   809: iload #7
    //   811: iflt -> 928
    //   814: iload #7
    //   816: iload #6
    //   818: iconst_1
    //   819: isub
    //   820: if_icmpge -> 928
    //   823: aload_0
    //   824: getfield dimensionRatio : Ljava/lang/String;
    //   827: iload #5
    //   829: iload #7
    //   831: invokevirtual substring : (II)Ljava/lang/String;
    //   834: astore_2
    //   835: aload_0
    //   836: getfield dimensionRatio : Ljava/lang/String;
    //   839: iload #7
    //   841: iconst_1
    //   842: iadd
    //   843: invokevirtual substring : (I)Ljava/lang/String;
    //   846: astore #8
    //   848: aload_2
    //   849: invokevirtual length : ()I
    //   852: ifle -> 2034
    //   855: aload #8
    //   857: invokevirtual length : ()I
    //   860: ifle -> 2034
    //   863: aload_2
    //   864: invokestatic parseFloat : (Ljava/lang/String;)F
    //   867: fstore #9
    //   869: aload #8
    //   871: invokestatic parseFloat : (Ljava/lang/String;)F
    //   874: fstore #10
    //   876: fload #9
    //   878: fconst_0
    //   879: fcmpl
    //   880: ifle -> 2034
    //   883: fload #10
    //   885: fconst_0
    //   886: fcmpl
    //   887: ifle -> 2034
    //   890: aload_0
    //   891: getfield dimensionRatioSide : I
    //   894: iconst_1
    //   895: if_icmpne -> 913
    //   898: aload_0
    //   899: fload #10
    //   901: fload #9
    //   903: fdiv
    //   904: invokestatic abs : (F)F
    //   907: putfield dimensionRatioValue : F
    //   910: goto -> 2034
    //   913: aload_0
    //   914: fload #9
    //   916: fload #10
    //   918: fdiv
    //   919: invokestatic abs : (F)F
    //   922: putfield dimensionRatioValue : F
    //   925: goto -> 2034
    //   928: aload_0
    //   929: getfield dimensionRatio : Ljava/lang/String;
    //   932: iload #5
    //   934: invokevirtual substring : (I)Ljava/lang/String;
    //   937: astore_2
    //   938: aload_2
    //   939: invokevirtual length : ()I
    //   942: ifle -> 2034
    //   945: aload_0
    //   946: aload_2
    //   947: invokestatic parseFloat : (Ljava/lang/String;)F
    //   950: putfield dimensionRatioValue : F
    //   953: goto -> 2034
    //   956: aload_0
    //   957: fconst_0
    //   958: aload_1
    //   959: iload #5
    //   961: aload_0
    //   962: getfield matchConstraintPercentHeight : F
    //   965: invokevirtual getFloat : (IF)F
    //   968: invokestatic max : (FF)F
    //   971: putfield matchConstraintPercentHeight : F
    //   974: goto -> 2034
    //   977: aload_0
    //   978: aload_1
    //   979: iload #5
    //   981: aload_0
    //   982: getfield matchConstraintMaxHeight : I
    //   985: invokevirtual getDimensionPixelSize : (II)I
    //   988: putfield matchConstraintMaxHeight : I
    //   991: goto -> 2034
    //   994: astore_2
    //   995: aload_1
    //   996: iload #5
    //   998: aload_0
    //   999: getfield matchConstraintMaxHeight : I
    //   1002: invokevirtual getInt : (II)I
    //   1005: bipush #-2
    //   1007: if_icmpne -> 2034
    //   1010: aload_0
    //   1011: bipush #-2
    //   1013: putfield matchConstraintMaxHeight : I
    //   1016: goto -> 2034
    //   1019: aload_0
    //   1020: aload_1
    //   1021: iload #5
    //   1023: aload_0
    //   1024: getfield matchConstraintMinHeight : I
    //   1027: invokevirtual getDimensionPixelSize : (II)I
    //   1030: putfield matchConstraintMinHeight : I
    //   1033: goto -> 2034
    //   1036: astore_2
    //   1037: aload_1
    //   1038: iload #5
    //   1040: aload_0
    //   1041: getfield matchConstraintMinHeight : I
    //   1044: invokevirtual getInt : (II)I
    //   1047: bipush #-2
    //   1049: if_icmpne -> 2034
    //   1052: aload_0
    //   1053: bipush #-2
    //   1055: putfield matchConstraintMinHeight : I
    //   1058: goto -> 2034
    //   1061: aload_0
    //   1062: fconst_0
    //   1063: aload_1
    //   1064: iload #5
    //   1066: aload_0
    //   1067: getfield matchConstraintPercentWidth : F
    //   1070: invokevirtual getFloat : (IF)F
    //   1073: invokestatic max : (FF)F
    //   1076: putfield matchConstraintPercentWidth : F
    //   1079: goto -> 2034
    //   1082: aload_0
    //   1083: aload_1
    //   1084: iload #5
    //   1086: aload_0
    //   1087: getfield matchConstraintMaxWidth : I
    //   1090: invokevirtual getDimensionPixelSize : (II)I
    //   1093: putfield matchConstraintMaxWidth : I
    //   1096: goto -> 2034
    //   1099: astore_2
    //   1100: aload_1
    //   1101: iload #5
    //   1103: aload_0
    //   1104: getfield matchConstraintMaxWidth : I
    //   1107: invokevirtual getInt : (II)I
    //   1110: bipush #-2
    //   1112: if_icmpne -> 2034
    //   1115: aload_0
    //   1116: bipush #-2
    //   1118: putfield matchConstraintMaxWidth : I
    //   1121: goto -> 2034
    //   1124: aload_0
    //   1125: aload_1
    //   1126: iload #5
    //   1128: aload_0
    //   1129: getfield matchConstraintMinWidth : I
    //   1132: invokevirtual getDimensionPixelSize : (II)I
    //   1135: putfield matchConstraintMinWidth : I
    //   1138: goto -> 2034
    //   1141: astore_2
    //   1142: aload_1
    //   1143: iload #5
    //   1145: aload_0
    //   1146: getfield matchConstraintMinWidth : I
    //   1149: invokevirtual getInt : (II)I
    //   1152: bipush #-2
    //   1154: if_icmpne -> 2034
    //   1157: aload_0
    //   1158: bipush #-2
    //   1160: putfield matchConstraintMinWidth : I
    //   1163: goto -> 2034
    //   1166: aload_0
    //   1167: aload_1
    //   1168: iload #5
    //   1170: iconst_0
    //   1171: invokevirtual getInt : (II)I
    //   1174: putfield matchConstraintDefaultHeight : I
    //   1177: aload_0
    //   1178: getfield matchConstraintDefaultHeight : I
    //   1181: iconst_1
    //   1182: if_icmpne -> 2034
    //   1185: ldc_w 'ConstraintLayout'
    //   1188: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
    //   1191: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1194: pop
    //   1195: goto -> 2034
    //   1198: aload_0
    //   1199: aload_1
    //   1200: iload #5
    //   1202: iconst_0
    //   1203: invokevirtual getInt : (II)I
    //   1206: putfield matchConstraintDefaultWidth : I
    //   1209: aload_0
    //   1210: getfield matchConstraintDefaultWidth : I
    //   1213: iconst_1
    //   1214: if_icmpne -> 2034
    //   1217: ldc_w 'ConstraintLayout'
    //   1220: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
    //   1223: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1226: pop
    //   1227: goto -> 2034
    //   1230: aload_0
    //   1231: aload_1
    //   1232: iload #5
    //   1234: aload_0
    //   1235: getfield verticalBias : F
    //   1238: invokevirtual getFloat : (IF)F
    //   1241: putfield verticalBias : F
    //   1244: goto -> 2034
    //   1247: aload_0
    //   1248: aload_1
    //   1249: iload #5
    //   1251: aload_0
    //   1252: getfield horizontalBias : F
    //   1255: invokevirtual getFloat : (IF)F
    //   1258: putfield horizontalBias : F
    //   1261: goto -> 2034
    //   1264: aload_0
    //   1265: aload_1
    //   1266: iload #5
    //   1268: aload_0
    //   1269: getfield constrainedHeight : Z
    //   1272: invokevirtual getBoolean : (IZ)Z
    //   1275: putfield constrainedHeight : Z
    //   1278: goto -> 2034
    //   1281: aload_0
    //   1282: aload_1
    //   1283: iload #5
    //   1285: aload_0
    //   1286: getfield constrainedWidth : Z
    //   1289: invokevirtual getBoolean : (IZ)Z
    //   1292: putfield constrainedWidth : Z
    //   1295: goto -> 2034
    //   1298: aload_0
    //   1299: aload_1
    //   1300: iload #5
    //   1302: aload_0
    //   1303: getfield goneEndMargin : I
    //   1306: invokevirtual getDimensionPixelSize : (II)I
    //   1309: putfield goneEndMargin : I
    //   1312: goto -> 2034
    //   1315: aload_0
    //   1316: aload_1
    //   1317: iload #5
    //   1319: aload_0
    //   1320: getfield goneStartMargin : I
    //   1323: invokevirtual getDimensionPixelSize : (II)I
    //   1326: putfield goneStartMargin : I
    //   1329: goto -> 2034
    //   1332: aload_0
    //   1333: aload_1
    //   1334: iload #5
    //   1336: aload_0
    //   1337: getfield goneBottomMargin : I
    //   1340: invokevirtual getDimensionPixelSize : (II)I
    //   1343: putfield goneBottomMargin : I
    //   1346: goto -> 2034
    //   1349: aload_0
    //   1350: aload_1
    //   1351: iload #5
    //   1353: aload_0
    //   1354: getfield goneRightMargin : I
    //   1357: invokevirtual getDimensionPixelSize : (II)I
    //   1360: putfield goneRightMargin : I
    //   1363: goto -> 2034
    //   1366: aload_0
    //   1367: aload_1
    //   1368: iload #5
    //   1370: aload_0
    //   1371: getfield goneTopMargin : I
    //   1374: invokevirtual getDimensionPixelSize : (II)I
    //   1377: putfield goneTopMargin : I
    //   1380: goto -> 2034
    //   1383: aload_0
    //   1384: aload_1
    //   1385: iload #5
    //   1387: aload_0
    //   1388: getfield goneLeftMargin : I
    //   1391: invokevirtual getDimensionPixelSize : (II)I
    //   1394: putfield goneLeftMargin : I
    //   1397: goto -> 2034
    //   1400: aload_0
    //   1401: aload_1
    //   1402: iload #5
    //   1404: aload_0
    //   1405: getfield endToEnd : I
    //   1408: invokevirtual getResourceId : (II)I
    //   1411: putfield endToEnd : I
    //   1414: aload_0
    //   1415: getfield endToEnd : I
    //   1418: iconst_m1
    //   1419: if_icmpne -> 2034
    //   1422: aload_0
    //   1423: aload_1
    //   1424: iload #5
    //   1426: iconst_m1
    //   1427: invokevirtual getInt : (II)I
    //   1430: putfield endToEnd : I
    //   1433: goto -> 2034
    //   1436: aload_0
    //   1437: aload_1
    //   1438: iload #5
    //   1440: aload_0
    //   1441: getfield endToStart : I
    //   1444: invokevirtual getResourceId : (II)I
    //   1447: putfield endToStart : I
    //   1450: aload_0
    //   1451: getfield endToStart : I
    //   1454: iconst_m1
    //   1455: if_icmpne -> 2034
    //   1458: aload_0
    //   1459: aload_1
    //   1460: iload #5
    //   1462: iconst_m1
    //   1463: invokevirtual getInt : (II)I
    //   1466: putfield endToStart : I
    //   1469: goto -> 2034
    //   1472: aload_0
    //   1473: aload_1
    //   1474: iload #5
    //   1476: aload_0
    //   1477: getfield startToStart : I
    //   1480: invokevirtual getResourceId : (II)I
    //   1483: putfield startToStart : I
    //   1486: aload_0
    //   1487: getfield startToStart : I
    //   1490: iconst_m1
    //   1491: if_icmpne -> 2034
    //   1494: aload_0
    //   1495: aload_1
    //   1496: iload #5
    //   1498: iconst_m1
    //   1499: invokevirtual getInt : (II)I
    //   1502: putfield startToStart : I
    //   1505: goto -> 2034
    //   1508: aload_0
    //   1509: aload_1
    //   1510: iload #5
    //   1512: aload_0
    //   1513: getfield startToEnd : I
    //   1516: invokevirtual getResourceId : (II)I
    //   1519: putfield startToEnd : I
    //   1522: aload_0
    //   1523: getfield startToEnd : I
    //   1526: iconst_m1
    //   1527: if_icmpne -> 2034
    //   1530: aload_0
    //   1531: aload_1
    //   1532: iload #5
    //   1534: iconst_m1
    //   1535: invokevirtual getInt : (II)I
    //   1538: putfield startToEnd : I
    //   1541: goto -> 2034
    //   1544: aload_0
    //   1545: aload_1
    //   1546: iload #5
    //   1548: aload_0
    //   1549: getfield baselineToBaseline : I
    //   1552: invokevirtual getResourceId : (II)I
    //   1555: putfield baselineToBaseline : I
    //   1558: aload_0
    //   1559: getfield baselineToBaseline : I
    //   1562: iconst_m1
    //   1563: if_icmpne -> 2034
    //   1566: aload_0
    //   1567: aload_1
    //   1568: iload #5
    //   1570: iconst_m1
    //   1571: invokevirtual getInt : (II)I
    //   1574: putfield baselineToBaseline : I
    //   1577: goto -> 2034
    //   1580: aload_0
    //   1581: aload_1
    //   1582: iload #5
    //   1584: aload_0
    //   1585: getfield bottomToBottom : I
    //   1588: invokevirtual getResourceId : (II)I
    //   1591: putfield bottomToBottom : I
    //   1594: aload_0
    //   1595: getfield bottomToBottom : I
    //   1598: iconst_m1
    //   1599: if_icmpne -> 2034
    //   1602: aload_0
    //   1603: aload_1
    //   1604: iload #5
    //   1606: iconst_m1
    //   1607: invokevirtual getInt : (II)I
    //   1610: putfield bottomToBottom : I
    //   1613: goto -> 2034
    //   1616: aload_0
    //   1617: aload_1
    //   1618: iload #5
    //   1620: aload_0
    //   1621: getfield bottomToTop : I
    //   1624: invokevirtual getResourceId : (II)I
    //   1627: putfield bottomToTop : I
    //   1630: aload_0
    //   1631: getfield bottomToTop : I
    //   1634: iconst_m1
    //   1635: if_icmpne -> 2034
    //   1638: aload_0
    //   1639: aload_1
    //   1640: iload #5
    //   1642: iconst_m1
    //   1643: invokevirtual getInt : (II)I
    //   1646: putfield bottomToTop : I
    //   1649: goto -> 2034
    //   1652: aload_0
    //   1653: aload_1
    //   1654: iload #5
    //   1656: aload_0
    //   1657: getfield topToBottom : I
    //   1660: invokevirtual getResourceId : (II)I
    //   1663: putfield topToBottom : I
    //   1666: aload_0
    //   1667: getfield topToBottom : I
    //   1670: iconst_m1
    //   1671: if_icmpne -> 2034
    //   1674: aload_0
    //   1675: aload_1
    //   1676: iload #5
    //   1678: iconst_m1
    //   1679: invokevirtual getInt : (II)I
    //   1682: putfield topToBottom : I
    //   1685: goto -> 2034
    //   1688: aload_0
    //   1689: aload_1
    //   1690: iload #5
    //   1692: aload_0
    //   1693: getfield topToTop : I
    //   1696: invokevirtual getResourceId : (II)I
    //   1699: putfield topToTop : I
    //   1702: aload_0
    //   1703: getfield topToTop : I
    //   1706: iconst_m1
    //   1707: if_icmpne -> 2034
    //   1710: aload_0
    //   1711: aload_1
    //   1712: iload #5
    //   1714: iconst_m1
    //   1715: invokevirtual getInt : (II)I
    //   1718: putfield topToTop : I
    //   1721: goto -> 2034
    //   1724: aload_0
    //   1725: aload_1
    //   1726: iload #5
    //   1728: aload_0
    //   1729: getfield rightToRight : I
    //   1732: invokevirtual getResourceId : (II)I
    //   1735: putfield rightToRight : I
    //   1738: aload_0
    //   1739: getfield rightToRight : I
    //   1742: iconst_m1
    //   1743: if_icmpne -> 2034
    //   1746: aload_0
    //   1747: aload_1
    //   1748: iload #5
    //   1750: iconst_m1
    //   1751: invokevirtual getInt : (II)I
    //   1754: putfield rightToRight : I
    //   1757: goto -> 2034
    //   1760: aload_0
    //   1761: aload_1
    //   1762: iload #5
    //   1764: aload_0
    //   1765: getfield rightToLeft : I
    //   1768: invokevirtual getResourceId : (II)I
    //   1771: putfield rightToLeft : I
    //   1774: aload_0
    //   1775: getfield rightToLeft : I
    //   1778: iconst_m1
    //   1779: if_icmpne -> 2034
    //   1782: aload_0
    //   1783: aload_1
    //   1784: iload #5
    //   1786: iconst_m1
    //   1787: invokevirtual getInt : (II)I
    //   1790: putfield rightToLeft : I
    //   1793: goto -> 2034
    //   1796: aload_0
    //   1797: aload_1
    //   1798: iload #5
    //   1800: aload_0
    //   1801: getfield leftToRight : I
    //   1804: invokevirtual getResourceId : (II)I
    //   1807: putfield leftToRight : I
    //   1810: aload_0
    //   1811: getfield leftToRight : I
    //   1814: iconst_m1
    //   1815: if_icmpne -> 2034
    //   1818: aload_0
    //   1819: aload_1
    //   1820: iload #5
    //   1822: iconst_m1
    //   1823: invokevirtual getInt : (II)I
    //   1826: putfield leftToRight : I
    //   1829: goto -> 2034
    //   1832: aload_0
    //   1833: aload_1
    //   1834: iload #5
    //   1836: aload_0
    //   1837: getfield leftToLeft : I
    //   1840: invokevirtual getResourceId : (II)I
    //   1843: putfield leftToLeft : I
    //   1846: aload_0
    //   1847: getfield leftToLeft : I
    //   1850: iconst_m1
    //   1851: if_icmpne -> 2034
    //   1854: aload_0
    //   1855: aload_1
    //   1856: iload #5
    //   1858: iconst_m1
    //   1859: invokevirtual getInt : (II)I
    //   1862: putfield leftToLeft : I
    //   1865: goto -> 2034
    //   1868: aload_0
    //   1869: aload_1
    //   1870: iload #5
    //   1872: aload_0
    //   1873: getfield guidePercent : F
    //   1876: invokevirtual getFloat : (IF)F
    //   1879: putfield guidePercent : F
    //   1882: goto -> 2034
    //   1885: aload_0
    //   1886: aload_1
    //   1887: iload #5
    //   1889: aload_0
    //   1890: getfield guideEnd : I
    //   1893: invokevirtual getDimensionPixelOffset : (II)I
    //   1896: putfield guideEnd : I
    //   1899: goto -> 2034
    //   1902: aload_0
    //   1903: aload_1
    //   1904: iload #5
    //   1906: aload_0
    //   1907: getfield guideBegin : I
    //   1910: invokevirtual getDimensionPixelOffset : (II)I
    //   1913: putfield guideBegin : I
    //   1916: goto -> 2034
    //   1919: aload_0
    //   1920: aload_1
    //   1921: iload #5
    //   1923: aload_0
    //   1924: getfield circleAngle : F
    //   1927: invokevirtual getFloat : (IF)F
    //   1930: ldc_w 360.0
    //   1933: frem
    //   1934: putfield circleAngle : F
    //   1937: aload_0
    //   1938: getfield circleAngle : F
    //   1941: fstore #10
    //   1943: fload #10
    //   1945: fconst_0
    //   1946: fcmpg
    //   1947: ifge -> 2034
    //   1950: aload_0
    //   1951: ldc_w 360.0
    //   1954: fload #10
    //   1956: fsub
    //   1957: ldc_w 360.0
    //   1960: frem
    //   1961: putfield circleAngle : F
    //   1964: goto -> 2034
    //   1967: aload_0
    //   1968: aload_1
    //   1969: iload #5
    //   1971: aload_0
    //   1972: getfield circleRadius : I
    //   1975: invokevirtual getDimensionPixelSize : (II)I
    //   1978: putfield circleRadius : I
    //   1981: goto -> 2034
    //   1984: aload_0
    //   1985: aload_1
    //   1986: iload #5
    //   1988: aload_0
    //   1989: getfield circleConstraint : I
    //   1992: invokevirtual getResourceId : (II)I
    //   1995: putfield circleConstraint : I
    //   1998: aload_0
    //   1999: getfield circleConstraint : I
    //   2002: iconst_m1
    //   2003: if_icmpne -> 2034
    //   2006: aload_0
    //   2007: aload_1
    //   2008: iload #5
    //   2010: iconst_m1
    //   2011: invokevirtual getInt : (II)I
    //   2014: putfield circleConstraint : I
    //   2017: goto -> 2034
    //   2020: aload_0
    //   2021: aload_1
    //   2022: iload #5
    //   2024: aload_0
    //   2025: getfield orientation : I
    //   2028: invokevirtual getInt : (II)I
    //   2031: putfield orientation : I
    //   2034: iinc #4, 1
    //   2037: goto -> 345
    //   2040: aload_1
    //   2041: invokevirtual recycle : ()V
    //   2044: aload_0
    //   2045: invokevirtual validate : ()V
    //   2048: return
    //   2049: astore_2
    //   2050: goto -> 2034
    // Exception table:
    //   from	to	target	type
    //   863	876	2049	java/lang/NumberFormatException
    //   890	910	2049	java/lang/NumberFormatException
    //   913	925	2049	java/lang/NumberFormatException
    //   945	953	2049	java/lang/NumberFormatException
    //   977	991	994	java/lang/Exception
    //   1019	1033	1036	java/lang/Exception
    //   1082	1096	1099	java/lang/Exception
    //   1124	1138	1141	java/lang/Exception
  }
  
  public LayoutParams(LayoutParams paramLayoutParams) {
    super(paramLayoutParams);
    this.guideBegin = paramLayoutParams.guideBegin;
    this.guideEnd = paramLayoutParams.guideEnd;
    this.guidePercent = paramLayoutParams.guidePercent;
    this.leftToLeft = paramLayoutParams.leftToLeft;
    this.leftToRight = paramLayoutParams.leftToRight;
    this.rightToLeft = paramLayoutParams.rightToLeft;
    this.rightToRight = paramLayoutParams.rightToRight;
    this.topToTop = paramLayoutParams.topToTop;
    this.topToBottom = paramLayoutParams.topToBottom;
    this.bottomToTop = paramLayoutParams.bottomToTop;
    this.bottomToBottom = paramLayoutParams.bottomToBottom;
    this.baselineToBaseline = paramLayoutParams.baselineToBaseline;
    this.circleConstraint = paramLayoutParams.circleConstraint;
    this.circleRadius = paramLayoutParams.circleRadius;
    this.circleAngle = paramLayoutParams.circleAngle;
    this.startToEnd = paramLayoutParams.startToEnd;
    this.startToStart = paramLayoutParams.startToStart;
    this.endToStart = paramLayoutParams.endToStart;
    this.endToEnd = paramLayoutParams.endToEnd;
    this.goneLeftMargin = paramLayoutParams.goneLeftMargin;
    this.goneTopMargin = paramLayoutParams.goneTopMargin;
    this.goneRightMargin = paramLayoutParams.goneRightMargin;
    this.goneBottomMargin = paramLayoutParams.goneBottomMargin;
    this.goneStartMargin = paramLayoutParams.goneStartMargin;
    this.goneEndMargin = paramLayoutParams.goneEndMargin;
    this.horizontalBias = paramLayoutParams.horizontalBias;
    this.verticalBias = paramLayoutParams.verticalBias;
    this.dimensionRatio = paramLayoutParams.dimensionRatio;
    this.dimensionRatioValue = paramLayoutParams.dimensionRatioValue;
    this.dimensionRatioSide = paramLayoutParams.dimensionRatioSide;
    this.horizontalWeight = paramLayoutParams.horizontalWeight;
    this.verticalWeight = paramLayoutParams.verticalWeight;
    this.horizontalChainStyle = paramLayoutParams.horizontalChainStyle;
    this.verticalChainStyle = paramLayoutParams.verticalChainStyle;
    this.constrainedWidth = paramLayoutParams.constrainedWidth;
    this.constrainedHeight = paramLayoutParams.constrainedHeight;
    this.matchConstraintDefaultWidth = paramLayoutParams.matchConstraintDefaultWidth;
    this.matchConstraintDefaultHeight = paramLayoutParams.matchConstraintDefaultHeight;
    this.matchConstraintMinWidth = paramLayoutParams.matchConstraintMinWidth;
    this.matchConstraintMaxWidth = paramLayoutParams.matchConstraintMaxWidth;
    this.matchConstraintMinHeight = paramLayoutParams.matchConstraintMinHeight;
    this.matchConstraintMaxHeight = paramLayoutParams.matchConstraintMaxHeight;
    this.matchConstraintPercentWidth = paramLayoutParams.matchConstraintPercentWidth;
    this.matchConstraintPercentHeight = paramLayoutParams.matchConstraintPercentHeight;
    this.editorAbsoluteX = paramLayoutParams.editorAbsoluteX;
    this.editorAbsoluteY = paramLayoutParams.editorAbsoluteY;
    this.orientation = paramLayoutParams.orientation;
    this.horizontalDimensionFixed = paramLayoutParams.horizontalDimensionFixed;
    this.verticalDimensionFixed = paramLayoutParams.verticalDimensionFixed;
    this.needsBaseline = paramLayoutParams.needsBaseline;
    this.isGuideline = paramLayoutParams.isGuideline;
    this.resolvedLeftToLeft = paramLayoutParams.resolvedLeftToLeft;
    this.resolvedLeftToRight = paramLayoutParams.resolvedLeftToRight;
    this.resolvedRightToLeft = paramLayoutParams.resolvedRightToLeft;
    this.resolvedRightToRight = paramLayoutParams.resolvedRightToRight;
    this.resolveGoneLeftMargin = paramLayoutParams.resolveGoneLeftMargin;
    this.resolveGoneRightMargin = paramLayoutParams.resolveGoneRightMargin;
    this.resolvedHorizontalBias = paramLayoutParams.resolvedHorizontalBias;
    this.widget = paramLayoutParams.widget;
  }
  
  public LayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    super(paramLayoutParams);
  }
  
  public void reset() {
    ConstraintWidget constraintWidget = this.widget;
    if (constraintWidget != null)
      constraintWidget.reset(); 
  }
  
  public void resolveLayoutDirection(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield leftMargin : I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield rightMargin : I
    //   9: istore_3
    //   10: aload_0
    //   11: iload_1
    //   12: invokespecial resolveLayoutDirection : (I)V
    //   15: aload_0
    //   16: iconst_m1
    //   17: putfield resolvedRightToLeft : I
    //   20: aload_0
    //   21: iconst_m1
    //   22: putfield resolvedRightToRight : I
    //   25: aload_0
    //   26: iconst_m1
    //   27: putfield resolvedLeftToLeft : I
    //   30: aload_0
    //   31: iconst_m1
    //   32: putfield resolvedLeftToRight : I
    //   35: aload_0
    //   36: iconst_m1
    //   37: putfield resolveGoneLeftMargin : I
    //   40: aload_0
    //   41: iconst_m1
    //   42: putfield resolveGoneRightMargin : I
    //   45: aload_0
    //   46: aload_0
    //   47: getfield goneLeftMargin : I
    //   50: putfield resolveGoneLeftMargin : I
    //   53: aload_0
    //   54: aload_0
    //   55: getfield goneRightMargin : I
    //   58: putfield resolveGoneRightMargin : I
    //   61: aload_0
    //   62: aload_0
    //   63: getfield horizontalBias : F
    //   66: putfield resolvedHorizontalBias : F
    //   69: aload_0
    //   70: aload_0
    //   71: getfield guideBegin : I
    //   74: putfield resolvedGuideBegin : I
    //   77: aload_0
    //   78: aload_0
    //   79: getfield guideEnd : I
    //   82: putfield resolvedGuideEnd : I
    //   85: aload_0
    //   86: aload_0
    //   87: getfield guidePercent : F
    //   90: putfield resolvedGuidePercent : F
    //   93: aload_0
    //   94: invokevirtual getLayoutDirection : ()I
    //   97: istore_1
    //   98: iconst_0
    //   99: istore #4
    //   101: iconst_1
    //   102: iload_1
    //   103: if_icmpne -> 111
    //   106: iconst_1
    //   107: istore_1
    //   108: goto -> 113
    //   111: iconst_0
    //   112: istore_1
    //   113: iload_1
    //   114: ifeq -> 359
    //   117: aload_0
    //   118: getfield startToEnd : I
    //   121: istore_1
    //   122: iload_1
    //   123: iconst_m1
    //   124: if_icmpeq -> 137
    //   127: aload_0
    //   128: iload_1
    //   129: putfield resolvedRightToLeft : I
    //   132: iconst_1
    //   133: istore_1
    //   134: goto -> 161
    //   137: aload_0
    //   138: getfield startToStart : I
    //   141: istore #5
    //   143: iload #4
    //   145: istore_1
    //   146: iload #5
    //   148: iconst_m1
    //   149: if_icmpeq -> 161
    //   152: aload_0
    //   153: iload #5
    //   155: putfield resolvedRightToRight : I
    //   158: goto -> 132
    //   161: aload_0
    //   162: getfield endToStart : I
    //   165: istore #4
    //   167: iload #4
    //   169: iconst_m1
    //   170: if_icmpeq -> 181
    //   173: aload_0
    //   174: iload #4
    //   176: putfield resolvedLeftToRight : I
    //   179: iconst_1
    //   180: istore_1
    //   181: aload_0
    //   182: getfield endToEnd : I
    //   185: istore #4
    //   187: iload #4
    //   189: iconst_m1
    //   190: if_icmpeq -> 201
    //   193: aload_0
    //   194: iload #4
    //   196: putfield resolvedLeftToLeft : I
    //   199: iconst_1
    //   200: istore_1
    //   201: aload_0
    //   202: getfield goneStartMargin : I
    //   205: istore #4
    //   207: iload #4
    //   209: iconst_m1
    //   210: if_icmpeq -> 219
    //   213: aload_0
    //   214: iload #4
    //   216: putfield resolveGoneRightMargin : I
    //   219: aload_0
    //   220: getfield goneEndMargin : I
    //   223: istore #4
    //   225: iload #4
    //   227: iconst_m1
    //   228: if_icmpeq -> 237
    //   231: aload_0
    //   232: iload #4
    //   234: putfield resolveGoneLeftMargin : I
    //   237: iload_1
    //   238: ifeq -> 251
    //   241: aload_0
    //   242: fconst_1
    //   243: aload_0
    //   244: getfield horizontalBias : F
    //   247: fsub
    //   248: putfield resolvedHorizontalBias : F
    //   251: aload_0
    //   252: getfield isGuideline : Z
    //   255: ifeq -> 449
    //   258: aload_0
    //   259: getfield orientation : I
    //   262: iconst_1
    //   263: if_icmpne -> 449
    //   266: aload_0
    //   267: getfield guidePercent : F
    //   270: fstore #6
    //   272: fload #6
    //   274: ldc -1.0
    //   276: fcmpl
    //   277: ifeq -> 301
    //   280: aload_0
    //   281: fconst_1
    //   282: fload #6
    //   284: fsub
    //   285: putfield resolvedGuidePercent : F
    //   288: aload_0
    //   289: iconst_m1
    //   290: putfield resolvedGuideBegin : I
    //   293: aload_0
    //   294: iconst_m1
    //   295: putfield resolvedGuideEnd : I
    //   298: goto -> 449
    //   301: aload_0
    //   302: getfield guideBegin : I
    //   305: istore_1
    //   306: iload_1
    //   307: iconst_m1
    //   308: if_icmpeq -> 330
    //   311: aload_0
    //   312: iload_1
    //   313: putfield resolvedGuideEnd : I
    //   316: aload_0
    //   317: iconst_m1
    //   318: putfield resolvedGuideBegin : I
    //   321: aload_0
    //   322: ldc -1.0
    //   324: putfield resolvedGuidePercent : F
    //   327: goto -> 449
    //   330: aload_0
    //   331: getfield guideEnd : I
    //   334: istore_1
    //   335: iload_1
    //   336: iconst_m1
    //   337: if_icmpeq -> 449
    //   340: aload_0
    //   341: iload_1
    //   342: putfield resolvedGuideBegin : I
    //   345: aload_0
    //   346: iconst_m1
    //   347: putfield resolvedGuideEnd : I
    //   350: aload_0
    //   351: ldc -1.0
    //   353: putfield resolvedGuidePercent : F
    //   356: goto -> 449
    //   359: aload_0
    //   360: getfield startToEnd : I
    //   363: istore_1
    //   364: iload_1
    //   365: iconst_m1
    //   366: if_icmpeq -> 374
    //   369: aload_0
    //   370: iload_1
    //   371: putfield resolvedLeftToRight : I
    //   374: aload_0
    //   375: getfield startToStart : I
    //   378: istore_1
    //   379: iload_1
    //   380: iconst_m1
    //   381: if_icmpeq -> 389
    //   384: aload_0
    //   385: iload_1
    //   386: putfield resolvedLeftToLeft : I
    //   389: aload_0
    //   390: getfield endToStart : I
    //   393: istore_1
    //   394: iload_1
    //   395: iconst_m1
    //   396: if_icmpeq -> 404
    //   399: aload_0
    //   400: iload_1
    //   401: putfield resolvedRightToLeft : I
    //   404: aload_0
    //   405: getfield endToEnd : I
    //   408: istore_1
    //   409: iload_1
    //   410: iconst_m1
    //   411: if_icmpeq -> 419
    //   414: aload_0
    //   415: iload_1
    //   416: putfield resolvedRightToRight : I
    //   419: aload_0
    //   420: getfield goneStartMargin : I
    //   423: istore_1
    //   424: iload_1
    //   425: iconst_m1
    //   426: if_icmpeq -> 434
    //   429: aload_0
    //   430: iload_1
    //   431: putfield resolveGoneLeftMargin : I
    //   434: aload_0
    //   435: getfield goneEndMargin : I
    //   438: istore_1
    //   439: iload_1
    //   440: iconst_m1
    //   441: if_icmpeq -> 449
    //   444: aload_0
    //   445: iload_1
    //   446: putfield resolveGoneRightMargin : I
    //   449: aload_0
    //   450: getfield endToStart : I
    //   453: iconst_m1
    //   454: if_icmpne -> 611
    //   457: aload_0
    //   458: getfield endToEnd : I
    //   461: iconst_m1
    //   462: if_icmpne -> 611
    //   465: aload_0
    //   466: getfield startToStart : I
    //   469: iconst_m1
    //   470: if_icmpne -> 611
    //   473: aload_0
    //   474: getfield startToEnd : I
    //   477: iconst_m1
    //   478: if_icmpne -> 611
    //   481: aload_0
    //   482: getfield rightToLeft : I
    //   485: istore_1
    //   486: iload_1
    //   487: iconst_m1
    //   488: if_icmpeq -> 515
    //   491: aload_0
    //   492: iload_1
    //   493: putfield resolvedRightToLeft : I
    //   496: aload_0
    //   497: getfield rightMargin : I
    //   500: ifgt -> 546
    //   503: iload_3
    //   504: ifle -> 546
    //   507: aload_0
    //   508: iload_3
    //   509: putfield rightMargin : I
    //   512: goto -> 546
    //   515: aload_0
    //   516: getfield rightToRight : I
    //   519: istore_1
    //   520: iload_1
    //   521: iconst_m1
    //   522: if_icmpeq -> 546
    //   525: aload_0
    //   526: iload_1
    //   527: putfield resolvedRightToRight : I
    //   530: aload_0
    //   531: getfield rightMargin : I
    //   534: ifgt -> 546
    //   537: iload_3
    //   538: ifle -> 546
    //   541: aload_0
    //   542: iload_3
    //   543: putfield rightMargin : I
    //   546: aload_0
    //   547: getfield leftToLeft : I
    //   550: istore_1
    //   551: iload_1
    //   552: iconst_m1
    //   553: if_icmpeq -> 580
    //   556: aload_0
    //   557: iload_1
    //   558: putfield resolvedLeftToLeft : I
    //   561: aload_0
    //   562: getfield leftMargin : I
    //   565: ifgt -> 611
    //   568: iload_2
    //   569: ifle -> 611
    //   572: aload_0
    //   573: iload_2
    //   574: putfield leftMargin : I
    //   577: goto -> 611
    //   580: aload_0
    //   581: getfield leftToRight : I
    //   584: istore_1
    //   585: iload_1
    //   586: iconst_m1
    //   587: if_icmpeq -> 611
    //   590: aload_0
    //   591: iload_1
    //   592: putfield resolvedLeftToRight : I
    //   595: aload_0
    //   596: getfield leftMargin : I
    //   599: ifgt -> 611
    //   602: iload_2
    //   603: ifle -> 611
    //   606: aload_0
    //   607: iload_2
    //   608: putfield leftMargin : I
    //   611: return
  }
  
  public void validate() {
    this.isGuideline = false;
    this.horizontalDimensionFixed = true;
    this.verticalDimensionFixed = true;
    if (this.width == -2 && this.constrainedWidth) {
      this.horizontalDimensionFixed = false;
      this.matchConstraintDefaultWidth = 1;
    } 
    if (this.height == -2 && this.constrainedHeight) {
      this.verticalDimensionFixed = false;
      this.matchConstraintDefaultHeight = 1;
    } 
    if (this.width == 0 || this.width == -1) {
      this.horizontalDimensionFixed = false;
      if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
        this.width = -2;
        this.constrainedWidth = true;
      } 
    } 
    if (this.height == 0 || this.height == -1) {
      this.verticalDimensionFixed = false;
      if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
        this.height = -2;
        this.constrainedHeight = true;
      } 
    } 
    if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
      this.isGuideline = true;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (!(this.widget instanceof Guideline))
        this.widget = (ConstraintWidget)new Guideline(); 
      ((Guideline)this.widget).setOrientation(this.orientation);
    } 
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map = new SparseIntArray();
    
    static {
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
    }
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\ConstraintLayout$LayoutParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */