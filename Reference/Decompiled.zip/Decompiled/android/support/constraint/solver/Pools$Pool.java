package android.support.constraint.solver;

interface Pool<T> {
  T acquire();
  
  boolean release(T paramT);
  
  void releaseAll(T[] paramArrayOfT, int paramInt);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\Pools$Pool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */