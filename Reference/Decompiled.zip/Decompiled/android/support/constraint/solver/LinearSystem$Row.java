package android.support.constraint.solver;

interface Row {
  void addError(SolverVariable paramSolverVariable);
  
  void clear();
  
  SolverVariable getKey();
  
  SolverVariable getPivotCandidate(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean);
  
  void initFromRow(Row paramRow);
  
  boolean isEmpty();
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\LinearSystem$Row.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */