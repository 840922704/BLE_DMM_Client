package android.support.constraint.solver.widgets;

class VerticalSlice {
  int alignment = 1;
  
  ConstraintWidget left;
  
  int padding;
  
  ConstraintWidget right;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\widgets\ConstraintTableLayout$VerticalSlice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */