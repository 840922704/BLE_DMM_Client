package android.support.constraint.solver.widgets;

public enum DimensionBehaviour {
  FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
  
  static {
    MATCH_CONSTRAINT = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
    MATCH_PARENT = new DimensionBehaviour("MATCH_PARENT", 3);
    $VALUES = new DimensionBehaviour[] { FIXED, WRAP_CONTENT, MATCH_CONSTRAINT, MATCH_PARENT };
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\widgets\ConstraintWidget$DimensionBehaviour.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */