package android.support.constraint.solver.widgets;

public enum ContentAlignment {
  BEGIN, BOTTOM, END, LEFT, MIDDLE, RIGHT, TOP, VERTICAL_MIDDLE;
  
  static {
    END = new ContentAlignment("END", 2);
    TOP = new ContentAlignment("TOP", 3);
    VERTICAL_MIDDLE = new ContentAlignment("VERTICAL_MIDDLE", 4);
    BOTTOM = new ContentAlignment("BOTTOM", 5);
    LEFT = new ContentAlignment("LEFT", 6);
    RIGHT = new ContentAlignment("RIGHT", 7);
    $VALUES = new ContentAlignment[] { BEGIN, MIDDLE, END, TOP, VERTICAL_MIDDLE, BOTTOM, LEFT, RIGHT };
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\widgets\ConstraintWidget$ContentAlignment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */