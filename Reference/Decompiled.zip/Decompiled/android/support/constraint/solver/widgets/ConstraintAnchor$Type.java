package android.support.constraint.solver.widgets;

public enum Type {
  BASELINE, BOTTOM, CENTER, CENTER_X, CENTER_Y, LEFT, NONE, RIGHT, TOP;
  
  static {
    LEFT = new Type("LEFT", 1);
    TOP = new Type("TOP", 2);
    RIGHT = new Type("RIGHT", 3);
    BOTTOM = new Type("BOTTOM", 4);
    BASELINE = new Type("BASELINE", 5);
    CENTER = new Type("CENTER", 6);
    CENTER_X = new Type("CENTER_X", 7);
    CENTER_Y = new Type("CENTER_Y", 8);
    $VALUES = new Type[] { NONE, LEFT, TOP, RIGHT, BOTTOM, BASELINE, CENTER, CENTER_X, CENTER_Y };
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\widgets\ConstraintAnchor$Type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */