package android.support.constraint.solver.widgets;

public enum ConnectionType {
  RELAXED, STRICT;
  
  static {
    $VALUES = new ConnectionType[] { RELAXED, STRICT };
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\solver\widgets\ConstraintAnchor$ConnectionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */