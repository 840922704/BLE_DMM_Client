package android.support.constraint;

public final class attr {
  public static final int barrierAllowsGoneWidgets = 2130903095;
  
  public static final int barrierDirection = 2130903096;
  
  public static final int chainUseRtl = 2130903138;
  
  public static final int constraintSet = 2130903193;
  
  public static final int constraint_referenced_ids = 2130903194;
  
  public static final int content = 2130903195;
  
  public static final int emptyVisibility = 2130903236;
  
  public static final int layout_constrainedHeight = 2130903329;
  
  public static final int layout_constrainedWidth = 2130903330;
  
  public static final int layout_constraintBaseline_creator = 2130903331;
  
  public static final int layout_constraintBaseline_toBaselineOf = 2130903332;
  
  public static final int layout_constraintBottom_creator = 2130903333;
  
  public static final int layout_constraintBottom_toBottomOf = 2130903334;
  
  public static final int layout_constraintBottom_toTopOf = 2130903335;
  
  public static final int layout_constraintCircle = 2130903336;
  
  public static final int layout_constraintCircleAngle = 2130903337;
  
  public static final int layout_constraintCircleRadius = 2130903338;
  
  public static final int layout_constraintDimensionRatio = 2130903339;
  
  public static final int layout_constraintEnd_toEndOf = 2130903340;
  
  public static final int layout_constraintEnd_toStartOf = 2130903341;
  
  public static final int layout_constraintGuide_begin = 2130903342;
  
  public static final int layout_constraintGuide_end = 2130903343;
  
  public static final int layout_constraintGuide_percent = 2130903344;
  
  public static final int layout_constraintHeight_default = 2130903345;
  
  public static final int layout_constraintHeight_max = 2130903346;
  
  public static final int layout_constraintHeight_min = 2130903347;
  
  public static final int layout_constraintHeight_percent = 2130903348;
  
  public static final int layout_constraintHorizontal_bias = 2130903349;
  
  public static final int layout_constraintHorizontal_chainStyle = 2130903350;
  
  public static final int layout_constraintHorizontal_weight = 2130903351;
  
  public static final int layout_constraintLeft_creator = 2130903352;
  
  public static final int layout_constraintLeft_toLeftOf = 2130903353;
  
  public static final int layout_constraintLeft_toRightOf = 2130903354;
  
  public static final int layout_constraintRight_creator = 2130903355;
  
  public static final int layout_constraintRight_toLeftOf = 2130903356;
  
  public static final int layout_constraintRight_toRightOf = 2130903357;
  
  public static final int layout_constraintStart_toEndOf = 2130903358;
  
  public static final int layout_constraintStart_toStartOf = 2130903359;
  
  public static final int layout_constraintTop_creator = 2130903360;
  
  public static final int layout_constraintTop_toBottomOf = 2130903361;
  
  public static final int layout_constraintTop_toTopOf = 2130903362;
  
  public static final int layout_constraintVertical_bias = 2130903363;
  
  public static final int layout_constraintVertical_chainStyle = 2130903364;
  
  public static final int layout_constraintVertical_weight = 2130903365;
  
  public static final int layout_constraintWidth_default = 2130903366;
  
  public static final int layout_constraintWidth_max = 2130903367;
  
  public static final int layout_constraintWidth_min = 2130903368;
  
  public static final int layout_constraintWidth_percent = 2130903369;
  
  public static final int layout_editor_absoluteX = 2130903371;
  
  public static final int layout_editor_absoluteY = 2130903372;
  
  public static final int layout_goneMarginBottom = 2130903373;
  
  public static final int layout_goneMarginEnd = 2130903374;
  
  public static final int layout_goneMarginLeft = 2130903375;
  
  public static final int layout_goneMarginRight = 2130903376;
  
  public static final int layout_goneMarginStart = 2130903377;
  
  public static final int layout_goneMarginTop = 2130903378;
  
  public static final int layout_optimizationLevel = 2130903381;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\R$attr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */