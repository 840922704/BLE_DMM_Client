package android.support.constraint;

import android.os.Build;
import java.util.Arrays;

class Constraint {
  static final int UNSET = -1;
  
  public float alpha = 1.0F;
  
  public boolean applyElevation = false;
  
  public int baselineToBaseline = -1;
  
  public int bottomMargin = -1;
  
  public int bottomToBottom = -1;
  
  public int bottomToTop = -1;
  
  public float circleAngle = 0.0F;
  
  public int circleConstraint = -1;
  
  public int circleRadius = 0;
  
  public boolean constrainedHeight = false;
  
  public boolean constrainedWidth = false;
  
  public String dimensionRatio = null;
  
  public int editorAbsoluteX = -1;
  
  public int editorAbsoluteY = -1;
  
  public float elevation = 0.0F;
  
  public int endMargin = -1;
  
  public int endToEnd = -1;
  
  public int endToStart = -1;
  
  public int goneBottomMargin = -1;
  
  public int goneEndMargin = -1;
  
  public int goneLeftMargin = -1;
  
  public int goneRightMargin = -1;
  
  public int goneStartMargin = -1;
  
  public int goneTopMargin = -1;
  
  public int guideBegin = -1;
  
  public int guideEnd = -1;
  
  public float guidePercent = -1.0F;
  
  public int heightDefault = 0;
  
  public int heightMax = -1;
  
  public int heightMin = -1;
  
  public float heightPercent = 1.0F;
  
  public float horizontalBias = 0.5F;
  
  public int horizontalChainStyle = 0;
  
  public float horizontalWeight = 0.0F;
  
  public int leftMargin = -1;
  
  public int leftToLeft = -1;
  
  public int leftToRight = -1;
  
  public boolean mBarrierAllowsGoneWidgets = false;
  
  public int mBarrierDirection = -1;
  
  public int mHeight;
  
  public int mHelperType = -1;
  
  boolean mIsGuideline = false;
  
  public String mReferenceIdString;
  
  public int[] mReferenceIds;
  
  int mViewId;
  
  public int mWidth;
  
  public int orientation = -1;
  
  public int rightMargin = -1;
  
  public int rightToLeft = -1;
  
  public int rightToRight = -1;
  
  public float rotation = 0.0F;
  
  public float rotationX = 0.0F;
  
  public float rotationY = 0.0F;
  
  public float scaleX = 1.0F;
  
  public float scaleY = 1.0F;
  
  public int startMargin = -1;
  
  public int startToEnd = -1;
  
  public int startToStart = -1;
  
  public int topMargin = -1;
  
  public int topToBottom = -1;
  
  public int topToTop = -1;
  
  public float transformPivotX = Float.NaN;
  
  public float transformPivotY = Float.NaN;
  
  public float translationX = 0.0F;
  
  public float translationY = 0.0F;
  
  public float translationZ = 0.0F;
  
  public float verticalBias = 0.5F;
  
  public int verticalChainStyle = 0;
  
  public float verticalWeight = 0.0F;
  
  public int visibility = 0;
  
  public int widthDefault = 0;
  
  public int widthMax = -1;
  
  public int widthMin = -1;
  
  public float widthPercent = 1.0F;
  
  private Constraint() {}
  
  private void fillFrom(int paramInt, ConstraintLayout.LayoutParams paramLayoutParams) {
    this.mViewId = paramInt;
    this.leftToLeft = paramLayoutParams.leftToLeft;
    this.leftToRight = paramLayoutParams.leftToRight;
    this.rightToLeft = paramLayoutParams.rightToLeft;
    this.rightToRight = paramLayoutParams.rightToRight;
    this.topToTop = paramLayoutParams.topToTop;
    this.topToBottom = paramLayoutParams.topToBottom;
    this.bottomToTop = paramLayoutParams.bottomToTop;
    this.bottomToBottom = paramLayoutParams.bottomToBottom;
    this.baselineToBaseline = paramLayoutParams.baselineToBaseline;
    this.startToEnd = paramLayoutParams.startToEnd;
    this.startToStart = paramLayoutParams.startToStart;
    this.endToStart = paramLayoutParams.endToStart;
    this.endToEnd = paramLayoutParams.endToEnd;
    this.horizontalBias = paramLayoutParams.horizontalBias;
    this.verticalBias = paramLayoutParams.verticalBias;
    this.dimensionRatio = paramLayoutParams.dimensionRatio;
    this.circleConstraint = paramLayoutParams.circleConstraint;
    this.circleRadius = paramLayoutParams.circleRadius;
    this.circleAngle = paramLayoutParams.circleAngle;
    this.editorAbsoluteX = paramLayoutParams.editorAbsoluteX;
    this.editorAbsoluteY = paramLayoutParams.editorAbsoluteY;
    this.orientation = paramLayoutParams.orientation;
    this.guidePercent = paramLayoutParams.guidePercent;
    this.guideBegin = paramLayoutParams.guideBegin;
    this.guideEnd = paramLayoutParams.guideEnd;
    this.mWidth = paramLayoutParams.width;
    this.mHeight = paramLayoutParams.height;
    this.leftMargin = paramLayoutParams.leftMargin;
    this.rightMargin = paramLayoutParams.rightMargin;
    this.topMargin = paramLayoutParams.topMargin;
    this.bottomMargin = paramLayoutParams.bottomMargin;
    this.verticalWeight = paramLayoutParams.verticalWeight;
    this.horizontalWeight = paramLayoutParams.horizontalWeight;
    this.verticalChainStyle = paramLayoutParams.verticalChainStyle;
    this.horizontalChainStyle = paramLayoutParams.horizontalChainStyle;
    this.constrainedWidth = paramLayoutParams.constrainedWidth;
    this.constrainedHeight = paramLayoutParams.constrainedHeight;
    this.widthDefault = paramLayoutParams.matchConstraintDefaultWidth;
    this.heightDefault = paramLayoutParams.matchConstraintDefaultHeight;
    this.constrainedWidth = paramLayoutParams.constrainedWidth;
    this.widthMax = paramLayoutParams.matchConstraintMaxWidth;
    this.heightMax = paramLayoutParams.matchConstraintMaxHeight;
    this.widthMin = paramLayoutParams.matchConstraintMinWidth;
    this.heightMin = paramLayoutParams.matchConstraintMinHeight;
    this.widthPercent = paramLayoutParams.matchConstraintPercentWidth;
    this.heightPercent = paramLayoutParams.matchConstraintPercentHeight;
    if (Build.VERSION.SDK_INT >= 17) {
      this.endMargin = paramLayoutParams.getMarginEnd();
      this.startMargin = paramLayoutParams.getMarginStart();
    } 
  }
  
  private void fillFromConstraints(int paramInt, Constraints.LayoutParams paramLayoutParams) {
    fillFrom(paramInt, paramLayoutParams);
    this.alpha = paramLayoutParams.alpha;
    this.rotation = paramLayoutParams.rotation;
    this.rotationX = paramLayoutParams.rotationX;
    this.rotationY = paramLayoutParams.rotationY;
    this.scaleX = paramLayoutParams.scaleX;
    this.scaleY = paramLayoutParams.scaleY;
    this.transformPivotX = paramLayoutParams.transformPivotX;
    this.transformPivotY = paramLayoutParams.transformPivotY;
    this.translationX = paramLayoutParams.translationX;
    this.translationY = paramLayoutParams.translationY;
    this.translationZ = paramLayoutParams.translationZ;
    this.elevation = paramLayoutParams.elevation;
    this.applyElevation = paramLayoutParams.applyElevation;
  }
  
  private void fillFromConstraints(ConstraintHelper paramConstraintHelper, int paramInt, Constraints.LayoutParams paramLayoutParams) {
    fillFromConstraints(paramInt, paramLayoutParams);
    if (paramConstraintHelper instanceof Barrier) {
      this.mHelperType = 1;
      paramConstraintHelper = paramConstraintHelper;
      this.mBarrierDirection = paramConstraintHelper.getType();
      this.mReferenceIds = paramConstraintHelper.getReferencedIds();
    } 
  }
  
  public void applyTo(ConstraintLayout.LayoutParams paramLayoutParams) {
    paramLayoutParams.leftToLeft = this.leftToLeft;
    paramLayoutParams.leftToRight = this.leftToRight;
    paramLayoutParams.rightToLeft = this.rightToLeft;
    paramLayoutParams.rightToRight = this.rightToRight;
    paramLayoutParams.topToTop = this.topToTop;
    paramLayoutParams.topToBottom = this.topToBottom;
    paramLayoutParams.bottomToTop = this.bottomToTop;
    paramLayoutParams.bottomToBottom = this.bottomToBottom;
    paramLayoutParams.baselineToBaseline = this.baselineToBaseline;
    paramLayoutParams.startToEnd = this.startToEnd;
    paramLayoutParams.startToStart = this.startToStart;
    paramLayoutParams.endToStart = this.endToStart;
    paramLayoutParams.endToEnd = this.endToEnd;
    paramLayoutParams.leftMargin = this.leftMargin;
    paramLayoutParams.rightMargin = this.rightMargin;
    paramLayoutParams.topMargin = this.topMargin;
    paramLayoutParams.bottomMargin = this.bottomMargin;
    paramLayoutParams.goneStartMargin = this.goneStartMargin;
    paramLayoutParams.goneEndMargin = this.goneEndMargin;
    paramLayoutParams.horizontalBias = this.horizontalBias;
    paramLayoutParams.verticalBias = this.verticalBias;
    paramLayoutParams.circleConstraint = this.circleConstraint;
    paramLayoutParams.circleRadius = this.circleRadius;
    paramLayoutParams.circleAngle = this.circleAngle;
    paramLayoutParams.dimensionRatio = this.dimensionRatio;
    paramLayoutParams.editorAbsoluteX = this.editorAbsoluteX;
    paramLayoutParams.editorAbsoluteY = this.editorAbsoluteY;
    paramLayoutParams.verticalWeight = this.verticalWeight;
    paramLayoutParams.horizontalWeight = this.horizontalWeight;
    paramLayoutParams.verticalChainStyle = this.verticalChainStyle;
    paramLayoutParams.horizontalChainStyle = this.horizontalChainStyle;
    paramLayoutParams.constrainedWidth = this.constrainedWidth;
    paramLayoutParams.constrainedHeight = this.constrainedHeight;
    paramLayoutParams.matchConstraintDefaultWidth = this.widthDefault;
    paramLayoutParams.matchConstraintDefaultHeight = this.heightDefault;
    paramLayoutParams.matchConstraintMaxWidth = this.widthMax;
    paramLayoutParams.matchConstraintMaxHeight = this.heightMax;
    paramLayoutParams.matchConstraintMinWidth = this.widthMin;
    paramLayoutParams.matchConstraintMinHeight = this.heightMin;
    paramLayoutParams.matchConstraintPercentWidth = this.widthPercent;
    paramLayoutParams.matchConstraintPercentHeight = this.heightPercent;
    paramLayoutParams.orientation = this.orientation;
    paramLayoutParams.guidePercent = this.guidePercent;
    paramLayoutParams.guideBegin = this.guideBegin;
    paramLayoutParams.guideEnd = this.guideEnd;
    paramLayoutParams.width = this.mWidth;
    paramLayoutParams.height = this.mHeight;
    if (Build.VERSION.SDK_INT >= 17) {
      paramLayoutParams.setMarginStart(this.startMargin);
      paramLayoutParams.setMarginEnd(this.endMargin);
    } 
    paramLayoutParams.validate();
  }
  
  public Constraint clone() {
    Constraint constraint = new Constraint();
    constraint.mIsGuideline = this.mIsGuideline;
    constraint.mWidth = this.mWidth;
    constraint.mHeight = this.mHeight;
    constraint.guideBegin = this.guideBegin;
    constraint.guideEnd = this.guideEnd;
    constraint.guidePercent = this.guidePercent;
    constraint.leftToLeft = this.leftToLeft;
    constraint.leftToRight = this.leftToRight;
    constraint.rightToLeft = this.rightToLeft;
    constraint.rightToRight = this.rightToRight;
    constraint.topToTop = this.topToTop;
    constraint.topToBottom = this.topToBottom;
    constraint.bottomToTop = this.bottomToTop;
    constraint.bottomToBottom = this.bottomToBottom;
    constraint.baselineToBaseline = this.baselineToBaseline;
    constraint.startToEnd = this.startToEnd;
    constraint.startToStart = this.startToStart;
    constraint.endToStart = this.endToStart;
    constraint.endToEnd = this.endToEnd;
    constraint.horizontalBias = this.horizontalBias;
    constraint.verticalBias = this.verticalBias;
    constraint.dimensionRatio = this.dimensionRatio;
    constraint.editorAbsoluteX = this.editorAbsoluteX;
    constraint.editorAbsoluteY = this.editorAbsoluteY;
    constraint.horizontalBias = this.horizontalBias;
    constraint.horizontalBias = this.horizontalBias;
    constraint.horizontalBias = this.horizontalBias;
    constraint.horizontalBias = this.horizontalBias;
    constraint.horizontalBias = this.horizontalBias;
    constraint.orientation = this.orientation;
    constraint.leftMargin = this.leftMargin;
    constraint.rightMargin = this.rightMargin;
    constraint.topMargin = this.topMargin;
    constraint.bottomMargin = this.bottomMargin;
    constraint.endMargin = this.endMargin;
    constraint.startMargin = this.startMargin;
    constraint.visibility = this.visibility;
    constraint.goneLeftMargin = this.goneLeftMargin;
    constraint.goneTopMargin = this.goneTopMargin;
    constraint.goneRightMargin = this.goneRightMargin;
    constraint.goneBottomMargin = this.goneBottomMargin;
    constraint.goneEndMargin = this.goneEndMargin;
    constraint.goneStartMargin = this.goneStartMargin;
    constraint.verticalWeight = this.verticalWeight;
    constraint.horizontalWeight = this.horizontalWeight;
    constraint.horizontalChainStyle = this.horizontalChainStyle;
    constraint.verticalChainStyle = this.verticalChainStyle;
    constraint.alpha = this.alpha;
    constraint.applyElevation = this.applyElevation;
    constraint.elevation = this.elevation;
    constraint.rotation = this.rotation;
    constraint.rotationX = this.rotationX;
    constraint.rotationY = this.rotationY;
    constraint.scaleX = this.scaleX;
    constraint.scaleY = this.scaleY;
    constraint.transformPivotX = this.transformPivotX;
    constraint.transformPivotY = this.transformPivotY;
    constraint.translationX = this.translationX;
    constraint.translationY = this.translationY;
    constraint.translationZ = this.translationZ;
    constraint.constrainedWidth = this.constrainedWidth;
    constraint.constrainedHeight = this.constrainedHeight;
    constraint.widthDefault = this.widthDefault;
    constraint.heightDefault = this.heightDefault;
    constraint.widthMax = this.widthMax;
    constraint.heightMax = this.heightMax;
    constraint.widthMin = this.widthMin;
    constraint.heightMin = this.heightMin;
    constraint.widthPercent = this.widthPercent;
    constraint.heightPercent = this.heightPercent;
    constraint.mBarrierDirection = this.mBarrierDirection;
    constraint.mHelperType = this.mHelperType;
    int[] arrayOfInt = this.mReferenceIds;
    if (arrayOfInt != null)
      constraint.mReferenceIds = Arrays.copyOf(arrayOfInt, arrayOfInt.length); 
    constraint.circleConstraint = this.circleConstraint;
    constraint.circleRadius = this.circleRadius;
    constraint.circleAngle = this.circleAngle;
    constraint.mBarrierAllowsGoneWidgets = this.mBarrierAllowsGoneWidgets;
    return constraint;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\constraint\ConstraintSet$Constraint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */