package android.support.compat;

public final class integer {
  public static final int status_bar_notification_info_maxnum = 2131296271;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\compat\R$integer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */