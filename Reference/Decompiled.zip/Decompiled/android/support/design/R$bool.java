package android.support.design;

public final class bool {
  public static final int abc_action_bar_embed_tabs = 2130968576;
  
  public static final int abc_allow_stacked_button_bar = 2130968577;
  
  public static final int abc_config_actionMenuItemAllCaps = 2130968578;
  
  public static final int mtrl_btn_textappearance_all_caps = 2130968579;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$bool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */