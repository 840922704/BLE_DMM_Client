package android.support.design;

public final class anim {
  public static final int abc_fade_in = 2130771968;
  
  public static final int abc_fade_out = 2130771969;
  
  public static final int abc_grow_fade_in_from_bottom = 2130771970;
  
  public static final int abc_popup_enter = 2130771971;
  
  public static final int abc_popup_exit = 2130771972;
  
  public static final int abc_shrink_fade_out_from_bottom = 2130771973;
  
  public static final int abc_slide_in_bottom = 2130771974;
  
  public static final int abc_slide_in_top = 2130771975;
  
  public static final int abc_slide_out_bottom = 2130771976;
  
  public static final int abc_slide_out_top = 2130771977;
  
  public static final int abc_tooltip_enter = 2130771978;
  
  public static final int abc_tooltip_exit = 2130771979;
  
  public static final int design_bottom_sheet_slide_in = 2130771980;
  
  public static final int design_bottom_sheet_slide_out = 2130771981;
  
  public static final int design_snackbar_in = 2130771982;
  
  public static final int design_snackbar_out = 2130771983;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$anim.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */