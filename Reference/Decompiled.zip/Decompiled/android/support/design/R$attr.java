package android.support.design;

public final class attr {
  public static final int actionBarDivider = 2130903040;
  
  public static final int actionBarItemBackground = 2130903041;
  
  public static final int actionBarPopupTheme = 2130903042;
  
  public static final int actionBarSize = 2130903043;
  
  public static final int actionBarSplitStyle = 2130903044;
  
  public static final int actionBarStyle = 2130903045;
  
  public static final int actionBarTabBarStyle = 2130903046;
  
  public static final int actionBarTabStyle = 2130903047;
  
  public static final int actionBarTabTextStyle = 2130903048;
  
  public static final int actionBarTheme = 2130903049;
  
  public static final int actionBarWidgetTheme = 2130903050;
  
  public static final int actionButtonStyle = 2130903051;
  
  public static final int actionDropDownStyle = 2130903052;
  
  public static final int actionLayout = 2130903053;
  
  public static final int actionMenuTextAppearance = 2130903054;
  
  public static final int actionMenuTextColor = 2130903055;
  
  public static final int actionModeBackground = 2130903056;
  
  public static final int actionModeCloseButtonStyle = 2130903057;
  
  public static final int actionModeCloseDrawable = 2130903058;
  
  public static final int actionModeCopyDrawable = 2130903059;
  
  public static final int actionModeCutDrawable = 2130903060;
  
  public static final int actionModeFindDrawable = 2130903061;
  
  public static final int actionModePasteDrawable = 2130903062;
  
  public static final int actionModePopupWindowStyle = 2130903063;
  
  public static final int actionModeSelectAllDrawable = 2130903064;
  
  public static final int actionModeShareDrawable = 2130903065;
  
  public static final int actionModeSplitBackground = 2130903066;
  
  public static final int actionModeStyle = 2130903067;
  
  public static final int actionModeWebSearchDrawable = 2130903068;
  
  public static final int actionOverflowButtonStyle = 2130903069;
  
  public static final int actionOverflowMenuStyle = 2130903070;
  
  public static final int actionProviderClass = 2130903071;
  
  public static final int actionViewClass = 2130903072;
  
  public static final int activityChooserViewStyle = 2130903073;
  
  public static final int alertDialogButtonGroupStyle = 2130903074;
  
  public static final int alertDialogCenterButtons = 2130903075;
  
  public static final int alertDialogStyle = 2130903076;
  
  public static final int alertDialogTheme = 2130903077;
  
  public static final int allowStacking = 2130903078;
  
  public static final int alpha = 2130903079;
  
  public static final int alphabeticModifiers = 2130903080;
  
  public static final int arrowHeadLength = 2130903081;
  
  public static final int arrowShaftLength = 2130903082;
  
  public static final int autoCompleteTextViewStyle = 2130903083;
  
  public static final int autoSizeMaxTextSize = 2130903084;
  
  public static final int autoSizeMinTextSize = 2130903085;
  
  public static final int autoSizePresetSizes = 2130903086;
  
  public static final int autoSizeStepGranularity = 2130903087;
  
  public static final int autoSizeTextType = 2130903088;
  
  public static final int background = 2130903089;
  
  public static final int backgroundSplit = 2130903090;
  
  public static final int backgroundStacked = 2130903091;
  
  public static final int backgroundTint = 2130903092;
  
  public static final int backgroundTintMode = 2130903093;
  
  public static final int barLength = 2130903094;
  
  public static final int behavior_autoHide = 2130903097;
  
  public static final int behavior_fitToContents = 2130903098;
  
  public static final int behavior_hideable = 2130903099;
  
  public static final int behavior_overlapTop = 2130903100;
  
  public static final int behavior_peekHeight = 2130903101;
  
  public static final int behavior_skipCollapsed = 2130903102;
  
  public static final int borderWidth = 2130903103;
  
  public static final int borderlessButtonStyle = 2130903104;
  
  public static final int bottomAppBarStyle = 2130903105;
  
  public static final int bottomNavigationStyle = 2130903106;
  
  public static final int bottomSheetDialogTheme = 2130903107;
  
  public static final int bottomSheetStyle = 2130903108;
  
  public static final int boxBackgroundColor = 2130903109;
  
  public static final int boxBackgroundMode = 2130903110;
  
  public static final int boxCollapsedPaddingTop = 2130903111;
  
  public static final int boxCornerRadiusBottomEnd = 2130903112;
  
  public static final int boxCornerRadiusBottomStart = 2130903113;
  
  public static final int boxCornerRadiusTopEnd = 2130903114;
  
  public static final int boxCornerRadiusTopStart = 2130903115;
  
  public static final int boxStrokeColor = 2130903116;
  
  public static final int boxStrokeWidth = 2130903117;
  
  public static final int buttonBarButtonStyle = 2130903118;
  
  public static final int buttonBarNegativeButtonStyle = 2130903119;
  
  public static final int buttonBarNeutralButtonStyle = 2130903120;
  
  public static final int buttonBarPositiveButtonStyle = 2130903121;
  
  public static final int buttonBarStyle = 2130903122;
  
  public static final int buttonGravity = 2130903123;
  
  public static final int buttonIconDimen = 2130903124;
  
  public static final int buttonPanelSideLayout = 2130903125;
  
  public static final int buttonStyle = 2130903127;
  
  public static final int buttonStyleSmall = 2130903128;
  
  public static final int buttonTint = 2130903129;
  
  public static final int buttonTintMode = 2130903130;
  
  public static final int cardBackgroundColor = 2130903131;
  
  public static final int cardCornerRadius = 2130903132;
  
  public static final int cardElevation = 2130903133;
  
  public static final int cardMaxElevation = 2130903134;
  
  public static final int cardPreventCornerOverlap = 2130903135;
  
  public static final int cardUseCompatPadding = 2130903136;
  
  public static final int cardViewStyle = 2130903137;
  
  public static final int checkboxStyle = 2130903139;
  
  public static final int checkedChip = 2130903141;
  
  public static final int checkedIcon = 2130903142;
  
  public static final int checkedIconEnabled = 2130903143;
  
  public static final int checkedIconVisible = 2130903144;
  
  public static final int checkedTextViewStyle = 2130903145;
  
  public static final int chipBackgroundColor = 2130903146;
  
  public static final int chipCornerRadius = 2130903147;
  
  public static final int chipEndPadding = 2130903148;
  
  public static final int chipGroupStyle = 2130903149;
  
  public static final int chipIcon = 2130903150;
  
  public static final int chipIconEnabled = 2130903151;
  
  public static final int chipIconSize = 2130903152;
  
  public static final int chipIconTint = 2130903153;
  
  public static final int chipIconVisible = 2130903154;
  
  public static final int chipMinHeight = 2130903155;
  
  public static final int chipSpacing = 2130903156;
  
  public static final int chipSpacingHorizontal = 2130903157;
  
  public static final int chipSpacingVertical = 2130903158;
  
  public static final int chipStandaloneStyle = 2130903159;
  
  public static final int chipStartPadding = 2130903160;
  
  public static final int chipStrokeColor = 2130903161;
  
  public static final int chipStrokeWidth = 2130903162;
  
  public static final int chipStyle = 2130903163;
  
  public static final int closeIcon = 2130903167;
  
  public static final int closeIconEnabled = 2130903168;
  
  public static final int closeIconEndPadding = 2130903169;
  
  public static final int closeIconSize = 2130903170;
  
  public static final int closeIconStartPadding = 2130903171;
  
  public static final int closeIconTint = 2130903172;
  
  public static final int closeIconVisible = 2130903173;
  
  public static final int closeItemLayout = 2130903174;
  
  public static final int collapseContentDescription = 2130903175;
  
  public static final int collapseIcon = 2130903176;
  
  public static final int collapsedTitleGravity = 2130903177;
  
  public static final int collapsedTitleTextAppearance = 2130903178;
  
  public static final int color = 2130903179;
  
  public static final int colorAccent = 2130903180;
  
  public static final int colorBackgroundFloating = 2130903181;
  
  public static final int colorButtonNormal = 2130903182;
  
  public static final int colorControlActivated = 2130903183;
  
  public static final int colorControlHighlight = 2130903184;
  
  public static final int colorControlNormal = 2130903185;
  
  public static final int colorError = 2130903186;
  
  public static final int colorPrimary = 2130903187;
  
  public static final int colorPrimaryDark = 2130903188;
  
  public static final int colorSecondary = 2130903190;
  
  public static final int colorSwitchThumbNormal = 2130903191;
  
  public static final int commitIcon = 2130903192;
  
  public static final int contentDescription = 2130903196;
  
  public static final int contentInsetEnd = 2130903197;
  
  public static final int contentInsetEndWithActions = 2130903198;
  
  public static final int contentInsetLeft = 2130903199;
  
  public static final int contentInsetRight = 2130903200;
  
  public static final int contentInsetStart = 2130903201;
  
  public static final int contentInsetStartWithNavigation = 2130903202;
  
  public static final int contentPadding = 2130903203;
  
  public static final int contentPaddingBottom = 2130903204;
  
  public static final int contentPaddingLeft = 2130903205;
  
  public static final int contentPaddingRight = 2130903206;
  
  public static final int contentPaddingTop = 2130903207;
  
  public static final int contentScrim = 2130903208;
  
  public static final int controlBackground = 2130903209;
  
  public static final int coordinatorLayoutStyle = 2130903210;
  
  public static final int cornerRadius = 2130903211;
  
  public static final int counterEnabled = 2130903212;
  
  public static final int counterMaxLength = 2130903213;
  
  public static final int counterOverflowTextAppearance = 2130903214;
  
  public static final int counterTextAppearance = 2130903215;
  
  public static final int customNavigationLayout = 2130903216;
  
  public static final int defaultQueryHint = 2130903217;
  
  public static final int dialogCornerRadius = 2130903219;
  
  public static final int dialogPreferredPadding = 2130903220;
  
  public static final int dialogTheme = 2130903221;
  
  public static final int displayOptions = 2130903222;
  
  public static final int divider = 2130903223;
  
  public static final int dividerHorizontal = 2130903224;
  
  public static final int dividerPadding = 2130903225;
  
  public static final int dividerVertical = 2130903226;
  
  public static final int drawableSize = 2130903228;
  
  public static final int drawerArrowStyle = 2130903229;
  
  public static final int dropDownListViewStyle = 2130903230;
  
  public static final int dropdownListPreferredItemHeight = 2130903231;
  
  public static final int editTextBackground = 2130903232;
  
  public static final int editTextColor = 2130903233;
  
  public static final int editTextStyle = 2130903234;
  
  public static final int elevation = 2130903235;
  
  public static final int enforceMaterialTheme = 2130903237;
  
  public static final int enforceTextAppearance = 2130903238;
  
  public static final int errorEnabled = 2130903239;
  
  public static final int errorTextAppearance = 2130903240;
  
  public static final int expandActivityOverflowButtonDrawable = 2130903241;
  
  public static final int expanded = 2130903242;
  
  public static final int expandedTitleGravity = 2130903243;
  
  public static final int expandedTitleMargin = 2130903244;
  
  public static final int expandedTitleMarginBottom = 2130903245;
  
  public static final int expandedTitleMarginEnd = 2130903246;
  
  public static final int expandedTitleMarginStart = 2130903247;
  
  public static final int expandedTitleMarginTop = 2130903248;
  
  public static final int expandedTitleTextAppearance = 2130903249;
  
  public static final int fabAlignmentMode = 2130903250;
  
  public static final int fabCradleMargin = 2130903251;
  
  public static final int fabCradleRoundedCornerRadius = 2130903252;
  
  public static final int fabCradleVerticalOffset = 2130903253;
  
  public static final int fabCustomSize = 2130903254;
  
  public static final int fabSize = 2130903255;
  
  public static final int fastScrollEnabled = 2130903256;
  
  public static final int fastScrollHorizontalThumbDrawable = 2130903257;
  
  public static final int fastScrollHorizontalTrackDrawable = 2130903258;
  
  public static final int fastScrollVerticalThumbDrawable = 2130903259;
  
  public static final int fastScrollVerticalTrackDrawable = 2130903260;
  
  public static final int firstBaselineToTopHeight = 2130903261;
  
  public static final int floatingActionButtonStyle = 2130903262;
  
  public static final int font = 2130903263;
  
  public static final int fontFamily = 2130903264;
  
  public static final int fontProviderAuthority = 2130903265;
  
  public static final int fontProviderCerts = 2130903266;
  
  public static final int fontProviderFetchStrategy = 2130903267;
  
  public static final int fontProviderFetchTimeout = 2130903268;
  
  public static final int fontProviderPackage = 2130903269;
  
  public static final int fontProviderQuery = 2130903270;
  
  public static final int fontStyle = 2130903271;
  
  public static final int fontVariationSettings = 2130903272;
  
  public static final int fontWeight = 2130903273;
  
  public static final int foregroundInsidePadding = 2130903274;
  
  public static final int gapBetweenBars = 2130903275;
  
  public static final int goIcon = 2130903276;
  
  public static final int headerLayout = 2130903277;
  
  public static final int height = 2130903278;
  
  public static final int helperText = 2130903279;
  
  public static final int helperTextEnabled = 2130903280;
  
  public static final int helperTextTextAppearance = 2130903281;
  
  public static final int hideMotionSpec = 2130903282;
  
  public static final int hideOnContentScroll = 2130903283;
  
  public static final int hideOnScroll = 2130903284;
  
  public static final int hintAnimationEnabled = 2130903285;
  
  public static final int hintEnabled = 2130903286;
  
  public static final int hintTextAppearance = 2130903287;
  
  public static final int homeAsUpIndicator = 2130903288;
  
  public static final int homeLayout = 2130903289;
  
  public static final int hoveredFocusedTranslationZ = 2130903290;
  
  public static final int icon = 2130903291;
  
  public static final int iconEndPadding = 2130903292;
  
  public static final int iconGravity = 2130903293;
  
  public static final int iconPadding = 2130903294;
  
  public static final int iconSize = 2130903295;
  
  public static final int iconStartPadding = 2130903296;
  
  public static final int iconTint = 2130903297;
  
  public static final int iconTintMode = 2130903298;
  
  public static final int iconifiedByDefault = 2130903299;
  
  public static final int imageButtonStyle = 2130903302;
  
  public static final int indeterminateProgressStyle = 2130903303;
  
  public static final int initialActivityCount = 2130903304;
  
  public static final int insetForeground = 2130903305;
  
  public static final int isLightTheme = 2130903306;
  
  public static final int itemBackground = 2130903307;
  
  public static final int itemHorizontalPadding = 2130903308;
  
  public static final int itemHorizontalTranslationEnabled = 2130903309;
  
  public static final int itemIconPadding = 2130903310;
  
  public static final int itemIconSize = 2130903311;
  
  public static final int itemIconTint = 2130903312;
  
  public static final int itemPadding = 2130903313;
  
  public static final int itemSpacing = 2130903314;
  
  public static final int itemTextAppearance = 2130903315;
  
  public static final int itemTextAppearanceActive = 2130903316;
  
  public static final int itemTextAppearanceInactive = 2130903317;
  
  public static final int itemTextColor = 2130903318;
  
  public static final int keylines = 2130903319;
  
  public static final int labelVisibilityMode = 2130903320;
  
  public static final int lastBaselineToBottomHeight = 2130903321;
  
  public static final int layout = 2130903322;
  
  public static final int layoutManager = 2130903323;
  
  public static final int layout_anchor = 2130903324;
  
  public static final int layout_anchorGravity = 2130903325;
  
  public static final int layout_behavior = 2130903326;
  
  public static final int layout_collapseMode = 2130903327;
  
  public static final int layout_collapseParallaxMultiplier = 2130903328;
  
  public static final int layout_dodgeInsetEdges = 2130903370;
  
  public static final int layout_insetEdge = 2130903379;
  
  public static final int layout_keyline = 2130903380;
  
  public static final int layout_scrollFlags = 2130903382;
  
  public static final int layout_scrollInterpolator = 2130903383;
  
  public static final int liftOnScroll = 2130903386;
  
  public static final int lineHeight = 2130903387;
  
  public static final int lineSpacing = 2130903389;
  
  public static final int listChoiceBackgroundIndicator = 2130903390;
  
  public static final int listDividerAlertDialog = 2130903391;
  
  public static final int listItemLayout = 2130903392;
  
  public static final int listLayout = 2130903393;
  
  public static final int listMenuViewStyle = 2130903394;
  
  public static final int listPopupWindowStyle = 2130903395;
  
  public static final int listPreferredItemHeight = 2130903396;
  
  public static final int listPreferredItemHeightLarge = 2130903397;
  
  public static final int listPreferredItemHeightSmall = 2130903398;
  
  public static final int listPreferredItemPaddingLeft = 2130903399;
  
  public static final int listPreferredItemPaddingRight = 2130903400;
  
  public static final int logo = 2130903401;
  
  public static final int logoDescription = 2130903402;
  
  public static final int materialButtonStyle = 2130903404;
  
  public static final int materialCardViewStyle = 2130903405;
  
  public static final int maxActionInlineWidth = 2130903406;
  
  public static final int maxButtonHeight = 2130903407;
  
  public static final int maxImageSize = 2130903408;
  
  public static final int measureWithLargestChild = 2130903409;
  
  public static final int menu = 2130903410;
  
  public static final int multiChoiceItemLayout = 2130903411;
  
  public static final int navigationContentDescription = 2130903412;
  
  public static final int navigationIcon = 2130903413;
  
  public static final int navigationMode = 2130903414;
  
  public static final int navigationViewStyle = 2130903415;
  
  public static final int numericModifiers = 2130903416;
  
  public static final int overlapAnchor = 2130903417;
  
  public static final int paddingBottomNoButtons = 2130903418;
  
  public static final int paddingEnd = 2130903419;
  
  public static final int paddingStart = 2130903420;
  
  public static final int paddingTopNoTitle = 2130903421;
  
  public static final int panelBackground = 2130903422;
  
  public static final int panelMenuListTheme = 2130903423;
  
  public static final int panelMenuListWidth = 2130903424;
  
  public static final int passwordToggleContentDescription = 2130903425;
  
  public static final int passwordToggleDrawable = 2130903426;
  
  public static final int passwordToggleEnabled = 2130903427;
  
  public static final int passwordToggleTint = 2130903428;
  
  public static final int passwordToggleTintMode = 2130903429;
  
  public static final int popupMenuStyle = 2130903430;
  
  public static final int popupTheme = 2130903431;
  
  public static final int popupWindowStyle = 2130903432;
  
  public static final int preserveIconSpacing = 2130903433;
  
  public static final int pressedTranslationZ = 2130903434;
  
  public static final int progressBarPadding = 2130903436;
  
  public static final int progressBarStyle = 2130903437;
  
  public static final int queryBackground = 2130903439;
  
  public static final int queryHint = 2130903440;
  
  public static final int radioButtonStyle = 2130903441;
  
  public static final int ratingBarStyle = 2130903442;
  
  public static final int ratingBarStyleIndicator = 2130903443;
  
  public static final int ratingBarStyleSmall = 2130903444;
  
  public static final int reverseLayout = 2130903445;
  
  public static final int rippleColor = 2130903446;
  
  public static final int scrimAnimationDuration = 2130903448;
  
  public static final int scrimBackground = 2130903449;
  
  public static final int scrimVisibleHeightTrigger = 2130903450;
  
  public static final int searchHintIcon = 2130903451;
  
  public static final int searchIcon = 2130903452;
  
  public static final int searchViewStyle = 2130903453;
  
  public static final int seekBarStyle = 2130903454;
  
  public static final int selectableItemBackground = 2130903455;
  
  public static final int selectableItemBackgroundBorderless = 2130903456;
  
  public static final int showAsAction = 2130903458;
  
  public static final int showDividers = 2130903459;
  
  public static final int showMotionSpec = 2130903460;
  
  public static final int showText = 2130903461;
  
  public static final int showTitle = 2130903462;
  
  public static final int singleChoiceItemLayout = 2130903463;
  
  public static final int singleLine = 2130903464;
  
  public static final int singleSelection = 2130903465;
  
  public static final int snackbarButtonStyle = 2130903466;
  
  public static final int snackbarStyle = 2130903467;
  
  public static final int spanCount = 2130903468;
  
  public static final int spinBars = 2130903469;
  
  public static final int spinnerDropDownItemStyle = 2130903470;
  
  public static final int spinnerStyle = 2130903471;
  
  public static final int splitTrack = 2130903472;
  
  public static final int srcCompat = 2130903473;
  
  public static final int stackFromEnd = 2130903539;
  
  public static final int state_above_anchor = 2130903540;
  
  public static final int state_collapsed = 2130903541;
  
  public static final int state_collapsible = 2130903542;
  
  public static final int state_liftable = 2130903543;
  
  public static final int state_lifted = 2130903544;
  
  public static final int statusBarBackground = 2130903545;
  
  public static final int statusBarScrim = 2130903546;
  
  public static final int strokeColor = 2130903547;
  
  public static final int strokeWidth = 2130903549;
  
  public static final int subMenuArrow = 2130903551;
  
  public static final int submitBackground = 2130903552;
  
  public static final int subtitle = 2130903553;
  
  public static final int subtitleTextAppearance = 2130903554;
  
  public static final int subtitleTextColor = 2130903555;
  
  public static final int subtitleTextStyle = 2130903556;
  
  public static final int suggestionRowLayout = 2130903557;
  
  public static final int switchMinWidth = 2130903558;
  
  public static final int switchPadding = 2130903559;
  
  public static final int switchStyle = 2130903560;
  
  public static final int switchTextAppearance = 2130903561;
  
  public static final int tabBackground = 2130903562;
  
  public static final int tabContentStart = 2130903563;
  
  public static final int tabGravity = 2130903564;
  
  public static final int tabIconTint = 2130903565;
  
  public static final int tabIconTintMode = 2130903566;
  
  public static final int tabIndicator = 2130903567;
  
  public static final int tabIndicatorAnimationDuration = 2130903568;
  
  public static final int tabIndicatorColor = 2130903569;
  
  public static final int tabIndicatorFullWidth = 2130903570;
  
  public static final int tabIndicatorGravity = 2130903571;
  
  public static final int tabIndicatorHeight = 2130903572;
  
  public static final int tabInlineLabel = 2130903573;
  
  public static final int tabMaxWidth = 2130903574;
  
  public static final int tabMinWidth = 2130903575;
  
  public static final int tabMode = 2130903576;
  
  public static final int tabPadding = 2130903577;
  
  public static final int tabPaddingBottom = 2130903578;
  
  public static final int tabPaddingEnd = 2130903579;
  
  public static final int tabPaddingStart = 2130903580;
  
  public static final int tabPaddingTop = 2130903581;
  
  public static final int tabRippleColor = 2130903582;
  
  public static final int tabSelectedTextColor = 2130903583;
  
  public static final int tabStyle = 2130903584;
  
  public static final int tabTextAppearance = 2130903585;
  
  public static final int tabTextColor = 2130903586;
  
  public static final int tabUnboundedRipple = 2130903587;
  
  public static final int textAllCaps = 2130903588;
  
  public static final int textAppearanceBody1 = 2130903589;
  
  public static final int textAppearanceBody2 = 2130903590;
  
  public static final int textAppearanceButton = 2130903591;
  
  public static final int textAppearanceCaption = 2130903592;
  
  public static final int textAppearanceHeadline1 = 2130903593;
  
  public static final int textAppearanceHeadline2 = 2130903594;
  
  public static final int textAppearanceHeadline3 = 2130903595;
  
  public static final int textAppearanceHeadline4 = 2130903596;
  
  public static final int textAppearanceHeadline5 = 2130903597;
  
  public static final int textAppearanceHeadline6 = 2130903598;
  
  public static final int textAppearanceLargePopupMenu = 2130903599;
  
  public static final int textAppearanceListItem = 2130903600;
  
  public static final int textAppearanceListItemSecondary = 2130903601;
  
  public static final int textAppearanceListItemSmall = 2130903602;
  
  public static final int textAppearanceOverline = 2130903603;
  
  public static final int textAppearancePopupMenuHeader = 2130903604;
  
  public static final int textAppearanceSearchResultSubtitle = 2130903605;
  
  public static final int textAppearanceSearchResultTitle = 2130903606;
  
  public static final int textAppearanceSmallPopupMenu = 2130903607;
  
  public static final int textAppearanceSubtitle1 = 2130903608;
  
  public static final int textAppearanceSubtitle2 = 2130903609;
  
  public static final int textColorAlertDialogListItem = 2130903610;
  
  public static final int textColorSearchUrl = 2130903611;
  
  public static final int textEndPadding = 2130903612;
  
  public static final int textInputStyle = 2130903613;
  
  public static final int textStartPadding = 2130903614;
  
  public static final int theme = 2130903615;
  
  public static final int thickness = 2130903616;
  
  public static final int thumbTextPadding = 2130903617;
  
  public static final int thumbTint = 2130903618;
  
  public static final int thumbTintMode = 2130903619;
  
  public static final int tickMark = 2130903620;
  
  public static final int tickMarkTint = 2130903621;
  
  public static final int tickMarkTintMode = 2130903622;
  
  public static final int tint = 2130903623;
  
  public static final int tintMode = 2130903624;
  
  public static final int title = 2130903625;
  
  public static final int titleEnabled = 2130903626;
  
  public static final int titleMargin = 2130903627;
  
  public static final int titleMarginBottom = 2130903628;
  
  public static final int titleMarginEnd = 2130903629;
  
  public static final int titleMarginStart = 2130903630;
  
  public static final int titleMarginTop = 2130903631;
  
  public static final int titleMargins = 2130903632;
  
  public static final int titleTextAppearance = 2130903633;
  
  public static final int titleTextColor = 2130903634;
  
  public static final int titleTextStyle = 2130903635;
  
  public static final int toolbarId = 2130903636;
  
  public static final int toolbarNavigationButtonStyle = 2130903637;
  
  public static final int toolbarStyle = 2130903638;
  
  public static final int tooltipForegroundColor = 2130903639;
  
  public static final int tooltipFrameBackground = 2130903640;
  
  public static final int tooltipText = 2130903641;
  
  public static final int track = 2130903642;
  
  public static final int trackTint = 2130903643;
  
  public static final int trackTintMode = 2130903644;
  
  public static final int ttcIndex = 2130903645;
  
  public static final int useCompatPadding = 2130903646;
  
  public static final int viewInflaterClass = 2130903647;
  
  public static final int voiceIcon = 2130903648;
  
  public static final int windowActionBar = 2130903649;
  
  public static final int windowActionBarOverlay = 2130903650;
  
  public static final int windowActionModeOverlay = 2130903651;
  
  public static final int windowFixedHeightMajor = 2130903652;
  
  public static final int windowFixedHeightMinor = 2130903653;
  
  public static final int windowFixedWidthMajor = 2130903654;
  
  public static final int windowFixedWidthMinor = 2130903655;
  
  public static final int windowMinWidthMajor = 2130903656;
  
  public static final int windowMinWidthMinor = 2130903657;
  
  public static final int windowNoTitle = 2130903658;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$attr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */