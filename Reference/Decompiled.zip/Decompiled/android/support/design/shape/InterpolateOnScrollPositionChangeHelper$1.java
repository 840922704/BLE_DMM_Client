package android.support.design.shape;

import android.view.ViewTreeObserver;

class null implements ViewTreeObserver.OnScrollChangedListener {
  public void onScrollChanged() {
    InterpolateOnScrollPositionChangeHelper.this.updateInterpolationForScreenPosition();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\InterpolateOnScrollPositionChangeHelper$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */