package android.support.design.shape;

import android.graphics.Matrix;
import android.graphics.Path;

public class PathQuadOperation extends ShapePath.PathOperation {
  public float controlX;
  
  public float controlY;
  
  public float endX;
  
  public float endY;
  
  public void applyToPath(Matrix paramMatrix, Path paramPath) {
    Matrix matrix = this.matrix;
    paramMatrix.invert(matrix);
    paramPath.transform(matrix);
    paramPath.quadTo(this.controlX, this.controlY, this.endX, this.endY);
    paramPath.transform(paramMatrix);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\ShapePath$PathQuadOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */