package android.support.design.shape;

public class CornerTreatment {
  public void getCornerPath(float paramFloat1, float paramFloat2, ShapePath paramShapePath) {}
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\CornerTreatment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */