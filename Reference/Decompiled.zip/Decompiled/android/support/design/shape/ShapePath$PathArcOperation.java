package android.support.design.shape;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;

public class PathArcOperation extends ShapePath.PathOperation {
  private static final RectF rectF = new RectF();
  
  public float bottom;
  
  public float left;
  
  public float right;
  
  public float startAngle;
  
  public float sweepAngle;
  
  public float top;
  
  public PathArcOperation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.left = paramFloat1;
    this.top = paramFloat2;
    this.right = paramFloat3;
    this.bottom = paramFloat4;
  }
  
  public void applyToPath(Matrix paramMatrix, Path paramPath) {
    Matrix matrix = this.matrix;
    paramMatrix.invert(matrix);
    paramPath.transform(matrix);
    rectF.set(this.left, this.top, this.right, this.bottom);
    paramPath.arcTo(rectF, this.startAngle, this.sweepAngle, false);
    paramPath.transform(paramMatrix);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\ShapePath$PathArcOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */