package android.support.design.shape;

public class TriangleEdgeTreatment extends EdgeTreatment {
  private final boolean inside;
  
  private final float size;
  
  public TriangleEdgeTreatment(float paramFloat, boolean paramBoolean) {
    this.size = paramFloat;
    this.inside = paramBoolean;
  }
  
  public void getEdgePath(float paramFloat1, float paramFloat2, ShapePath paramShapePath) {
    float f2;
    float f1 = paramFloat1 / 2.0F;
    paramShapePath.lineTo(f1 - this.size * paramFloat2, 0.0F);
    if (this.inside) {
      f2 = this.size;
    } else {
      f2 = -this.size;
    } 
    paramShapePath.lineTo(f1, f2 * paramFloat2);
    paramShapePath.lineTo(f1 + this.size * paramFloat2, 0.0F);
    paramShapePath.lineTo(paramFloat1, 0.0F);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\TriangleEdgeTreatment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */