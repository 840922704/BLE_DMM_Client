package android.support.design.shape;

import android.graphics.Matrix;
import android.graphics.Path;

public abstract class PathOperation {
  protected final Matrix matrix = new Matrix();
  
  public abstract void applyToPath(Matrix paramMatrix, Path paramPath);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\ShapePath$PathOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */