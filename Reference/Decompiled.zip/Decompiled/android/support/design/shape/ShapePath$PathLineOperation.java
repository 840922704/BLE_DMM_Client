package android.support.design.shape;

import android.graphics.Matrix;
import android.graphics.Path;

public class PathLineOperation extends ShapePath.PathOperation {
  private float x;
  
  private float y;
  
  public void applyToPath(Matrix paramMatrix, Path paramPath) {
    Matrix matrix = this.matrix;
    paramMatrix.invert(matrix);
    paramPath.transform(matrix);
    paramPath.lineTo(this.x, this.y);
    paramPath.transform(paramMatrix);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\shape\ShapePath$PathLineOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */