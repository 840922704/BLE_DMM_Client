package android.support.design.stateful;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<ExtendableSavedState> {
  public ExtendableSavedState createFromParcel(Parcel paramParcel) {
    return new ExtendableSavedState(paramParcel, null, null);
  }
  
  public ExtendableSavedState createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new ExtendableSavedState(paramParcel, paramClassLoader, null);
  }
  
  public ExtendableSavedState[] newArray(int paramInt) {
    return new ExtendableSavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\stateful\ExtendableSavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */