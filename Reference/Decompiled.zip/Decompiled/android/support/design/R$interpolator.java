package android.support.design;

public final class interpolator {
  public static final int mtrl_fast_out_linear_in = 2131361792;
  
  public static final int mtrl_fast_out_slow_in = 2131361793;
  
  public static final int mtrl_linear = 2131361794;
  
  public static final int mtrl_linear_out_slow_in = 2131361795;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$interpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */