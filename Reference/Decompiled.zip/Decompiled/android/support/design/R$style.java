package android.support.design;

public final class style {
  public static final int AlertDialog_AppCompat = 2131755008;
  
  public static final int AlertDialog_AppCompat_Light = 2131755009;
  
  public static final int Animation_AppCompat_Dialog = 2131755011;
  
  public static final int Animation_AppCompat_DropDownUp = 2131755012;
  
  public static final int Animation_AppCompat_Tooltip = 2131755013;
  
  public static final int Animation_Design_BottomSheetDialog = 2131755014;
  
  public static final int Base_AlertDialog_AppCompat = 2131755016;
  
  public static final int Base_AlertDialog_AppCompat_Light = 2131755017;
  
  public static final int Base_Animation_AppCompat_Dialog = 2131755018;
  
  public static final int Base_Animation_AppCompat_DropDownUp = 2131755019;
  
  public static final int Base_Animation_AppCompat_Tooltip = 2131755020;
  
  public static final int Base_CardView = 2131755021;
  
  public static final int Base_DialogWindowTitleBackground_AppCompat = 2131755023;
  
  public static final int Base_DialogWindowTitle_AppCompat = 2131755022;
  
  public static final int Base_TextAppearance_AppCompat = 2131755024;
  
  public static final int Base_TextAppearance_AppCompat_Body1 = 2131755025;
  
  public static final int Base_TextAppearance_AppCompat_Body2 = 2131755026;
  
  public static final int Base_TextAppearance_AppCompat_Button = 2131755027;
  
  public static final int Base_TextAppearance_AppCompat_Caption = 2131755028;
  
  public static final int Base_TextAppearance_AppCompat_Display1 = 2131755029;
  
  public static final int Base_TextAppearance_AppCompat_Display2 = 2131755030;
  
  public static final int Base_TextAppearance_AppCompat_Display3 = 2131755031;
  
  public static final int Base_TextAppearance_AppCompat_Display4 = 2131755032;
  
  public static final int Base_TextAppearance_AppCompat_Headline = 2131755033;
  
  public static final int Base_TextAppearance_AppCompat_Inverse = 2131755034;
  
  public static final int Base_TextAppearance_AppCompat_Large = 2131755035;
  
  public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131755036;
  
  public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131755037;
  
  public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131755038;
  
  public static final int Base_TextAppearance_AppCompat_Medium = 2131755039;
  
  public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131755040;
  
  public static final int Base_TextAppearance_AppCompat_Menu = 2131755041;
  
  public static final int Base_TextAppearance_AppCompat_SearchResult = 2131755042;
  
  public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131755043;
  
  public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131755044;
  
  public static final int Base_TextAppearance_AppCompat_Small = 2131755045;
  
  public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131755046;
  
  public static final int Base_TextAppearance_AppCompat_Subhead = 2131755047;
  
  public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131755048;
  
  public static final int Base_TextAppearance_AppCompat_Title = 2131755049;
  
  public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131755050;
  
  public static final int Base_TextAppearance_AppCompat_Tooltip = 2131755051;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131755052;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131755053;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131755054;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131755055;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131755056;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131755057;
  
  public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131755058;
  
  public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131755059;
  
  public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131755060;
  
  public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131755061;
  
  public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131755062;
  
  public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131755063;
  
  public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131755064;
  
  public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131755065;
  
  public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131755066;
  
  public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131755067;
  
  public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131755068;
  
  public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131755069;
  
  public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131755070;
  
  public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131755071;
  
  public static final int Base_ThemeOverlay_AppCompat = 2131755103;
  
  public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131755104;
  
  public static final int Base_ThemeOverlay_AppCompat_Dark = 2131755105;
  
  public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131755106;
  
  public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131755107;
  
  public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131755108;
  
  public static final int Base_ThemeOverlay_AppCompat_Light = 2131755109;
  
  public static final int Base_ThemeOverlay_MaterialComponents_Dialog = 2131755110;
  
  public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755111;
  
  public static final int Base_Theme_AppCompat = 2131755072;
  
  public static final int Base_Theme_AppCompat_CompactMenu = 2131755073;
  
  public static final int Base_Theme_AppCompat_Dialog = 2131755074;
  
  public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131755078;
  
  public static final int Base_Theme_AppCompat_Dialog_Alert = 2131755075;
  
  public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131755076;
  
  public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131755077;
  
  public static final int Base_Theme_AppCompat_Light = 2131755079;
  
  public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131755080;
  
  public static final int Base_Theme_AppCompat_Light_Dialog = 2131755081;
  
  public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131755085;
  
  public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131755082;
  
  public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131755083;
  
  public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131755084;
  
  public static final int Base_Theme_MaterialComponents = 2131755086;
  
  public static final int Base_Theme_MaterialComponents_Bridge = 2131755087;
  
  public static final int Base_Theme_MaterialComponents_CompactMenu = 2131755088;
  
  public static final int Base_Theme_MaterialComponents_Dialog = 2131755089;
  
  public static final int Base_Theme_MaterialComponents_DialogWhenLarge = 2131755093;
  
  public static final int Base_Theme_MaterialComponents_Dialog_Alert = 2131755090;
  
  public static final int Base_Theme_MaterialComponents_Dialog_FixedSize = 2131755091;
  
  public static final int Base_Theme_MaterialComponents_Dialog_MinWidth = 2131755092;
  
  public static final int Base_Theme_MaterialComponents_Light = 2131755094;
  
  public static final int Base_Theme_MaterialComponents_Light_Bridge = 2131755095;
  
  public static final int Base_Theme_MaterialComponents_Light_DarkActionBar = 2131755096;
  
  public static final int Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755097;
  
  public static final int Base_Theme_MaterialComponents_Light_Dialog = 2131755098;
  
  public static final int Base_Theme_MaterialComponents_Light_DialogWhenLarge = 2131755102;
  
  public static final int Base_Theme_MaterialComponents_Light_Dialog_Alert = 2131755099;
  
  public static final int Base_Theme_MaterialComponents_Light_Dialog_FixedSize = 2131755100;
  
  public static final int Base_Theme_MaterialComponents_Light_Dialog_MinWidth = 2131755101;
  
  public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog = 2131755119;
  
  public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755120;
  
  public static final int Base_V14_Theme_MaterialComponents = 2131755112;
  
  public static final int Base_V14_Theme_MaterialComponents_Bridge = 2131755113;
  
  public static final int Base_V14_Theme_MaterialComponents_Dialog = 2131755114;
  
  public static final int Base_V14_Theme_MaterialComponents_Light = 2131755115;
  
  public static final int Base_V14_Theme_MaterialComponents_Light_Bridge = 2131755116;
  
  public static final int Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755117;
  
  public static final int Base_V14_Theme_MaterialComponents_Light_Dialog = 2131755118;
  
  public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131755125;
  
  public static final int Base_V21_Theme_AppCompat = 2131755121;
  
  public static final int Base_V21_Theme_AppCompat_Dialog = 2131755122;
  
  public static final int Base_V21_Theme_AppCompat_Light = 2131755123;
  
  public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131755124;
  
  public static final int Base_V22_Theme_AppCompat = 2131755126;
  
  public static final int Base_V22_Theme_AppCompat_Light = 2131755127;
  
  public static final int Base_V23_Theme_AppCompat = 2131755128;
  
  public static final int Base_V23_Theme_AppCompat_Light = 2131755129;
  
  public static final int Base_V26_Theme_AppCompat = 2131755130;
  
  public static final int Base_V26_Theme_AppCompat_Light = 2131755131;
  
  public static final int Base_V26_Widget_AppCompat_Toolbar = 2131755132;
  
  public static final int Base_V28_Theme_AppCompat = 2131755133;
  
  public static final int Base_V28_Theme_AppCompat_Light = 2131755134;
  
  public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131755139;
  
  public static final int Base_V7_Theme_AppCompat = 2131755135;
  
  public static final int Base_V7_Theme_AppCompat_Dialog = 2131755136;
  
  public static final int Base_V7_Theme_AppCompat_Light = 2131755137;
  
  public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131755138;
  
  public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131755140;
  
  public static final int Base_V7_Widget_AppCompat_EditText = 2131755141;
  
  public static final int Base_V7_Widget_AppCompat_Toolbar = 2131755142;
  
  public static final int Base_Widget_AppCompat_ActionBar = 2131755143;
  
  public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131755144;
  
  public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131755145;
  
  public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131755146;
  
  public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131755147;
  
  public static final int Base_Widget_AppCompat_ActionButton = 2131755148;
  
  public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131755149;
  
  public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131755150;
  
  public static final int Base_Widget_AppCompat_ActionMode = 2131755151;
  
  public static final int Base_Widget_AppCompat_ActivityChooserView = 2131755152;
  
  public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131755153;
  
  public static final int Base_Widget_AppCompat_Button = 2131755154;
  
  public static final int Base_Widget_AppCompat_ButtonBar = 2131755160;
  
  public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131755161;
  
  public static final int Base_Widget_AppCompat_Button_Borderless = 2131755155;
  
  public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131755156;
  
  public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131755157;
  
  public static final int Base_Widget_AppCompat_Button_Colored = 2131755158;
  
  public static final int Base_Widget_AppCompat_Button_Small = 2131755159;
  
  public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131755162;
  
  public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131755163;
  
  public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131755164;
  
  public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131755165;
  
  public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131755166;
  
  public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131755167;
  
  public static final int Base_Widget_AppCompat_EditText = 2131755168;
  
  public static final int Base_Widget_AppCompat_ImageButton = 2131755169;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar = 2131755170;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131755171;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131755172;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131755173;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131755174;
  
  public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131755175;
  
  public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131755176;
  
  public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131755177;
  
  public static final int Base_Widget_AppCompat_ListMenuView = 2131755178;
  
  public static final int Base_Widget_AppCompat_ListPopupWindow = 2131755179;
  
  public static final int Base_Widget_AppCompat_ListView = 2131755180;
  
  public static final int Base_Widget_AppCompat_ListView_DropDown = 2131755181;
  
  public static final int Base_Widget_AppCompat_ListView_Menu = 2131755182;
  
  public static final int Base_Widget_AppCompat_PopupMenu = 2131755183;
  
  public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131755184;
  
  public static final int Base_Widget_AppCompat_PopupWindow = 2131755185;
  
  public static final int Base_Widget_AppCompat_ProgressBar = 2131755186;
  
  public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131755187;
  
  public static final int Base_Widget_AppCompat_RatingBar = 2131755188;
  
  public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131755189;
  
  public static final int Base_Widget_AppCompat_RatingBar_Small = 2131755190;
  
  public static final int Base_Widget_AppCompat_SearchView = 2131755191;
  
  public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131755192;
  
  public static final int Base_Widget_AppCompat_SeekBar = 2131755193;
  
  public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131755194;
  
  public static final int Base_Widget_AppCompat_Spinner = 2131755195;
  
  public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131755196;
  
  public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131755197;
  
  public static final int Base_Widget_AppCompat_Toolbar = 2131755198;
  
  public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131755199;
  
  public static final int Base_Widget_Design_TabLayout = 2131755200;
  
  public static final int Base_Widget_MaterialComponents_Chip = 2131755201;
  
  public static final int Base_Widget_MaterialComponents_TextInputEditText = 2131755202;
  
  public static final int Base_Widget_MaterialComponents_TextInputLayout = 2131755203;
  
  public static final int CardView = 2131755204;
  
  public static final int CardView_Dark = 2131755205;
  
  public static final int CardView_Light = 2131755206;
  
  public static final int Platform_AppCompat = 2131755208;
  
  public static final int Platform_AppCompat_Light = 2131755209;
  
  public static final int Platform_MaterialComponents = 2131755210;
  
  public static final int Platform_MaterialComponents_Dialog = 2131755211;
  
  public static final int Platform_MaterialComponents_Light = 2131755212;
  
  public static final int Platform_MaterialComponents_Light_Dialog = 2131755213;
  
  public static final int Platform_ThemeOverlay_AppCompat = 2131755214;
  
  public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131755215;
  
  public static final int Platform_ThemeOverlay_AppCompat_Light = 2131755216;
  
  public static final int Platform_V21_AppCompat = 2131755217;
  
  public static final int Platform_V21_AppCompat_Light = 2131755218;
  
  public static final int Platform_V25_AppCompat = 2131755219;
  
  public static final int Platform_V25_AppCompat_Light = 2131755220;
  
  public static final int Platform_Widget_AppCompat_Spinner = 2131755221;
  
  public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131755225;
  
  public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131755226;
  
  public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131755227;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131755228;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131755229;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131755230;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131755231;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131755232;
  
  public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131755233;
  
  public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131755239;
  
  public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131755234;
  
  public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131755235;
  
  public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131755236;
  
  public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131755237;
  
  public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131755238;
  
  public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131755240;
  
  public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131755241;
  
  public static final int TextAppearance_AppCompat = 2131755242;
  
  public static final int TextAppearance_AppCompat_Body1 = 2131755243;
  
  public static final int TextAppearance_AppCompat_Body2 = 2131755244;
  
  public static final int TextAppearance_AppCompat_Button = 2131755245;
  
  public static final int TextAppearance_AppCompat_Caption = 2131755246;
  
  public static final int TextAppearance_AppCompat_Display1 = 2131755247;
  
  public static final int TextAppearance_AppCompat_Display2 = 2131755248;
  
  public static final int TextAppearance_AppCompat_Display3 = 2131755249;
  
  public static final int TextAppearance_AppCompat_Display4 = 2131755250;
  
  public static final int TextAppearance_AppCompat_Headline = 2131755251;
  
  public static final int TextAppearance_AppCompat_Inverse = 2131755252;
  
  public static final int TextAppearance_AppCompat_Large = 2131755253;
  
  public static final int TextAppearance_AppCompat_Large_Inverse = 2131755254;
  
  public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131755255;
  
  public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131755256;
  
  public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131755257;
  
  public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131755258;
  
  public static final int TextAppearance_AppCompat_Medium = 2131755259;
  
  public static final int TextAppearance_AppCompat_Medium_Inverse = 2131755260;
  
  public static final int TextAppearance_AppCompat_Menu = 2131755261;
  
  public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131755262;
  
  public static final int TextAppearance_AppCompat_SearchResult_Title = 2131755263;
  
  public static final int TextAppearance_AppCompat_Small = 2131755264;
  
  public static final int TextAppearance_AppCompat_Small_Inverse = 2131755265;
  
  public static final int TextAppearance_AppCompat_Subhead = 2131755266;
  
  public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131755267;
  
  public static final int TextAppearance_AppCompat_Title = 2131755268;
  
  public static final int TextAppearance_AppCompat_Title_Inverse = 2131755269;
  
  public static final int TextAppearance_AppCompat_Tooltip = 2131755270;
  
  public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131755271;
  
  public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131755272;
  
  public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131755273;
  
  public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131755274;
  
  public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131755275;
  
  public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131755276;
  
  public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131755277;
  
  public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131755278;
  
  public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131755279;
  
  public static final int TextAppearance_AppCompat_Widget_Button = 2131755280;
  
  public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131755281;
  
  public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131755282;
  
  public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131755283;
  
  public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131755284;
  
  public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131755285;
  
  public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131755286;
  
  public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131755287;
  
  public static final int TextAppearance_AppCompat_Widget_Switch = 2131755288;
  
  public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131755289;
  
  public static final int TextAppearance_Compat_Notification = 2131755290;
  
  public static final int TextAppearance_Compat_Notification_Info = 2131755291;
  
  public static final int TextAppearance_Compat_Notification_Line2 = 2131755292;
  
  public static final int TextAppearance_Compat_Notification_Time = 2131755293;
  
  public static final int TextAppearance_Compat_Notification_Title = 2131755294;
  
  public static final int TextAppearance_Design_CollapsingToolbar_Expanded = 2131755295;
  
  public static final int TextAppearance_Design_Counter = 2131755296;
  
  public static final int TextAppearance_Design_Counter_Overflow = 2131755297;
  
  public static final int TextAppearance_Design_Error = 2131755298;
  
  public static final int TextAppearance_Design_HelperText = 2131755299;
  
  public static final int TextAppearance_Design_Hint = 2131755300;
  
  public static final int TextAppearance_Design_Snackbar_Message = 2131755301;
  
  public static final int TextAppearance_Design_Tab = 2131755302;
  
  public static final int TextAppearance_MaterialComponents_Body1 = 2131755303;
  
  public static final int TextAppearance_MaterialComponents_Body2 = 2131755304;
  
  public static final int TextAppearance_MaterialComponents_Button = 2131755305;
  
  public static final int TextAppearance_MaterialComponents_Caption = 2131755306;
  
  public static final int TextAppearance_MaterialComponents_Chip = 2131755307;
  
  public static final int TextAppearance_MaterialComponents_Headline1 = 2131755308;
  
  public static final int TextAppearance_MaterialComponents_Headline2 = 2131755309;
  
  public static final int TextAppearance_MaterialComponents_Headline3 = 2131755310;
  
  public static final int TextAppearance_MaterialComponents_Headline4 = 2131755311;
  
  public static final int TextAppearance_MaterialComponents_Headline5 = 2131755312;
  
  public static final int TextAppearance_MaterialComponents_Headline6 = 2131755313;
  
  public static final int TextAppearance_MaterialComponents_Overline = 2131755314;
  
  public static final int TextAppearance_MaterialComponents_Subtitle1 = 2131755315;
  
  public static final int TextAppearance_MaterialComponents_Subtitle2 = 2131755316;
  
  public static final int TextAppearance_MaterialComponents_Tab = 2131755317;
  
  public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131755318;
  
  public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131755319;
  
  public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131755320;
  
  public static final int ThemeOverlay_AppCompat = 2131755369;
  
  public static final int ThemeOverlay_AppCompat_ActionBar = 2131755370;
  
  public static final int ThemeOverlay_AppCompat_Dark = 2131755371;
  
  public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131755372;
  
  public static final int ThemeOverlay_AppCompat_Dialog = 2131755373;
  
  public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131755374;
  
  public static final int ThemeOverlay_AppCompat_Light = 2131755375;
  
  public static final int ThemeOverlay_MaterialComponents = 2131755376;
  
  public static final int ThemeOverlay_MaterialComponents_ActionBar = 2131755377;
  
  public static final int ThemeOverlay_MaterialComponents_Dark = 2131755378;
  
  public static final int ThemeOverlay_MaterialComponents_Dark_ActionBar = 2131755379;
  
  public static final int ThemeOverlay_MaterialComponents_Dialog = 2131755380;
  
  public static final int ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755381;
  
  public static final int ThemeOverlay_MaterialComponents_Light = 2131755382;
  
  public static final int ThemeOverlay_MaterialComponents_TextInputEditText = 2131755383;
  
  public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox = 2131755384;
  
  public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense = 2131755385;
  
  public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox = 2131755386;
  
  public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 2131755387;
  
  public static final int Theme_AppCompat = 2131755321;
  
  public static final int Theme_AppCompat_CompactMenu = 2131755322;
  
  public static final int Theme_AppCompat_DayNight = 2131755323;
  
  public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131755324;
  
  public static final int Theme_AppCompat_DayNight_Dialog = 2131755325;
  
  public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131755328;
  
  public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131755326;
  
  public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131755327;
  
  public static final int Theme_AppCompat_DayNight_NoActionBar = 2131755329;
  
  public static final int Theme_AppCompat_Dialog = 2131755330;
  
  public static final int Theme_AppCompat_DialogWhenLarge = 2131755333;
  
  public static final int Theme_AppCompat_Dialog_Alert = 2131755331;
  
  public static final int Theme_AppCompat_Dialog_MinWidth = 2131755332;
  
  public static final int Theme_AppCompat_Light = 2131755334;
  
  public static final int Theme_AppCompat_Light_DarkActionBar = 2131755335;
  
  public static final int Theme_AppCompat_Light_Dialog = 2131755336;
  
  public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131755339;
  
  public static final int Theme_AppCompat_Light_Dialog_Alert = 2131755337;
  
  public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131755338;
  
  public static final int Theme_AppCompat_Light_NoActionBar = 2131755340;
  
  public static final int Theme_AppCompat_NoActionBar = 2131755341;
  
  public static final int Theme_Design = 2131755342;
  
  public static final int Theme_Design_BottomSheetDialog = 2131755343;
  
  public static final int Theme_Design_Light = 2131755344;
  
  public static final int Theme_Design_Light_BottomSheetDialog = 2131755345;
  
  public static final int Theme_Design_Light_NoActionBar = 2131755346;
  
  public static final int Theme_Design_NoActionBar = 2131755347;
  
  public static final int Theme_MaterialComponents = 2131755348;
  
  public static final int Theme_MaterialComponents_BottomSheetDialog = 2131755349;
  
  public static final int Theme_MaterialComponents_Bridge = 2131755350;
  
  public static final int Theme_MaterialComponents_CompactMenu = 2131755351;
  
  public static final int Theme_MaterialComponents_Dialog = 2131755352;
  
  public static final int Theme_MaterialComponents_DialogWhenLarge = 2131755355;
  
  public static final int Theme_MaterialComponents_Dialog_Alert = 2131755353;
  
  public static final int Theme_MaterialComponents_Dialog_MinWidth = 2131755354;
  
  public static final int Theme_MaterialComponents_Light = 2131755356;
  
  public static final int Theme_MaterialComponents_Light_BottomSheetDialog = 2131755357;
  
  public static final int Theme_MaterialComponents_Light_Bridge = 2131755358;
  
  public static final int Theme_MaterialComponents_Light_DarkActionBar = 2131755359;
  
  public static final int Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755360;
  
  public static final int Theme_MaterialComponents_Light_Dialog = 2131755361;
  
  public static final int Theme_MaterialComponents_Light_DialogWhenLarge = 2131755364;
  
  public static final int Theme_MaterialComponents_Light_Dialog_Alert = 2131755362;
  
  public static final int Theme_MaterialComponents_Light_Dialog_MinWidth = 2131755363;
  
  public static final int Theme_MaterialComponents_Light_NoActionBar = 2131755365;
  
  public static final int Theme_MaterialComponents_Light_NoActionBar_Bridge = 2131755366;
  
  public static final int Theme_MaterialComponents_NoActionBar = 2131755367;
  
  public static final int Theme_MaterialComponents_NoActionBar_Bridge = 2131755368;
  
  public static final int Widget_AppCompat_ActionBar = 2131755388;
  
  public static final int Widget_AppCompat_ActionBar_Solid = 2131755389;
  
  public static final int Widget_AppCompat_ActionBar_TabBar = 2131755390;
  
  public static final int Widget_AppCompat_ActionBar_TabText = 2131755391;
  
  public static final int Widget_AppCompat_ActionBar_TabView = 2131755392;
  
  public static final int Widget_AppCompat_ActionButton = 2131755393;
  
  public static final int Widget_AppCompat_ActionButton_CloseMode = 2131755394;
  
  public static final int Widget_AppCompat_ActionButton_Overflow = 2131755395;
  
  public static final int Widget_AppCompat_ActionMode = 2131755396;
  
  public static final int Widget_AppCompat_ActivityChooserView = 2131755397;
  
  public static final int Widget_AppCompat_AutoCompleteTextView = 2131755398;
  
  public static final int Widget_AppCompat_Button = 2131755399;
  
  public static final int Widget_AppCompat_ButtonBar = 2131755405;
  
  public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131755406;
  
  public static final int Widget_AppCompat_Button_Borderless = 2131755400;
  
  public static final int Widget_AppCompat_Button_Borderless_Colored = 2131755401;
  
  public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131755402;
  
  public static final int Widget_AppCompat_Button_Colored = 2131755403;
  
  public static final int Widget_AppCompat_Button_Small = 2131755404;
  
  public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131755407;
  
  public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131755408;
  
  public static final int Widget_AppCompat_CompoundButton_Switch = 2131755409;
  
  public static final int Widget_AppCompat_DrawerArrowToggle = 2131755410;
  
  public static final int Widget_AppCompat_DropDownItem_Spinner = 2131755411;
  
  public static final int Widget_AppCompat_EditText = 2131755412;
  
  public static final int Widget_AppCompat_ImageButton = 2131755413;
  
  public static final int Widget_AppCompat_Light_ActionBar = 2131755414;
  
  public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131755415;
  
  public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131755416;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131755417;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131755418;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131755419;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131755420;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131755421;
  
  public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131755422;
  
  public static final int Widget_AppCompat_Light_ActionButton = 2131755423;
  
  public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131755424;
  
  public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131755425;
  
  public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131755426;
  
  public static final int Widget_AppCompat_Light_ActivityChooserView = 2131755427;
  
  public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131755428;
  
  public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131755429;
  
  public static final int Widget_AppCompat_Light_ListPopupWindow = 2131755430;
  
  public static final int Widget_AppCompat_Light_ListView_DropDown = 2131755431;
  
  public static final int Widget_AppCompat_Light_PopupMenu = 2131755432;
  
  public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131755433;
  
  public static final int Widget_AppCompat_Light_SearchView = 2131755434;
  
  public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131755435;
  
  public static final int Widget_AppCompat_ListMenuView = 2131755436;
  
  public static final int Widget_AppCompat_ListPopupWindow = 2131755437;
  
  public static final int Widget_AppCompat_ListView = 2131755438;
  
  public static final int Widget_AppCompat_ListView_DropDown = 2131755439;
  
  public static final int Widget_AppCompat_ListView_Menu = 2131755440;
  
  public static final int Widget_AppCompat_PopupMenu = 2131755441;
  
  public static final int Widget_AppCompat_PopupMenu_Overflow = 2131755442;
  
  public static final int Widget_AppCompat_PopupWindow = 2131755443;
  
  public static final int Widget_AppCompat_ProgressBar = 2131755444;
  
  public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131755445;
  
  public static final int Widget_AppCompat_RatingBar = 2131755446;
  
  public static final int Widget_AppCompat_RatingBar_Indicator = 2131755447;
  
  public static final int Widget_AppCompat_RatingBar_Small = 2131755448;
  
  public static final int Widget_AppCompat_SearchView = 2131755449;
  
  public static final int Widget_AppCompat_SearchView_ActionBar = 2131755450;
  
  public static final int Widget_AppCompat_SeekBar = 2131755451;
  
  public static final int Widget_AppCompat_SeekBar_Discrete = 2131755452;
  
  public static final int Widget_AppCompat_Spinner = 2131755453;
  
  public static final int Widget_AppCompat_Spinner_DropDown = 2131755454;
  
  public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131755455;
  
  public static final int Widget_AppCompat_Spinner_Underlined = 2131755456;
  
  public static final int Widget_AppCompat_TextView_SpinnerItem = 2131755457;
  
  public static final int Widget_AppCompat_Toolbar = 2131755458;
  
  public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131755459;
  
  public static final int Widget_Compat_NotificationActionContainer = 2131755460;
  
  public static final int Widget_Compat_NotificationActionText = 2131755461;
  
  public static final int Widget_Design_AppBarLayout = 2131755462;
  
  public static final int Widget_Design_BottomNavigationView = 2131755463;
  
  public static final int Widget_Design_BottomSheet_Modal = 2131755464;
  
  public static final int Widget_Design_CollapsingToolbar = 2131755465;
  
  public static final int Widget_Design_FloatingActionButton = 2131755466;
  
  public static final int Widget_Design_NavigationView = 2131755467;
  
  public static final int Widget_Design_ScrimInsetsFrameLayout = 2131755468;
  
  public static final int Widget_Design_Snackbar = 2131755469;
  
  public static final int Widget_Design_TabLayout = 2131755470;
  
  public static final int Widget_Design_TextInputLayout = 2131755471;
  
  public static final int Widget_MaterialComponents_BottomAppBar = 2131755472;
  
  public static final int Widget_MaterialComponents_BottomAppBar_Colored = 2131755473;
  
  public static final int Widget_MaterialComponents_BottomNavigationView = 2131755474;
  
  public static final int Widget_MaterialComponents_BottomNavigationView_Colored = 2131755475;
  
  public static final int Widget_MaterialComponents_BottomSheet_Modal = 2131755476;
  
  public static final int Widget_MaterialComponents_Button = 2131755477;
  
  public static final int Widget_MaterialComponents_Button_Icon = 2131755478;
  
  public static final int Widget_MaterialComponents_Button_OutlinedButton = 2131755479;
  
  public static final int Widget_MaterialComponents_Button_OutlinedButton_Icon = 2131755480;
  
  public static final int Widget_MaterialComponents_Button_TextButton = 2131755481;
  
  public static final int Widget_MaterialComponents_Button_TextButton_Dialog = 2131755482;
  
  public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Icon = 2131755483;
  
  public static final int Widget_MaterialComponents_Button_TextButton_Icon = 2131755484;
  
  public static final int Widget_MaterialComponents_Button_UnelevatedButton = 2131755485;
  
  public static final int Widget_MaterialComponents_Button_UnelevatedButton_Icon = 2131755486;
  
  public static final int Widget_MaterialComponents_CardView = 2131755487;
  
  public static final int Widget_MaterialComponents_ChipGroup = 2131755492;
  
  public static final int Widget_MaterialComponents_Chip_Action = 2131755488;
  
  public static final int Widget_MaterialComponents_Chip_Choice = 2131755489;
  
  public static final int Widget_MaterialComponents_Chip_Entry = 2131755490;
  
  public static final int Widget_MaterialComponents_Chip_Filter = 2131755491;
  
  public static final int Widget_MaterialComponents_FloatingActionButton = 2131755493;
  
  public static final int Widget_MaterialComponents_NavigationView = 2131755494;
  
  public static final int Widget_MaterialComponents_Snackbar = 2131755495;
  
  public static final int Widget_MaterialComponents_Snackbar_FullWidth = 2131755496;
  
  public static final int Widget_MaterialComponents_TabLayout = 2131755497;
  
  public static final int Widget_MaterialComponents_TabLayout_Colored = 2131755498;
  
  public static final int Widget_MaterialComponents_TextInputEditText_FilledBox = 2131755499;
  
  public static final int Widget_MaterialComponents_TextInputEditText_FilledBox_Dense = 2131755500;
  
  public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox = 2131755501;
  
  public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 2131755502;
  
  public static final int Widget_MaterialComponents_TextInputLayout_FilledBox = 2131755503;
  
  public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense = 2131755504;
  
  public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox = 2131755505;
  
  public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense = 2131755506;
  
  public static final int Widget_MaterialComponents_Toolbar = 2131755507;
  
  public static final int Widget_Support_CoordinatorLayout = 2131755508;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$style.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */