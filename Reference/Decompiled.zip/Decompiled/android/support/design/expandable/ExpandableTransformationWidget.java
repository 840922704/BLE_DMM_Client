package android.support.design.expandable;

public interface ExpandableTransformationWidget extends ExpandableWidget {
  int getExpandedComponentIdHint();
  
  void setExpandedComponentIdHint(int paramInt);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\expandable\ExpandableTransformationWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */