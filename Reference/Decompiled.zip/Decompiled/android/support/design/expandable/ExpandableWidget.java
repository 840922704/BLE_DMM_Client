package android.support.design.expandable;

public interface ExpandableWidget {
  boolean isExpanded();
  
  boolean setExpanded(boolean paramBoolean);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\expandable\ExpandableWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */