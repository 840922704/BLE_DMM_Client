package android.support.design.transformation;

import android.support.design.expandable.ExpandableWidget;
import android.view.View;
import android.view.ViewTreeObserver;

class null implements ViewTreeObserver.OnPreDrawListener {
  public boolean onPreDraw() {
    child.getViewTreeObserver().removeOnPreDrawListener(this);
    if (ExpandableBehavior.access$000(ExpandableBehavior.this) == expectedState) {
      ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
      ExpandableWidget expandableWidget = dep;
      expandableBehavior.onExpandedStateChange((View)expandableWidget, child, expandableWidget.isExpanded(), false);
    } 
    return false;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\transformation\ExpandableBehavior$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */