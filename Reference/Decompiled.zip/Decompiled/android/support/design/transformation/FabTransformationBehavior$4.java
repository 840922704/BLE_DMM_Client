package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.design.circularreveal.CircularRevealWidget;

class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    CircularRevealWidget.RevealInfo revealInfo = circularRevealChild.getRevealInfo();
    revealInfo.radius = Float.MAX_VALUE;
    circularRevealChild.setRevealInfo(revealInfo);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\transformation\FabTransformationBehavior$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */