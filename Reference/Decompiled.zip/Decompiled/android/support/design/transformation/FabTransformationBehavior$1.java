package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    if (!expanded) {
      child.setVisibility(4);
      dependency.setAlpha(1.0F);
      dependency.setVisibility(0);
    } 
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    if (expanded) {
      child.setVisibility(0);
      dependency.setAlpha(0.0F);
      dependency.setVisibility(4);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\transformation\FabTransformationBehavior$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */