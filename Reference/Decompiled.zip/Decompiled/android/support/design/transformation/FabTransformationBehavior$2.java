package android.support.design.transformation;

import android.animation.ValueAnimator;
import android.view.View;

class null implements ValueAnimator.AnimatorUpdateListener {
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    child.invalidate();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\transformation\FabTransformationBehavior$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */