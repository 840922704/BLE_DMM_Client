package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.drawable.Drawable;
import android.support.design.circularreveal.CircularRevealWidget;

class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    circularRevealChild.setCircularRevealOverlayDrawable(null);
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    circularRevealChild.setCircularRevealOverlayDrawable(icon);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\transformation\FabTransformationBehavior$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */