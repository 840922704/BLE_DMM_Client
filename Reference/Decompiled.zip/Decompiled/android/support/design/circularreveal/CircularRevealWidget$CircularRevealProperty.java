package android.support.design.circularreveal;

import android.util.Property;

public class CircularRevealProperty extends Property<CircularRevealWidget, CircularRevealWidget.RevealInfo> {
  public static final Property<CircularRevealWidget, CircularRevealWidget.RevealInfo> CIRCULAR_REVEAL = new CircularRevealProperty("circularReveal");
  
  private CircularRevealProperty(String paramString) {
    super(CircularRevealWidget.RevealInfo.class, paramString);
  }
  
  public CircularRevealWidget.RevealInfo get(CircularRevealWidget paramCircularRevealWidget) {
    return paramCircularRevealWidget.getRevealInfo();
  }
  
  public void set(CircularRevealWidget paramCircularRevealWidget, CircularRevealWidget.RevealInfo paramRevealInfo) {
    paramCircularRevealWidget.setRevealInfo(paramRevealInfo);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealWidget$CircularRevealProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */