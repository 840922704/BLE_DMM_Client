package android.support.design.circularreveal;

import android.util.Property;

public class CircularRevealScrimColorProperty extends Property<CircularRevealWidget, Integer> {
  public static final Property<CircularRevealWidget, Integer> CIRCULAR_REVEAL_SCRIM_COLOR = new CircularRevealScrimColorProperty("circularRevealScrimColor");
  
  private CircularRevealScrimColorProperty(String paramString) {
    super(Integer.class, paramString);
  }
  
  public Integer get(CircularRevealWidget paramCircularRevealWidget) {
    return Integer.valueOf(paramCircularRevealWidget.getCircularRevealScrimColor());
  }
  
  public void set(CircularRevealWidget paramCircularRevealWidget, Integer paramInteger) {
    paramCircularRevealWidget.setCircularRevealScrimColor(paramInteger.intValue());
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealWidget$CircularRevealScrimColorProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */