package android.support.design.circularreveal;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

final class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    view.destroyCircularRevealCache();
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    view.buildCircularRevealCache();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealCompat$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */