package android.support.design.circularreveal;

import android.animation.TypeEvaluator;
import android.support.design.widget.MathUtils;

public class CircularRevealEvaluator implements TypeEvaluator<CircularRevealWidget.RevealInfo> {
  public static final TypeEvaluator<CircularRevealWidget.RevealInfo> CIRCULAR_REVEAL = new CircularRevealEvaluator();
  
  private final CircularRevealWidget.RevealInfo revealInfo = new CircularRevealWidget.RevealInfo(null);
  
  public CircularRevealWidget.RevealInfo evaluate(float paramFloat, CircularRevealWidget.RevealInfo paramRevealInfo1, CircularRevealWidget.RevealInfo paramRevealInfo2) {
    this.revealInfo.set(MathUtils.lerp(paramRevealInfo1.centerX, paramRevealInfo2.centerX, paramFloat), MathUtils.lerp(paramRevealInfo1.centerY, paramRevealInfo2.centerY, paramFloat), MathUtils.lerp(paramRevealInfo1.radius, paramRevealInfo2.radius, paramFloat));
    return this.revealInfo;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealWidget$CircularRevealEvaluator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */