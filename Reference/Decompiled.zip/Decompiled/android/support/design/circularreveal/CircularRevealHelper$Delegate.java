package android.support.design.circularreveal;

import android.graphics.Canvas;

interface Delegate {
  void actualDraw(Canvas paramCanvas);
  
  boolean actualIsOpaque();
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealHelper$Delegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */