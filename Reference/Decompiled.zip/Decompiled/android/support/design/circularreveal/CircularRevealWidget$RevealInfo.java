package android.support.design.circularreveal;

public class RevealInfo {
  public static final float INVALID_RADIUS = 3.4028235E38F;
  
  public float centerX;
  
  public float centerY;
  
  public float radius;
  
  private RevealInfo() {}
  
  public RevealInfo(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.centerX = paramFloat1;
    this.centerY = paramFloat2;
    this.radius = paramFloat3;
  }
  
  public RevealInfo(RevealInfo paramRevealInfo) {
    this(paramRevealInfo.centerX, paramRevealInfo.centerY, paramRevealInfo.radius);
  }
  
  public boolean isInvalid() {
    boolean bool;
    if (this.radius == Float.MAX_VALUE) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void set(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.centerX = paramFloat1;
    this.centerY = paramFloat2;
    this.radius = paramFloat3;
  }
  
  public void set(RevealInfo paramRevealInfo) {
    set(paramRevealInfo.centerX, paramRevealInfo.centerY, paramRevealInfo.radius);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\circularreveal\CircularRevealWidget$RevealInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */