package android.support.design.snackbar;

public interface ContentViewCallback {
  void animateContentIn(int paramInt1, int paramInt2);
  
  void animateContentOut(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\snackbar\ContentViewCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */