package android.support.design.resources;

public class TextAppearanceConfig {
  private static boolean shouldLoadFontSynchronously;
  
  public static void setShouldLoadFontSynchronously(boolean paramBoolean) {
    shouldLoadFontSynchronously = paramBoolean;
  }
  
  public static boolean shouldLoadFontSynchronously() {
    return shouldLoadFontSynchronously;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\resources\TextAppearanceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */