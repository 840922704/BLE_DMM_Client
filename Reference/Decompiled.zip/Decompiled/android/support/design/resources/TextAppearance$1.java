package android.support.design.resources;

import android.graphics.Typeface;
import android.support.v4.content.res.ResourcesCompat;
import android.text.TextPaint;

class null extends ResourcesCompat.FontCallback {
  public void onFontRetrievalFailed(int paramInt) {
    TextAppearance.access$200(TextAppearance.this);
    TextAppearance.access$102(TextAppearance.this, true);
    callback.onFontRetrievalFailed(paramInt);
  }
  
  public void onFontRetrieved(Typeface paramTypeface) {
    TextAppearance textAppearance = TextAppearance.this;
    TextAppearance.access$002(textAppearance, Typeface.create(paramTypeface, textAppearance.textStyle));
    TextAppearance.this.updateTextPaintMeasureState(textPaint, paramTypeface);
    TextAppearance.access$102(TextAppearance.this, true);
    callback.onFontRetrieved(paramTypeface);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\resources\TextAppearance$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */