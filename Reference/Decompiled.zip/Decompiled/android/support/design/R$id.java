package android.support.design;

public final class id {
  public static final int action_bar = 2131230737;
  
  public static final int action_bar_activity_content = 2131230738;
  
  public static final int action_bar_container = 2131230739;
  
  public static final int action_bar_root = 2131230740;
  
  public static final int action_bar_spinner = 2131230741;
  
  public static final int action_bar_subtitle = 2131230742;
  
  public static final int action_bar_title = 2131230743;
  
  public static final int action_container = 2131230744;
  
  public static final int action_context_bar = 2131230745;
  
  public static final int action_divider = 2131230746;
  
  public static final int action_image = 2131230747;
  
  public static final int action_menu_divider = 2131230748;
  
  public static final int action_menu_presenter = 2131230749;
  
  public static final int action_mode_bar = 2131230750;
  
  public static final int action_mode_bar_stub = 2131230751;
  
  public static final int action_mode_close_button = 2131230752;
  
  public static final int action_text = 2131230753;
  
  public static final int actions = 2131230754;
  
  public static final int activity_chooser_view_content = 2131230755;
  
  public static final int add = 2131230756;
  
  public static final int alertTitle = 2131230762;
  
  public static final int async = 2131230766;
  
  public static final int auto = 2131230767;
  
  public static final int blocking = 2131230771;
  
  public static final int bottom = 2131230773;
  
  public static final int buttonPanel = 2131230779;
  
  public static final int center = 2131230786;
  
  public static final int checkbox = 2131230792;
  
  public static final int chronometer = 2131230796;
  
  public static final int container = 2131230804;
  
  public static final int content = 2131230805;
  
  public static final int contentPanel = 2131230806;
  
  public static final int coordinator = 2131230807;
  
  public static final int custom = 2131230810;
  
  public static final int customPanel = 2131230811;
  
  public static final int decor_content_parent = 2131230814;
  
  public static final int default_activity_button = 2131230815;
  
  public static final int design_bottom_sheet = 2131230821;
  
  public static final int design_menu_item_action_area = 2131230822;
  
  public static final int design_menu_item_action_area_stub = 2131230823;
  
  public static final int design_menu_item_text = 2131230824;
  
  public static final int design_navigation_view = 2131230825;
  
  public static final int edit_query = 2131230836;
  
  public static final int end = 2131230846;
  
  public static final int expand_activities_button = 2131230854;
  
  public static final int expanded_menu = 2131230855;
  
  public static final int fill = 2131230858;
  
  public static final int filled = 2131230861;
  
  public static final int fixed = 2131230864;
  
  public static final int forever = 2131230866;
  
  public static final int ghost_view = 2131230870;
  
  public static final int group_divider = 2131230872;
  
  public static final int home = 2131230877;
  
  public static final int icon = 2131230881;
  
  public static final int icon_group = 2131230882;
  
  public static final int image = 2131230885;
  
  public static final int info = 2131230887;
  
  public static final int italic = 2131230889;
  
  public static final int item_touch_helper_previous_elevation = 2131230891;
  
  public static final int labeled = 2131230893;
  
  public static final int largeLabel = 2131230895;
  
  public static final int left = 2131230896;
  
  public static final int line1 = 2131230899;
  
  public static final int line3 = 2131230900;
  
  public static final int listMode = 2131230901;
  
  public static final int list_item = 2131230902;
  
  public static final int masked = 2131230915;
  
  public static final int message = 2131230918;
  
  public static final int mini = 2131230921;
  
  public static final int mtrl_child_content_container = 2131230923;
  
  public static final int mtrl_internal_children_alpha_tag = 2131230924;
  
  public static final int multiply = 2131230926;
  
  public static final int navigation_header_container = 2131230934;
  
  public static final int none = 2131230940;
  
  public static final int normal = 2131230941;
  
  public static final int notification_background = 2131230947;
  
  public static final int notification_main_column = 2131230948;
  
  public static final int notification_main_column_container = 2131230949;
  
  public static final int outline = 2131230953;
  
  public static final int parallax = 2131230957;
  
  public static final int parentPanel = 2131230959;
  
  public static final int parent_matrix = 2131230960;
  
  public static final int pin = 2131230962;
  
  public static final int progress_circular = 2131230964;
  
  public static final int progress_horizontal = 2131230965;
  
  public static final int radio = 2131230969;
  
  public static final int right = 2131230996;
  
  public static final int right_icon = 2131230997;
  
  public static final int right_side = 2131230998;
  
  public static final int save_image_matrix = 2131231002;
  
  public static final int save_non_transition_alpha = 2131231003;
  
  public static final int save_scale_type = 2131231004;
  
  public static final int screen = 2131231005;
  
  public static final int scrollIndicatorDown = 2131231007;
  
  public static final int scrollIndicatorUp = 2131231008;
  
  public static final int scrollView = 2131231009;
  
  public static final int scrollable = 2131231010;
  
  public static final int search_badge = 2131231012;
  
  public static final int search_bar = 2131231013;
  
  public static final int search_button = 2131231014;
  
  public static final int search_close_btn = 2131231015;
  
  public static final int search_edit_frame = 2131231016;
  
  public static final int search_go_btn = 2131231017;
  
  public static final int search_mag_icon = 2131231018;
  
  public static final int search_plate = 2131231019;
  
  public static final int search_src_text = 2131231020;
  
  public static final int search_voice_btn = 2131231021;
  
  public static final int select_dialog_listview = 2131231025;
  
  public static final int selected = 2131231026;
  
  public static final int shortcut = 2131231031;
  
  public static final int smallLabel = 2131231036;
  
  public static final int snackbar_action = 2131231037;
  
  public static final int snackbar_text = 2131231038;
  
  public static final int spacer = 2131231042;
  
  public static final int split_action_bar = 2131231043;
  
  public static final int src_atop = 2131231046;
  
  public static final int src_in = 2131231047;
  
  public static final int src_over = 2131231048;
  
  public static final int start = 2131231055;
  
  public static final int stretch = 2131231056;
  
  public static final int submenuarrow = 2131231057;
  
  public static final int submit_area = 2131231058;
  
  public static final int tabMode = 2131231061;
  
  public static final int tag_transition_group = 2131231070;
  
  public static final int tag_unhandled_key_event_manager = 2131231071;
  
  public static final int tag_unhandled_key_listeners = 2131231072;
  
  public static final int text = 2131231075;
  
  public static final int text2 = 2131231076;
  
  public static final int textSpacerNoButtons = 2131231077;
  
  public static final int textSpacerNoTitle = 2131231078;
  
  public static final int text_input_password_toggle = 2131231080;
  
  public static final int textinput_counter = 2131231081;
  
  public static final int textinput_error = 2131231082;
  
  public static final int textinput_helper_text = 2131231083;
  
  public static final int time = 2131231086;
  
  public static final int title = 2131231088;
  
  public static final int titleDividerNoCustom = 2131231089;
  
  public static final int title_template = 2131231092;
  
  public static final int top = 2131231093;
  
  public static final int topPanel = 2131231098;
  
  public static final int touch_outside = 2131231099;
  
  public static final int transition_current_scene = 2131231100;
  
  public static final int transition_layout_save = 2131231101;
  
  public static final int transition_position = 2131231102;
  
  public static final int transition_scene_layoutid_cache = 2131231103;
  
  public static final int transition_transform = 2131231104;
  
  public static final int uniform = 2131231117;
  
  public static final int unlabeled = 2131231118;
  
  public static final int up = 2131231119;
  
  public static final int view_offset_helper = 2131231126;
  
  public static final int visible = 2131231127;
  
  public static final int wrap_content = 2131231135;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$id.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */