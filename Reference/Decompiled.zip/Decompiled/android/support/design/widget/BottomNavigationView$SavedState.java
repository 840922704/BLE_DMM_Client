package android.support.design.widget;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.AbsSavedState;

class SavedState extends AbsSavedState {
  public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
      public BottomNavigationView.SavedState createFromParcel(Parcel param2Parcel) {
        return new BottomNavigationView.SavedState(param2Parcel, null);
      }
      
      public BottomNavigationView.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new BottomNavigationView.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public BottomNavigationView.SavedState[] newArray(int param2Int) {
        return new BottomNavigationView.SavedState[param2Int];
      }
    };
  
  Bundle menuPresenterState;
  
  public SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    readFromParcel(paramParcel, paramClassLoader);
  }
  
  public SavedState(Parcelable paramParcelable) {
    super(paramParcelable);
  }
  
  private void readFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    this.menuPresenterState = paramParcel.readBundle(paramClassLoader);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeBundle(this.menuPresenterState);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomNavigationView$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */