package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.AbsSavedState;

public class SavedState extends AbsSavedState {
  public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
      public BottomSheetBehavior.SavedState createFromParcel(Parcel param2Parcel) {
        return new BottomSheetBehavior.SavedState(param2Parcel, null);
      }
      
      public BottomSheetBehavior.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new BottomSheetBehavior.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public BottomSheetBehavior.SavedState[] newArray(int param2Int) {
        return new BottomSheetBehavior.SavedState[param2Int];
      }
    };
  
  final int state;
  
  public SavedState(Parcel paramParcel) {
    this(paramParcel, (ClassLoader)null);
  }
  
  public SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    this.state = paramParcel.readInt();
  }
  
  public SavedState(Parcelable paramParcelable, int paramInt) {
    super(paramParcelable);
    this.state = paramInt;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.state);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetBehavior$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */