package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.design.R;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;

public class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.Behavior<T> {
  private static final boolean AUTO_HIDE_DEFAULT = true;
  
  private boolean autoHideEnabled;
  
  private FloatingActionButton.OnVisibilityChangedListener internalAutoHideListener;
  
  private Rect tmpRect;
  
  public BaseBehavior() {
    this.autoHideEnabled = true;
  }
  
  public BaseBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.FloatingActionButton_Behavior_Layout);
    this.autoHideEnabled = typedArray.getBoolean(R.styleable.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
    typedArray.recycle();
  }
  
  private static boolean isBottomSheet(View paramView) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    return (layoutParams instanceof CoordinatorLayout.LayoutParams) ? (((CoordinatorLayout.LayoutParams)layoutParams).getBehavior() instanceof BottomSheetBehavior) : false;
  }
  
  private void offsetIfNeeded(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton) {
    Rect rect = paramFloatingActionButton.shadowPadding;
    if (rect != null && rect.centerX() > 0 && rect.centerY() > 0) {
      CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams)paramFloatingActionButton.getLayoutParams();
      int i = paramFloatingActionButton.getRight();
      int j = paramCoordinatorLayout.getWidth();
      int k = layoutParams.rightMargin;
      int m = 0;
      if (i >= j - k) {
        i = rect.right;
      } else if (paramFloatingActionButton.getLeft() <= layoutParams.leftMargin) {
        i = -rect.left;
      } else {
        i = 0;
      } 
      if (paramFloatingActionButton.getBottom() >= paramCoordinatorLayout.getHeight() - layoutParams.bottomMargin) {
        m = rect.bottom;
      } else if (paramFloatingActionButton.getTop() <= layoutParams.topMargin) {
        m = -rect.top;
      } 
      if (m != 0)
        ViewCompat.offsetTopAndBottom((View)paramFloatingActionButton, m); 
      if (i != 0)
        ViewCompat.offsetLeftAndRight((View)paramFloatingActionButton, i); 
    } 
  }
  
  private boolean shouldUpdateVisibility(View paramView, FloatingActionButton paramFloatingActionButton) {
    CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams)paramFloatingActionButton.getLayoutParams();
    return !this.autoHideEnabled ? false : ((layoutParams.getAnchorId() != paramView.getId()) ? false : (!(paramFloatingActionButton.getUserSetVisibility() != 0)));
  }
  
  private boolean updateFabVisibilityForAppBarLayout(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, FloatingActionButton paramFloatingActionButton) {
    if (!shouldUpdateVisibility((View)paramAppBarLayout, paramFloatingActionButton))
      return false; 
    if (this.tmpRect == null)
      this.tmpRect = new Rect(); 
    Rect rect = this.tmpRect;
    DescendantOffsetUtils.getDescendantRect(paramCoordinatorLayout, (View)paramAppBarLayout, rect);
    if (rect.bottom <= paramAppBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
      paramFloatingActionButton.hide(this.internalAutoHideListener, false);
    } else {
      paramFloatingActionButton.show(this.internalAutoHideListener, false);
    } 
    return true;
  }
  
  private boolean updateFabVisibilityForBottomSheet(View paramView, FloatingActionButton paramFloatingActionButton) {
    if (!shouldUpdateVisibility(paramView, paramFloatingActionButton))
      return false; 
    CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams)paramFloatingActionButton.getLayoutParams();
    if (paramView.getTop() < paramFloatingActionButton.getHeight() / 2 + layoutParams.topMargin) {
      paramFloatingActionButton.hide(this.internalAutoHideListener, false);
    } else {
      paramFloatingActionButton.show(this.internalAutoHideListener, false);
    } 
    return true;
  }
  
  public boolean getInsetDodgeRect(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton, Rect paramRect) {
    Rect rect = paramFloatingActionButton.shadowPadding;
    paramRect.set(paramFloatingActionButton.getLeft() + rect.left, paramFloatingActionButton.getTop() + rect.top, paramFloatingActionButton.getRight() - rect.right, paramFloatingActionButton.getBottom() - rect.bottom);
    return true;
  }
  
  public boolean isAutoHideEnabled() {
    return this.autoHideEnabled;
  }
  
  public void onAttachedToLayoutParams(CoordinatorLayout.LayoutParams paramLayoutParams) {
    if (paramLayoutParams.dodgeInsetEdges == 0)
      paramLayoutParams.dodgeInsetEdges = 80; 
  }
  
  public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton, View paramView) {
    if (paramView instanceof AppBarLayout) {
      updateFabVisibilityForAppBarLayout(paramCoordinatorLayout, (AppBarLayout)paramView, paramFloatingActionButton);
    } else if (isBottomSheet(paramView)) {
      updateFabVisibilityForBottomSheet(paramView, paramFloatingActionButton);
    } 
    return false;
  }
  
  public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton, int paramInt) {
    List<View> list = paramCoordinatorLayout.getDependencies((View)paramFloatingActionButton);
    int i = list.size();
    for (byte b = 0; b < i; b++) {
      View view = list.get(b);
      if ((view instanceof AppBarLayout) ? updateFabVisibilityForAppBarLayout(paramCoordinatorLayout, (AppBarLayout)view, paramFloatingActionButton) : (isBottomSheet(view) && updateFabVisibilityForBottomSheet(view, paramFloatingActionButton)))
        break; 
    } 
    paramCoordinatorLayout.onLayoutChild((View)paramFloatingActionButton, paramInt);
    offsetIfNeeded(paramCoordinatorLayout, paramFloatingActionButton);
    return true;
  }
  
  public void setAutoHideEnabled(boolean paramBoolean) {
    this.autoHideEnabled = paramBoolean;
  }
  
  public void setInternalAutoHideListener(FloatingActionButton.OnVisibilityChangedListener paramOnVisibilityChangedListener) {
    this.internalAutoHideListener = paramOnVisibilityChangedListener;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\FloatingActionButton$BaseBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */