package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.design.R;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

public class ScrollingViewBehavior extends HeaderScrollingViewBehavior {
  public ScrollingViewBehavior() {}
  
  public ScrollingViewBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ScrollingViewBehavior_Layout);
    setOverlayTop(typedArray.getDimensionPixelSize(R.styleable.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
    typedArray.recycle();
  }
  
  private static int getAppBarLayoutOffset(AppBarLayout paramAppBarLayout) {
    CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)paramAppBarLayout.getLayoutParams()).getBehavior();
    return (behavior instanceof AppBarLayout.BaseBehavior) ? ((AppBarLayout.BaseBehavior)behavior).getTopBottomOffsetForScrollingSibling() : 0;
  }
  
  private void offsetChildAsNeeded(View paramView1, View paramView2) {
    CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)paramView2.getLayoutParams()).getBehavior();
    if (behavior instanceof AppBarLayout.BaseBehavior) {
      behavior = behavior;
      ViewCompat.offsetTopAndBottom(paramView1, paramView2.getBottom() - paramView1.getTop() + AppBarLayout.BaseBehavior.access$000((AppBarLayout.BaseBehavior)behavior) + getVerticalLayoutGap() - getOverlapPixelsForOffset(paramView2));
    } 
  }
  
  private void updateLiftedStateIfNeeded(View paramView1, View paramView2) {
    if (paramView2 instanceof AppBarLayout) {
      AppBarLayout appBarLayout = (AppBarLayout)paramView2;
      if (appBarLayout.isLiftOnScroll()) {
        boolean bool;
        if (paramView1.getScrollY() > 0) {
          bool = true;
        } else {
          bool = false;
        } 
        appBarLayout.setLiftedState(bool);
      } 
    } 
  }
  
  AppBarLayout findFirstDependency(List<View> paramList) {
    int i = paramList.size();
    for (byte b = 0; b < i; b++) {
      View view = paramList.get(b);
      if (view instanceof AppBarLayout)
        return (AppBarLayout)view; 
    } 
    return null;
  }
  
  float getOverlapRatioForOffset(View paramView) {
    if (paramView instanceof AppBarLayout) {
      AppBarLayout appBarLayout = (AppBarLayout)paramView;
      int i = appBarLayout.getTotalScrollRange();
      int j = appBarLayout.getDownNestedPreScrollRange();
      int k = getAppBarLayoutOffset(appBarLayout);
      if (j != 0 && i + k <= j)
        return 0.0F; 
      j = i - j;
      if (j != 0)
        return k / j + 1.0F; 
    } 
    return 0.0F;
  }
  
  int getScrollRange(View paramView) {
    return (paramView instanceof AppBarLayout) ? ((AppBarLayout)paramView).getTotalScrollRange() : super.getScrollRange(paramView);
  }
  
  public boolean layoutDependsOn(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2) {
    return paramView2 instanceof AppBarLayout;
  }
  
  public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2) {
    offsetChildAsNeeded(paramView1, paramView2);
    updateLiftedStateIfNeeded(paramView1, paramView2);
    return false;
  }
  
  public boolean onRequestChildRectangleOnScreen(CoordinatorLayout paramCoordinatorLayout, View paramView, Rect paramRect, boolean paramBoolean) {
    AppBarLayout appBarLayout = findFirstDependency(paramCoordinatorLayout.getDependencies(paramView));
    if (appBarLayout != null) {
      paramRect.offset(paramView.getLeft(), paramView.getTop());
      Rect rect = this.tempRect1;
      rect.set(0, 0, paramCoordinatorLayout.getWidth(), paramCoordinatorLayout.getHeight());
      if (!rect.contains(paramRect)) {
        appBarLayout.setExpanded(false, paramBoolean ^ true);
        return true;
      } 
    } 
    return false;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$ScrollingViewBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */