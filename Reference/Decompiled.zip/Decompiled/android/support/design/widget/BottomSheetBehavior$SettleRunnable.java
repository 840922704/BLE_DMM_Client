package android.support.design.widget;

import android.support.v4.view.ViewCompat;
import android.view.View;

class SettleRunnable implements Runnable {
  private final int targetState;
  
  private final View view;
  
  SettleRunnable(View paramView, int paramInt) {
    this.view = paramView;
    this.targetState = paramInt;
  }
  
  public void run() {
    if (BottomSheetBehavior.this.viewDragHelper != null && BottomSheetBehavior.this.viewDragHelper.continueSettling(true)) {
      ViewCompat.postOnAnimation(this.view, this);
    } else {
      BottomSheetBehavior.this.setStateInternal(this.targetState);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetBehavior$SettleRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */