package android.support.design.widget;

class null implements FloatingActionButtonImpl.InternalVisibilityChangedListener {
  public void onHidden() {
    listener.onHidden(FloatingActionButton.this);
  }
  
  public void onShown() {
    listener.onShown(FloatingActionButton.this);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\FloatingActionButton$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */