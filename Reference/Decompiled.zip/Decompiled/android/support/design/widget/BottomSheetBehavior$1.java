package android.support.design.widget;

import android.view.View;

class null implements Runnable {
  public void run() {
    BottomSheetBehavior.this.startSettlingAnimation(child, finalState);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetBehavior$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */