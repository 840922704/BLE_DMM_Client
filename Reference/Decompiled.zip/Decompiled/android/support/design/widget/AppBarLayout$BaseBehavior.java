package android.support.design.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.animation.AnimationUtils;
import android.support.v4.math.MathUtils;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.List;

public class BaseBehavior<T extends AppBarLayout> extends HeaderBehavior<T> {
  private static final int INVALID_POSITION = -1;
  
  private static final int MAX_OFFSET_ANIMATION_DURATION = 600;
  
  private WeakReference<View> lastNestedScrollingChildRef;
  
  private int lastStartedType;
  
  private ValueAnimator offsetAnimator;
  
  private int offsetDelta;
  
  private int offsetToChildIndexOnLayout = -1;
  
  private boolean offsetToChildIndexOnLayoutIsMinHeight;
  
  private float offsetToChildIndexOnLayoutPerc;
  
  private BaseDragCallback onDragCallback;
  
  public BaseBehavior() {}
  
  public BaseBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private void animateOffsetTo(CoordinatorLayout paramCoordinatorLayout, T paramT, int paramInt, float paramFloat) {
    int i = Math.abs(getTopBottomOffsetForScrollingSibling() - paramInt);
    paramFloat = Math.abs(paramFloat);
    if (paramFloat > 0.0F) {
      i = Math.round(i / paramFloat * 1000.0F) * 3;
    } else {
      i = (int)((i / paramT.getHeight() + 1.0F) * 150.0F);
    } 
    animateOffsetWithDuration(paramCoordinatorLayout, paramT, paramInt, i);
  }
  
  private void animateOffsetWithDuration(CoordinatorLayout paramCoordinatorLayout, final T child, int paramInt1, int paramInt2) {
    final ValueAnimator coordinatorLayout;
    int i = getTopBottomOffsetForScrollingSibling();
    if (i == paramInt1) {
      valueAnimator1 = this.offsetAnimator;
      if (valueAnimator1 != null && valueAnimator1.isRunning())
        this.offsetAnimator.cancel(); 
      return;
    } 
    ValueAnimator valueAnimator2 = this.offsetAnimator;
    if (valueAnimator2 == null) {
      this.offsetAnimator = new ValueAnimator();
      this.offsetAnimator.setInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
      this.offsetAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator param2ValueAnimator) {
              AppBarLayout.BaseBehavior.this.setHeaderTopBottomOffset(coordinatorLayout, child, ((Integer)param2ValueAnimator.getAnimatedValue()).intValue());
            }
          });
    } else {
      valueAnimator2.cancel();
    } 
    this.offsetAnimator.setDuration(Math.min(paramInt2, 600));
    this.offsetAnimator.setIntValues(new int[] { i, paramInt1 });
    this.offsetAnimator.start();
  }
  
  private boolean canScrollChildren(CoordinatorLayout paramCoordinatorLayout, T paramT, View paramView) {
    boolean bool;
    if (paramT.hasScrollableChildren() && paramCoordinatorLayout.getHeight() - paramView.getHeight() <= paramT.getHeight()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean checkFlag(int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt1 & paramInt2) == paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private View findFirstScrollingChild(CoordinatorLayout paramCoordinatorLayout) {
    int i = paramCoordinatorLayout.getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = paramCoordinatorLayout.getChildAt(b);
      if (view instanceof android.support.v4.view.NestedScrollingChild)
        return view; 
    } 
    return null;
  }
  
  private static View getAppBarChildOnOffset(AppBarLayout paramAppBarLayout, int paramInt) {
    int i = Math.abs(paramInt);
    int j = paramAppBarLayout.getChildCount();
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = paramAppBarLayout.getChildAt(paramInt);
      if (i >= view.getTop() && i <= view.getBottom())
        return view; 
    } 
    return null;
  }
  
  private int getChildIndexOnOffset(T paramT, int paramInt) {
    int i = paramT.getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = paramT.getChildAt(b);
      int j = view.getTop();
      int k = view.getBottom();
      AppBarLayout.LayoutParams layoutParams = (AppBarLayout.LayoutParams)view.getLayoutParams();
      int m = j;
      int n = k;
      if (checkFlag(layoutParams.getScrollFlags(), 32)) {
        m = j - layoutParams.topMargin;
        n = k + layoutParams.bottomMargin;
      } 
      k = -paramInt;
      if (m <= k && n >= k)
        return b; 
    } 
    return -1;
  }
  
  private int interpolateOffset(T paramT, int paramInt) {
    int i = Math.abs(paramInt);
    int j = paramT.getChildCount();
    int k = 0;
    for (int m = 0; m < j; m++) {
      View view = paramT.getChildAt(m);
      AppBarLayout.LayoutParams layoutParams = (AppBarLayout.LayoutParams)view.getLayoutParams();
      Interpolator interpolator = layoutParams.getScrollInterpolator();
      if (i >= view.getTop() && i <= view.getBottom()) {
        if (interpolator != null) {
          j = layoutParams.getScrollFlags();
          m = k;
          if ((j & 0x1) != 0) {
            k = 0 + view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            m = k;
            if ((j & 0x2) != 0)
              m = k - ViewCompat.getMinimumHeight(view); 
          } 
          k = m;
          if (ViewCompat.getFitsSystemWindows(view))
            k = m - paramT.getTopInset(); 
          if (k > 0) {
            m = view.getTop();
            float f = k;
            m = Math.round(f * interpolator.getInterpolation((i - m) / f));
            return Integer.signum(paramInt) * (view.getTop() + m);
          } 
        } 
        break;
      } 
    } 
    return paramInt;
  }
  
  private boolean shouldJumpElevationState(CoordinatorLayout paramCoordinatorLayout, T paramT) {
    List<View> list = paramCoordinatorLayout.getDependents((View)paramT);
    int i = list.size();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)((View)list.get(b)).getLayoutParams()).getBehavior();
      if (behavior instanceof AppBarLayout.ScrollingViewBehavior) {
        if (((AppBarLayout.ScrollingViewBehavior)behavior).getOverlayTop() != 0)
          bool = true; 
        return bool;
      } 
    } 
    return false;
  }
  
  private void snapToChildIfNeeded(CoordinatorLayout paramCoordinatorLayout, T paramT) {
    int i = getTopBottomOffsetForScrollingSibling();
    int j = getChildIndexOnOffset(paramT, i);
    if (j >= 0) {
      View view = paramT.getChildAt(j);
      AppBarLayout.LayoutParams layoutParams = (AppBarLayout.LayoutParams)view.getLayoutParams();
      int k = layoutParams.getScrollFlags();
      if ((k & 0x11) == 17) {
        int m = -view.getTop();
        int n = -view.getBottom();
        int i1 = n;
        if (j == paramT.getChildCount() - 1)
          i1 = n + paramT.getTopInset(); 
        if (checkFlag(k, 2)) {
          n = i1 + ViewCompat.getMinimumHeight(view);
          j = m;
        } else {
          j = m;
          n = i1;
          if (checkFlag(k, 5)) {
            n = ViewCompat.getMinimumHeight(view) + i1;
            if (i < n) {
              j = n;
              n = i1;
            } else {
              j = m;
            } 
          } 
        } 
        m = j;
        i1 = n;
        if (checkFlag(k, 32)) {
          m = j + layoutParams.topMargin;
          i1 = n - layoutParams.bottomMargin;
        } 
        n = m;
        if (i < (i1 + m) / 2)
          n = i1; 
        animateOffsetTo(paramCoordinatorLayout, paramT, MathUtils.clamp(n, -paramT.getTotalScrollRange(), 0), 0.0F);
      } 
    } 
  }
  
  private void stopNestedScrollIfNeeded(int paramInt1, T paramT, View paramView, int paramInt2) {
    if (paramInt2 == 1) {
      paramInt2 = getTopBottomOffsetForScrollingSibling();
      if ((paramInt1 < 0 && paramInt2 == 0) || (paramInt1 > 0 && paramInt2 == -paramT.getDownNestedScrollRange()))
        ViewCompat.stopNestedScroll(paramView, 1); 
    } 
  }
  
  private void updateAppBarLayoutDrawableState(CoordinatorLayout paramCoordinatorLayout, T paramT, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_2
    //   1: iload_3
    //   2: invokestatic getAppBarChildOnOffset : (Landroid/support/design/widget/AppBarLayout;I)Landroid/view/View;
    //   5: astore #6
    //   7: aload #6
    //   9: ifnull -> 190
    //   12: aload #6
    //   14: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   17: checkcast android/support/design/widget/AppBarLayout$LayoutParams
    //   20: invokevirtual getScrollFlags : ()I
    //   23: istore #7
    //   25: iload #7
    //   27: iconst_1
    //   28: iand
    //   29: ifeq -> 104
    //   32: aload #6
    //   34: invokestatic getMinimumHeight : (Landroid/view/View;)I
    //   37: istore #8
    //   39: iload #4
    //   41: ifle -> 76
    //   44: iload #7
    //   46: bipush #12
    //   48: iand
    //   49: ifeq -> 76
    //   52: iload_3
    //   53: ineg
    //   54: aload #6
    //   56: invokevirtual getBottom : ()I
    //   59: iload #8
    //   61: isub
    //   62: aload_2
    //   63: invokevirtual getTopInset : ()I
    //   66: isub
    //   67: if_icmplt -> 104
    //   70: iconst_1
    //   71: istore #9
    //   73: goto -> 107
    //   76: iload #7
    //   78: iconst_2
    //   79: iand
    //   80: ifeq -> 104
    //   83: iload_3
    //   84: ineg
    //   85: aload #6
    //   87: invokevirtual getBottom : ()I
    //   90: iload #8
    //   92: isub
    //   93: aload_2
    //   94: invokevirtual getTopInset : ()I
    //   97: isub
    //   98: if_icmplt -> 104
    //   101: goto -> 70
    //   104: iconst_0
    //   105: istore #9
    //   107: iload #9
    //   109: istore #10
    //   111: aload_2
    //   112: invokevirtual isLiftOnScroll : ()Z
    //   115: ifeq -> 151
    //   118: aload_0
    //   119: aload_1
    //   120: invokespecial findFirstScrollingChild : (Landroid/support/design/widget/CoordinatorLayout;)Landroid/view/View;
    //   123: astore #6
    //   125: iload #9
    //   127: istore #10
    //   129: aload #6
    //   131: ifnull -> 151
    //   134: aload #6
    //   136: invokevirtual getScrollY : ()I
    //   139: ifle -> 148
    //   142: iconst_1
    //   143: istore #10
    //   145: goto -> 151
    //   148: iconst_0
    //   149: istore #10
    //   151: aload_2
    //   152: iload #10
    //   154: invokevirtual setLiftedState : (Z)Z
    //   157: istore #10
    //   159: getstatic android/os/Build$VERSION.SDK_INT : I
    //   162: bipush #11
    //   164: if_icmplt -> 190
    //   167: iload #5
    //   169: ifne -> 186
    //   172: iload #10
    //   174: ifeq -> 190
    //   177: aload_0
    //   178: aload_1
    //   179: aload_2
    //   180: invokespecial shouldJumpElevationState : (Landroid/support/design/widget/CoordinatorLayout;Landroid/support/design/widget/AppBarLayout;)Z
    //   183: ifeq -> 190
    //   186: aload_2
    //   187: invokevirtual jumpDrawablesToCurrentState : ()V
    //   190: return
  }
  
  boolean canDragView(T paramT) {
    BaseDragCallback<T> baseDragCallback = this.onDragCallback;
    if (baseDragCallback != null)
      return baseDragCallback.canDrag(paramT); 
    WeakReference<View> weakReference = this.lastNestedScrollingChildRef;
    boolean bool1 = true;
    boolean bool2 = bool1;
    if (weakReference != null) {
      View view = weakReference.get();
      if (view != null && view.isShown() && !view.canScrollVertically(-1)) {
        bool2 = bool1;
      } else {
        bool2 = false;
      } 
    } 
    return bool2;
  }
  
  int getMaxDragOffset(T paramT) {
    return -paramT.getDownNestedScrollRange();
  }
  
  int getScrollRangeForDragFling(T paramT) {
    return paramT.getTotalScrollRange();
  }
  
  int getTopBottomOffsetForScrollingSibling() {
    return getTopAndBottomOffset() + this.offsetDelta;
  }
  
  boolean isOffsetAnimatorRunning() {
    boolean bool;
    ValueAnimator valueAnimator = this.offsetAnimator;
    if (valueAnimator != null && valueAnimator.isRunning()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void onFlingFinished(CoordinatorLayout paramCoordinatorLayout, T paramT) {
    snapToChildIfNeeded(paramCoordinatorLayout, paramT);
  }
  
  public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, T paramT, int paramInt) {
    boolean bool = super.onLayoutChild(paramCoordinatorLayout, paramT, paramInt);
    int i = paramT.getPendingAction();
    paramInt = this.offsetToChildIndexOnLayout;
    if (paramInt >= 0 && (i & 0x8) == 0) {
      View view = paramT.getChildAt(paramInt);
      i = -view.getBottom();
      if (this.offsetToChildIndexOnLayoutIsMinHeight) {
        paramInt = ViewCompat.getMinimumHeight(view) + paramT.getTopInset();
      } else {
        paramInt = Math.round(view.getHeight() * this.offsetToChildIndexOnLayoutPerc);
      } 
      setHeaderTopBottomOffset(paramCoordinatorLayout, paramT, i + paramInt);
    } else if (i != 0) {
      if ((i & 0x4) != 0) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if ((i & 0x2) != 0) {
        i = -paramT.getUpNestedPreScrollRange();
        if (paramInt != 0) {
          animateOffsetTo(paramCoordinatorLayout, paramT, i, 0.0F);
        } else {
          setHeaderTopBottomOffset(paramCoordinatorLayout, paramT, i);
        } 
      } else if ((i & 0x1) != 0) {
        if (paramInt != 0) {
          animateOffsetTo(paramCoordinatorLayout, paramT, 0, 0.0F);
        } else {
          setHeaderTopBottomOffset(paramCoordinatorLayout, paramT, 0);
        } 
      } 
    } 
    paramT.resetPendingAction();
    this.offsetToChildIndexOnLayout = -1;
    setTopAndBottomOffset(MathUtils.clamp(getTopAndBottomOffset(), -paramT.getTotalScrollRange(), 0));
    updateAppBarLayoutDrawableState(paramCoordinatorLayout, paramT, getTopAndBottomOffset(), 0, true);
    paramT.dispatchOffsetUpdates(getTopAndBottomOffset());
    return bool;
  }
  
  public boolean onMeasureChild(CoordinatorLayout paramCoordinatorLayout, T paramT, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (((CoordinatorLayout.LayoutParams)paramT.getLayoutParams()).height == -2) {
      paramCoordinatorLayout.onMeasureChild((View)paramT, paramInt1, paramInt2, View.MeasureSpec.makeMeasureSpec(0, 0), paramInt4);
      return true;
    } 
    return super.onMeasureChild(paramCoordinatorLayout, paramT, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, T paramT, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt2 != 0) {
      byte b;
      if (paramInt2 < 0) {
        b = -paramT.getTotalScrollRange();
        int i = paramT.getDownNestedPreScrollRange();
        paramInt1 = b;
        b = i + b;
      } else {
        paramInt1 = -paramT.getUpNestedPreScrollRange();
        b = 0;
      } 
      if (paramInt1 != b) {
        paramArrayOfint[1] = scroll(paramCoordinatorLayout, paramT, paramInt2, paramInt1, b);
        stopNestedScrollIfNeeded(paramInt2, paramT, paramView, paramInt3);
      } 
    } 
  }
  
  public void onNestedScroll(CoordinatorLayout paramCoordinatorLayout, T paramT, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt4 < 0) {
      scroll(paramCoordinatorLayout, paramT, paramInt4, -paramT.getDownNestedScrollRange(), 0);
      stopNestedScrollIfNeeded(paramInt4, paramT, paramView, paramInt5);
    } 
    if (paramT.isLiftOnScroll()) {
      boolean bool;
      if (paramView.getScrollY() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      paramT.setLiftedState(bool);
    } 
  }
  
  public void onRestoreInstanceState(CoordinatorLayout paramCoordinatorLayout, T paramT, Parcelable paramParcelable) {
    SavedState savedState;
    if (paramParcelable instanceof SavedState) {
      savedState = (SavedState)paramParcelable;
      super.onRestoreInstanceState(paramCoordinatorLayout, paramT, savedState.getSuperState());
      this.offsetToChildIndexOnLayout = savedState.firstVisibleChildIndex;
      this.offsetToChildIndexOnLayoutPerc = savedState.firstVisibleChildPercentageShown;
      this.offsetToChildIndexOnLayoutIsMinHeight = savedState.firstVisibleChildAtMinimumHeight;
    } else {
      super.onRestoreInstanceState(paramCoordinatorLayout, paramT, (Parcelable)savedState);
      this.offsetToChildIndexOnLayout = -1;
    } 
  }
  
  public Parcelable onSaveInstanceState(CoordinatorLayout paramCoordinatorLayout, T paramT) {
    SavedState savedState;
    Parcelable parcelable = super.onSaveInstanceState(paramCoordinatorLayout, paramT);
    int i = getTopAndBottomOffset();
    int j = paramT.getChildCount();
    boolean bool = false;
    for (byte b = 0; b < j; b++) {
      View view = paramT.getChildAt(b);
      int k = view.getBottom() + i;
      if (view.getTop() + i <= 0 && k >= 0) {
        savedState = new SavedState(parcelable);
        savedState.firstVisibleChildIndex = b;
        if (k == ViewCompat.getMinimumHeight(view) + paramT.getTopInset())
          bool = true; 
        savedState.firstVisibleChildAtMinimumHeight = bool;
        savedState.firstVisibleChildPercentageShown = k / view.getHeight();
        return (Parcelable)savedState;
      } 
    } 
    return (Parcelable)savedState;
  }
  
  public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, T paramT, View paramView1, View paramView2, int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt1 & 0x2) != 0 && (paramT.isLiftOnScroll() || canScrollChildren(paramCoordinatorLayout, paramT, paramView1))) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      ValueAnimator valueAnimator = this.offsetAnimator;
      if (valueAnimator != null)
        valueAnimator.cancel(); 
    } 
    this.lastNestedScrollingChildRef = null;
    this.lastStartedType = paramInt2;
    return bool;
  }
  
  public void onStopNestedScroll(CoordinatorLayout paramCoordinatorLayout, T paramT, View paramView, int paramInt) {
    if (this.lastStartedType == 0 || paramInt == 1)
      snapToChildIfNeeded(paramCoordinatorLayout, paramT); 
    this.lastNestedScrollingChildRef = new WeakReference<View>(paramView);
  }
  
  public void setDragCallback(BaseDragCallback paramBaseDragCallback) {
    this.onDragCallback = paramBaseDragCallback;
  }
  
  int setHeaderTopBottomOffset(CoordinatorLayout paramCoordinatorLayout, T paramT, int paramInt1, int paramInt2, int paramInt3) {
    int i = getTopBottomOffsetForScrollingSibling();
    boolean bool = false;
    if (paramInt2 != 0 && i >= paramInt2 && i <= paramInt3) {
      paramInt2 = MathUtils.clamp(paramInt1, paramInt2, paramInt3);
      paramInt1 = bool;
      if (i != paramInt2) {
        if (paramT.hasChildWithInterpolator()) {
          paramInt1 = interpolateOffset(paramT, paramInt2);
        } else {
          paramInt1 = paramInt2;
        } 
        boolean bool1 = setTopAndBottomOffset(paramInt1);
        paramInt3 = i - paramInt2;
        this.offsetDelta = paramInt2 - paramInt1;
        if (!bool1 && paramT.hasChildWithInterpolator())
          paramCoordinatorLayout.dispatchDependentViewsChanged((View)paramT); 
        paramT.dispatchOffsetUpdates(getTopAndBottomOffset());
        if (paramInt2 < i) {
          paramInt1 = -1;
        } else {
          paramInt1 = 1;
        } 
        updateAppBarLayoutDrawableState(paramCoordinatorLayout, paramT, paramInt2, paramInt1, false);
        paramInt1 = paramInt3;
      } 
    } else {
      this.offsetDelta = 0;
      paramInt1 = bool;
    } 
    return paramInt1;
  }
  
  public static abstract class BaseDragCallback<T extends AppBarLayout> {
    public abstract boolean canDrag(T param2T);
  }
  
  protected static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param3Parcel) {
          return new AppBarLayout.BaseBehavior.SavedState(param3Parcel, null);
        }
        
        public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
          return new AppBarLayout.BaseBehavior.SavedState(param3Parcel, param3ClassLoader);
        }
        
        public AppBarLayout.BaseBehavior.SavedState[] newArray(int param3Int) {
          return new AppBarLayout.BaseBehavior.SavedState[param3Int];
        }
      };
    
    boolean firstVisibleChildAtMinimumHeight;
    
    int firstVisibleChildIndex;
    
    float firstVisibleChildPercentageShown;
    
    public SavedState(Parcel param2Parcel, ClassLoader param2ClassLoader) {
      super(param2Parcel, param2ClassLoader);
      boolean bool;
      this.firstVisibleChildIndex = param2Parcel.readInt();
      this.firstVisibleChildPercentageShown = param2Parcel.readFloat();
      if (param2Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.firstVisibleChildAtMinimumHeight = bool;
    }
    
    public SavedState(Parcelable param2Parcelable) {
      super(param2Parcelable);
    }
    
    public void writeToParcel(Parcel param2Parcel, int param2Int) {
      super.writeToParcel(param2Parcel, param2Int);
      param2Parcel.writeInt(this.firstVisibleChildIndex);
      param2Parcel.writeFloat(this.firstVisibleChildPercentageShown);
      param2Parcel.writeByte((byte)this.firstVisibleChildAtMinimumHeight);
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
    public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param2Parcel) {
      return new AppBarLayout.BaseBehavior.SavedState(param2Parcel, null);
    }
    
    public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
      return new AppBarLayout.BaseBehavior.SavedState(param2Parcel, param2ClassLoader);
    }
    
    public AppBarLayout.BaseBehavior.SavedState[] newArray(int param2Int) {
      return new AppBarLayout.BaseBehavior.SavedState[param2Int];
    }
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$BaseBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */