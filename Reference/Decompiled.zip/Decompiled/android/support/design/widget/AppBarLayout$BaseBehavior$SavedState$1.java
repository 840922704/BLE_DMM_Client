package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<AppBarLayout.BaseBehavior.SavedState> {
  public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel paramParcel) {
    return new AppBarLayout.BaseBehavior.SavedState(paramParcel, null);
  }
  
  public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new AppBarLayout.BaseBehavior.SavedState(paramParcel, paramClassLoader);
  }
  
  public AppBarLayout.BaseBehavior.SavedState[] newArray(int paramInt) {
    return new AppBarLayout.BaseBehavior.SavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$BaseBehavior$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */