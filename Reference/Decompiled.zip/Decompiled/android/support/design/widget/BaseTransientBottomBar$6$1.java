package android.support.design.widget;

class null implements Runnable {
  public void run() {
    this.this$1.this$0.onViewHidden(3);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$6$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */