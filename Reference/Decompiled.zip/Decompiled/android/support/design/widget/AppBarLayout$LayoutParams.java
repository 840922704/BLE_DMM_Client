package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.design.R;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LayoutParams extends LinearLayout.LayoutParams {
  static final int COLLAPSIBLE_FLAGS = 10;
  
  static final int FLAG_QUICK_RETURN = 5;
  
  static final int FLAG_SNAP = 17;
  
  public static final int SCROLL_FLAG_ENTER_ALWAYS = 4;
  
  public static final int SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED = 8;
  
  public static final int SCROLL_FLAG_EXIT_UNTIL_COLLAPSED = 2;
  
  public static final int SCROLL_FLAG_SCROLL = 1;
  
  public static final int SCROLL_FLAG_SNAP = 16;
  
  public static final int SCROLL_FLAG_SNAP_MARGINS = 32;
  
  int scrollFlags = 1;
  
  Interpolator scrollInterpolator;
  
  public LayoutParams(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public LayoutParams(int paramInt1, int paramInt2, float paramFloat) {
    super(paramInt1, paramInt2, paramFloat);
  }
  
  public LayoutParams(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.AppBarLayout_Layout);
    this.scrollFlags = typedArray.getInt(R.styleable.AppBarLayout_Layout_layout_scrollFlags, 0);
    if (typedArray.hasValue(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator))
      this.scrollInterpolator = AnimationUtils.loadInterpolator(paramContext, typedArray.getResourceId(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator, 0)); 
    typedArray.recycle();
  }
  
  public LayoutParams(LayoutParams paramLayoutParams) {
    super(paramLayoutParams);
    this.scrollFlags = paramLayoutParams.scrollFlags;
    this.scrollInterpolator = paramLayoutParams.scrollInterpolator;
  }
  
  public LayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    super(paramLayoutParams);
  }
  
  public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    super(paramMarginLayoutParams);
  }
  
  public LayoutParams(LinearLayout.LayoutParams paramLayoutParams) {
    super(paramLayoutParams);
  }
  
  public int getScrollFlags() {
    return this.scrollFlags;
  }
  
  public Interpolator getScrollInterpolator() {
    return this.scrollInterpolator;
  }
  
  boolean isCollapsible() {
    int i = this.scrollFlags;
    boolean bool = true;
    if ((i & 0x1) != 1 || (i & 0xA) == 0)
      bool = false; 
    return bool;
  }
  
  public void setScrollFlags(int paramInt) {
    this.scrollFlags = paramInt;
  }
  
  public void setScrollInterpolator(Interpolator paramInterpolator) {
    this.scrollInterpolator = paramInterpolator;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ScrollFlags {}
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$LayoutParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */