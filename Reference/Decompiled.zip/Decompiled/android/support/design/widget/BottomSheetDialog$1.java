package android.support.design.widget;

import android.view.View;

class null implements View.OnClickListener {
  public void onClick(View paramView) {
    if (BottomSheetDialog.this.cancelable && BottomSheetDialog.this.isShowing() && BottomSheetDialog.this.shouldWindowCloseOnTouchOutside())
      BottomSheetDialog.this.cancel(); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetDialog$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */