package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.AbsSavedState;

public class SavedState extends AbsSavedState {
  public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
      public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param3Parcel) {
        return new AppBarLayout.BaseBehavior.SavedState(param3Parcel, null);
      }
      
      public AppBarLayout.BaseBehavior.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
        return new AppBarLayout.BaseBehavior.SavedState(param3Parcel, param3ClassLoader);
      }
      
      public AppBarLayout.BaseBehavior.SavedState[] newArray(int param3Int) {
        return new AppBarLayout.BaseBehavior.SavedState[param3Int];
      }
    };
  
  boolean firstVisibleChildAtMinimumHeight;
  
  int firstVisibleChildIndex;
  
  float firstVisibleChildPercentageShown;
  
  public SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    boolean bool;
    this.firstVisibleChildIndex = paramParcel.readInt();
    this.firstVisibleChildPercentageShown = paramParcel.readFloat();
    if (paramParcel.readByte() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.firstVisibleChildAtMinimumHeight = bool;
  }
  
  public SavedState(Parcelable paramParcelable) {
    super(paramParcelable);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.firstVisibleChildIndex);
    paramParcel.writeFloat(this.firstVisibleChildPercentageShown);
    paramParcel.writeByte((byte)this.firstVisibleChildAtMinimumHeight);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$BaseBehavior$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */