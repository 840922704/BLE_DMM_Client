package android.support.design.widget;

import android.view.View;

class null implements SwipeDismissBehavior.OnDismissListener {
  public void onDismiss(View paramView) {
    paramView.setVisibility(8);
    BaseTransientBottomBar.this.dispatchDismiss(0);
  }
  
  public void onDragStateChanged(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1 || paramInt == 2)
        SnackbarManager.getInstance().pauseTimeout(BaseTransientBottomBar.this.managerCallback); 
    } else {
      SnackbarManager.getInstance().restoreTimeoutIfPaused(BaseTransientBottomBar.this.managerCallback);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */