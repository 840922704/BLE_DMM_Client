package android.support.design.widget;

import android.support.v4.view.accessibility.AccessibilityManagerCompat;

class null implements AccessibilityManagerCompat.TouchExplorationStateChangeListener {
  public void onTouchExplorationStateChanged(boolean paramBoolean) {
    BaseTransientBottomBar.SnackbarBaseLayout.access$300(BaseTransientBottomBar.SnackbarBaseLayout.this, paramBoolean);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$SnackbarBaseLayout$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */