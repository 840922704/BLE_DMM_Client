package android.support.design.widget;

import android.animation.ValueAnimator;
import android.support.v4.view.ViewCompat;
import android.view.View;

class null implements ValueAnimator.AnimatorUpdateListener {
  private int previousAnimatedIntValue = 0;
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    int i = ((Integer)paramValueAnimator.getAnimatedValue()).intValue();
    if (BaseTransientBottomBar.access$200()) {
      ViewCompat.offsetTopAndBottom((View)BaseTransientBottomBar.this.view, i - this.previousAnimatedIntValue);
    } else {
      BaseTransientBottomBar.this.view.setTranslationY(i);
    } 
    this.previousAnimatedIntValue = i;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */