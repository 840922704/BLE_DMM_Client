package android.support.design.widget;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public abstract class BaseCallback<B> {
  public static final int DISMISS_EVENT_ACTION = 1;
  
  public static final int DISMISS_EVENT_CONSECUTIVE = 4;
  
  public static final int DISMISS_EVENT_MANUAL = 3;
  
  public static final int DISMISS_EVENT_SWIPE = 0;
  
  public static final int DISMISS_EVENT_TIMEOUT = 2;
  
  public void onDismissed(B paramB, int paramInt) {}
  
  public void onShown(B paramB) {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface DismissEvent {}
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$BaseCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */