package android.support.design.widget;

class null implements SnackbarManager.Callback {
  public void dismiss(int paramInt) {
    BaseTransientBottomBar.handler.sendMessage(BaseTransientBottomBar.handler.obtainMessage(1, paramInt, 0, BaseTransientBottomBar.this));
  }
  
  public void show() {
    BaseTransientBottomBar.handler.sendMessage(BaseTransientBottomBar.handler.obtainMessage(0, BaseTransientBottomBar.this));
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */