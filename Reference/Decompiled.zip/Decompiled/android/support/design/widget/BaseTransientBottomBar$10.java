package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    BaseTransientBottomBar.this.onViewHidden(event);
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    BaseTransientBottomBar.access$100(BaseTransientBottomBar.this).animateContentOut(0, 180);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$10.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */