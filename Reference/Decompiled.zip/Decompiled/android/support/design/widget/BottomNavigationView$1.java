package android.support.design.widget;

import android.support.v7.view.menu.MenuBuilder;
import android.view.MenuItem;

class null implements MenuBuilder.Callback {
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem) {
    BottomNavigationView.OnNavigationItemReselectedListener onNavigationItemReselectedListener = BottomNavigationView.access$000(BottomNavigationView.this);
    boolean bool = true;
    if (onNavigationItemReselectedListener != null && paramMenuItem.getItemId() == BottomNavigationView.this.getSelectedItemId()) {
      BottomNavigationView.access$000(BottomNavigationView.this).onNavigationItemReselected(paramMenuItem);
      return true;
    } 
    if (BottomNavigationView.access$100(BottomNavigationView.this) == null || BottomNavigationView.access$100(BottomNavigationView.this).onNavigationItemSelected(paramMenuItem))
      bool = false; 
    return bool;
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder) {}
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomNavigationView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */