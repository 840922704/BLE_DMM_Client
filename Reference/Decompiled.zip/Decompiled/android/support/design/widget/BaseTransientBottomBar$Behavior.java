package android.support.design.widget;

import android.view.MotionEvent;
import android.view.View;

public class Behavior extends SwipeDismissBehavior<View> {
  private final BaseTransientBottomBar.BehaviorDelegate delegate = new BaseTransientBottomBar.BehaviorDelegate(this);
  
  private void setBaseTransientBottomBar(BaseTransientBottomBar<?> paramBaseTransientBottomBar) {
    this.delegate.setBaseTransientBottomBar(paramBaseTransientBottomBar);
  }
  
  public boolean canSwipeDismissView(View paramView) {
    return this.delegate.canSwipeDismissView(paramView);
  }
  
  public boolean onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    this.delegate.onInterceptTouchEvent(paramCoordinatorLayout, paramView, paramMotionEvent);
    return super.onInterceptTouchEvent(paramCoordinatorLayout, paramView, paramMotionEvent);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */