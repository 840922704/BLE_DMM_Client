package android.support.design.widget;

public interface BaseOnOffsetChangedListener<T extends AppBarLayout> {
  void onOffsetChanged(T paramT, int paramInt);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\AppBarLayout$BaseOnOffsetChangedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */