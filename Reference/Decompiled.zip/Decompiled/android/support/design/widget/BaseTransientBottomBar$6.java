package android.support.design.widget;

import android.view.View;

class null implements BaseTransientBottomBar.OnAttachStateChangeListener {
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    if (BaseTransientBottomBar.this.isShownOrQueued())
      BaseTransientBottomBar.handler.post(new Runnable() {
            public void run() {
              BaseTransientBottomBar.this.onViewHidden(3);
            }
          }); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */