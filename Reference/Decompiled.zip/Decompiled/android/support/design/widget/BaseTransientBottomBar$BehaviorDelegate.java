package android.support.design.widget;

import android.view.MotionEvent;
import android.view.View;

public class BehaviorDelegate {
  private SnackbarManager.Callback managerCallback;
  
  public BehaviorDelegate(SwipeDismissBehavior<?> paramSwipeDismissBehavior) {
    paramSwipeDismissBehavior.setStartAlphaSwipeDistance(0.1F);
    paramSwipeDismissBehavior.setEndAlphaSwipeDistance(0.6F);
    paramSwipeDismissBehavior.setSwipeDirection(0);
  }
  
  public boolean canSwipeDismissView(View paramView) {
    return paramView instanceof BaseTransientBottomBar.SnackbarBaseLayout;
  }
  
  public void onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i == 1 || i == 3)
        SnackbarManager.getInstance().restoreTimeoutIfPaused(this.managerCallback); 
    } else if (paramCoordinatorLayout.isPointInChildBounds(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) {
      SnackbarManager.getInstance().pauseTimeout(this.managerCallback);
    } 
  }
  
  public void setBaseTransientBottomBar(BaseTransientBottomBar<?> paramBaseTransientBottomBar) {
    this.managerCallback = paramBaseTransientBottomBar.managerCallback;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$BehaviorDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */