package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class null extends AnimatorListenerAdapter {
  private boolean cancelled;
  
  public void onAnimationCancel(Animator paramAnimator) {
    this.cancelled = true;
  }
  
  public void onAnimationEnd(Animator paramAnimator) {
    FloatingActionButtonImpl floatingActionButtonImpl = FloatingActionButtonImpl.this;
    floatingActionButtonImpl.animState = 0;
    floatingActionButtonImpl.currentAnimator = null;
    if (!this.cancelled) {
      byte b;
      VisibilityAwareImageButton visibilityAwareImageButton = floatingActionButtonImpl.view;
      if (fromUser) {
        b = 8;
      } else {
        b = 4;
      } 
      visibilityAwareImageButton.internalSetVisibility(b, fromUser);
      FloatingActionButtonImpl.InternalVisibilityChangedListener internalVisibilityChangedListener = listener;
      if (internalVisibilityChangedListener != null)
        internalVisibilityChangedListener.onHidden(); 
    } 
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    FloatingActionButtonImpl.this.view.internalSetVisibility(0, fromUser);
    FloatingActionButtonImpl floatingActionButtonImpl = FloatingActionButtonImpl.this;
    floatingActionButtonImpl.animState = 1;
    floatingActionButtonImpl.currentAnimator = paramAnimator;
    this.cancelled = false;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\FloatingActionButtonImpl$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */