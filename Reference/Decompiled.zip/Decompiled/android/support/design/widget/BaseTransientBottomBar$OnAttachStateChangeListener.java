package android.support.design.widget;

import android.view.View;

public interface OnAttachStateChangeListener {
  void onViewAttachedToWindow(View paramView);
  
  void onViewDetachedFromWindow(View paramView);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$OnAttachStateChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */