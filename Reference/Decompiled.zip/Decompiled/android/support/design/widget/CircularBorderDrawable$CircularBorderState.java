package android.support.design.widget;

import android.graphics.drawable.Drawable;

class CircularBorderState extends Drawable.ConstantState {
  private CircularBorderState() {}
  
  public int getChangingConfigurations() {
    return 0;
  }
  
  public Drawable newDrawable() {
    return CircularBorderDrawable.this;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\CircularBorderDrawable$CircularBorderState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */