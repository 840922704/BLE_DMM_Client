package android.support.design.widget;

import android.support.v4.math.MathUtils;
import android.support.v4.widget.ViewDragHelper;
import android.view.View;

class null extends ViewDragHelper.Callback {
  public int clampViewPositionHorizontal(View paramView, int paramInt1, int paramInt2) {
    return paramView.getLeft();
  }
  
  public int clampViewPositionVertical(View paramView, int paramInt1, int paramInt2) {
    int i = BottomSheetBehavior.access$100(BottomSheetBehavior.this);
    if (BottomSheetBehavior.this.hideable) {
      paramInt2 = BottomSheetBehavior.this.parentHeight;
    } else {
      paramInt2 = BottomSheetBehavior.this.collapsedOffset;
    } 
    return MathUtils.clamp(paramInt1, i, paramInt2);
  }
  
  public int getViewVerticalDragRange(View paramView) {
    return BottomSheetBehavior.this.hideable ? BottomSheetBehavior.this.parentHeight : BottomSheetBehavior.this.collapsedOffset;
  }
  
  public void onViewDragStateChanged(int paramInt) {
    if (paramInt == 1)
      BottomSheetBehavior.this.setStateInternal(1); 
  }
  
  public void onViewPositionChanged(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    BottomSheetBehavior.this.dispatchOnSlide(paramInt2);
  }
  
  public void onViewReleased(View paramView, float paramFloat1, float paramFloat2) {
    // Byte code:
    //   0: iconst_4
    //   1: istore #4
    //   3: fload_3
    //   4: fconst_0
    //   5: fcmpg
    //   6: ifge -> 70
    //   9: aload_0
    //   10: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   13: invokestatic access$000 : (Landroid/support/design/widget/BottomSheetBehavior;)Z
    //   16: ifeq -> 34
    //   19: aload_0
    //   20: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   23: getfield fitToContentsOffset : I
    //   26: istore #5
    //   28: iconst_3
    //   29: istore #4
    //   31: goto -> 333
    //   34: aload_1
    //   35: invokevirtual getTop : ()I
    //   38: aload_0
    //   39: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   42: getfield halfExpandedOffset : I
    //   45: if_icmple -> 64
    //   48: aload_0
    //   49: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   52: getfield halfExpandedOffset : I
    //   55: istore #5
    //   57: bipush #6
    //   59: istore #4
    //   61: goto -> 333
    //   64: iconst_0
    //   65: istore #5
    //   67: goto -> 28
    //   70: aload_0
    //   71: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   74: getfield hideable : Z
    //   77: ifeq -> 133
    //   80: aload_0
    //   81: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   84: aload_1
    //   85: fload_3
    //   86: invokevirtual shouldHide : (Landroid/view/View;F)Z
    //   89: ifeq -> 133
    //   92: aload_1
    //   93: invokevirtual getTop : ()I
    //   96: aload_0
    //   97: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   100: getfield collapsedOffset : I
    //   103: if_icmpgt -> 118
    //   106: fload_2
    //   107: invokestatic abs : (F)F
    //   110: fload_3
    //   111: invokestatic abs : (F)F
    //   114: fcmpg
    //   115: ifge -> 133
    //   118: aload_0
    //   119: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   122: getfield parentHeight : I
    //   125: istore #5
    //   127: iconst_5
    //   128: istore #4
    //   130: goto -> 333
    //   133: fload_3
    //   134: fconst_0
    //   135: fcmpl
    //   136: ifeq -> 166
    //   139: fload_2
    //   140: invokestatic abs : (F)F
    //   143: fload_3
    //   144: invokestatic abs : (F)F
    //   147: fcmpl
    //   148: ifle -> 154
    //   151: goto -> 166
    //   154: aload_0
    //   155: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   158: getfield collapsedOffset : I
    //   161: istore #5
    //   163: goto -> 333
    //   166: aload_1
    //   167: invokevirtual getTop : ()I
    //   170: istore #5
    //   172: aload_0
    //   173: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   176: invokestatic access$000 : (Landroid/support/design/widget/BottomSheetBehavior;)Z
    //   179: ifeq -> 235
    //   182: iload #5
    //   184: aload_0
    //   185: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   188: getfield fitToContentsOffset : I
    //   191: isub
    //   192: invokestatic abs : (I)I
    //   195: iload #5
    //   197: aload_0
    //   198: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   201: getfield collapsedOffset : I
    //   204: isub
    //   205: invokestatic abs : (I)I
    //   208: if_icmpge -> 223
    //   211: aload_0
    //   212: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   215: getfield fitToContentsOffset : I
    //   218: istore #5
    //   220: goto -> 28
    //   223: aload_0
    //   224: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   227: getfield collapsedOffset : I
    //   230: istore #5
    //   232: goto -> 333
    //   235: iload #5
    //   237: aload_0
    //   238: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   241: getfield halfExpandedOffset : I
    //   244: if_icmpge -> 280
    //   247: iload #5
    //   249: iload #5
    //   251: aload_0
    //   252: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   255: getfield collapsedOffset : I
    //   258: isub
    //   259: invokestatic abs : (I)I
    //   262: if_icmpge -> 268
    //   265: goto -> 64
    //   268: aload_0
    //   269: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   272: getfield halfExpandedOffset : I
    //   275: istore #5
    //   277: goto -> 57
    //   280: iload #5
    //   282: aload_0
    //   283: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   286: getfield halfExpandedOffset : I
    //   289: isub
    //   290: invokestatic abs : (I)I
    //   293: iload #5
    //   295: aload_0
    //   296: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   299: getfield collapsedOffset : I
    //   302: isub
    //   303: invokestatic abs : (I)I
    //   306: if_icmpge -> 321
    //   309: aload_0
    //   310: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   313: getfield halfExpandedOffset : I
    //   316: istore #5
    //   318: goto -> 57
    //   321: aload_0
    //   322: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   325: getfield collapsedOffset : I
    //   328: istore #5
    //   330: goto -> 232
    //   333: aload_0
    //   334: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   337: getfield viewDragHelper : Landroid/support/v4/widget/ViewDragHelper;
    //   340: aload_1
    //   341: invokevirtual getLeft : ()I
    //   344: iload #5
    //   346: invokevirtual settleCapturedViewAt : (II)Z
    //   349: ifeq -> 381
    //   352: aload_0
    //   353: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   356: iconst_2
    //   357: invokevirtual setStateInternal : (I)V
    //   360: aload_1
    //   361: new android/support/design/widget/BottomSheetBehavior$SettleRunnable
    //   364: dup
    //   365: aload_0
    //   366: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   369: aload_1
    //   370: iload #4
    //   372: invokespecial <init> : (Landroid/support/design/widget/BottomSheetBehavior;Landroid/view/View;I)V
    //   375: invokestatic postOnAnimation : (Landroid/view/View;Ljava/lang/Runnable;)V
    //   378: goto -> 390
    //   381: aload_0
    //   382: getfield this$0 : Landroid/support/design/widget/BottomSheetBehavior;
    //   385: iload #4
    //   387: invokevirtual setStateInternal : (I)V
    //   390: return
  }
  
  public boolean tryCaptureView(View paramView, int paramInt) {
    int i = BottomSheetBehavior.this.state;
    boolean bool = true;
    if (i == 1)
      return false; 
    if (BottomSheetBehavior.this.touchingScrollingChild)
      return false; 
    if (BottomSheetBehavior.this.state == 3 && BottomSheetBehavior.this.activePointerId == paramInt) {
      View view = BottomSheetBehavior.this.nestedScrollingChildRef.get();
      if (view != null && view.canScrollVertically(-1))
        return false; 
    } 
    if (BottomSheetBehavior.this.viewRef == null || BottomSheetBehavior.this.viewRef.get() != paramView)
      bool = false; 
    return bool;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetBehavior$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */