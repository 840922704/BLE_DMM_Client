package android.support.design.widget;

import android.animation.ValueAnimator;

class null implements ValueAnimator.AnimatorUpdateListener {
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    CollapsingToolbarLayout.this.setScrimAlpha(((Integer)paramValueAnimator.getAnimatedValue()).intValue());
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\CollapsingToolbarLayout$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */