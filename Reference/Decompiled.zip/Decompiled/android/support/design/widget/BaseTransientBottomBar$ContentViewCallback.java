package android.support.design.widget;

import android.support.design.snackbar.ContentViewCallback;

@Deprecated
public interface ContentViewCallback extends ContentViewCallback {}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$ContentViewCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */