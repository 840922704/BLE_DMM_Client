package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<BottomNavigationView.SavedState> {
  public BottomNavigationView.SavedState createFromParcel(Parcel paramParcel) {
    return new BottomNavigationView.SavedState(paramParcel, null);
  }
  
  public BottomNavigationView.SavedState createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new BottomNavigationView.SavedState(paramParcel, paramClassLoader);
  }
  
  public BottomNavigationView.SavedState[] newArray(int paramInt) {
    return new BottomNavigationView.SavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomNavigationView$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */