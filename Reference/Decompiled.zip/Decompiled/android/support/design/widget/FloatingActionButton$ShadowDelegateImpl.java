package android.support.design.widget;

import android.graphics.drawable.Drawable;

class ShadowDelegateImpl implements ShadowViewDelegate {
  public float getRadius() {
    return FloatingActionButton.this.getSizeDimension() / 2.0F;
  }
  
  public boolean isCompatPaddingEnabled() {
    return FloatingActionButton.this.compatPadding;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    FloatingActionButton.access$101(FloatingActionButton.this, paramDrawable);
  }
  
  public void setShadowPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    FloatingActionButton.this.shadowPadding.set(paramInt1, paramInt2, paramInt3, paramInt4);
    FloatingActionButton floatingActionButton = FloatingActionButton.this;
    floatingActionButton.setPadding(paramInt1 + FloatingActionButton.access$000(floatingActionButton), paramInt2 + FloatingActionButton.access$000(FloatingActionButton.this), paramInt3 + FloatingActionButton.access$000(FloatingActionButton.this), paramInt4 + FloatingActionButton.access$000(FloatingActionButton.this));
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\FloatingActionButton$ShadowDelegateImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */