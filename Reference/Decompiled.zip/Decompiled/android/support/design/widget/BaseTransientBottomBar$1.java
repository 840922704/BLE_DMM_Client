package android.support.design.widget;

import android.os.Handler;
import android.os.Message;

final class null implements Handler.Callback {
  public boolean handleMessage(Message paramMessage) {
    int i = paramMessage.what;
    if (i != 0) {
      if (i != 1)
        return false; 
      ((BaseTransientBottomBar)paramMessage.obj).hideView(paramMessage.arg1);
      return true;
    } 
    ((BaseTransientBottomBar)paramMessage.obj).showView();
    return true;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */