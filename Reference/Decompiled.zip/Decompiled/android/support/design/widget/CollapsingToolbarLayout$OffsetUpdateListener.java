package android.support.design.widget;

import android.support.v4.math.MathUtils;
import android.support.v4.view.ViewCompat;
import android.view.View;

class OffsetUpdateListener implements AppBarLayout.OnOffsetChangedListener {
  public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt) {
    byte b;
    CollapsingToolbarLayout collapsingToolbarLayout = CollapsingToolbarLayout.this;
    collapsingToolbarLayout.currentOffset = paramInt;
    if (collapsingToolbarLayout.lastInsets != null) {
      b = CollapsingToolbarLayout.this.lastInsets.getSystemWindowInsetTop();
    } else {
      b = 0;
    } 
    int i = CollapsingToolbarLayout.this.getChildCount();
    int j;
    for (j = 0; j < i; j++) {
      View view = CollapsingToolbarLayout.this.getChildAt(j);
      CollapsingToolbarLayout.LayoutParams layoutParams = (CollapsingToolbarLayout.LayoutParams)view.getLayoutParams();
      ViewOffsetHelper viewOffsetHelper = CollapsingToolbarLayout.getViewOffsetHelper(view);
      int k = layoutParams.collapseMode;
      if (k != 1) {
        if (k == 2)
          viewOffsetHelper.setTopAndBottomOffset(Math.round(-paramInt * layoutParams.parallaxMult)); 
      } else {
        viewOffsetHelper.setTopAndBottomOffset(MathUtils.clamp(-paramInt, 0, CollapsingToolbarLayout.this.getMaxOffsetForPinChild(view)));
      } 
    } 
    CollapsingToolbarLayout.this.updateScrimVisibility();
    if (CollapsingToolbarLayout.this.statusBarScrim != null && b)
      ViewCompat.postInvalidateOnAnimation((View)CollapsingToolbarLayout.this); 
    j = CollapsingToolbarLayout.this.getHeight();
    i = ViewCompat.getMinimumHeight((View)CollapsingToolbarLayout.this);
    CollapsingToolbarLayout.this.collapsingTextHelper.setExpansionFraction(Math.abs(paramInt) / (j - i - b));
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\CollapsingToolbarLayout$OffsetUpdateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */