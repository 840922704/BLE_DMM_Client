package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<BottomSheetBehavior.SavedState> {
  public BottomSheetBehavior.SavedState createFromParcel(Parcel paramParcel) {
    return new BottomSheetBehavior.SavedState(paramParcel, null);
  }
  
  public BottomSheetBehavior.SavedState createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new BottomSheetBehavior.SavedState(paramParcel, paramClassLoader);
  }
  
  public BottomSheetBehavior.SavedState[] newArray(int paramInt) {
    return new BottomSheetBehavior.SavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetBehavior$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */