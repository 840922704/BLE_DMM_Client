package android.support.design.widget;

import android.view.View;

public interface OnLayoutChangeListener {
  void onLayoutChange(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BaseTransientBottomBar$OnLayoutChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */