package android.support.design.widget;

import android.view.View;

class null extends BottomSheetBehavior.BottomSheetCallback {
  public void onSlide(View paramView, float paramFloat) {}
  
  public void onStateChanged(View paramView, int paramInt) {
    if (paramInt == 5)
      BottomSheetDialog.this.cancel(); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\widget\BottomSheetDialog$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */