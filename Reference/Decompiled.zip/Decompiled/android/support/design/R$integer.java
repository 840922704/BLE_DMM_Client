package android.support.design;

public final class integer {
  public static final int abc_config_activityDefaultDur = 2131296256;
  
  public static final int abc_config_activityShortDur = 2131296257;
  
  public static final int app_bar_elevation_anim_duration = 2131296258;
  
  public static final int bottom_sheet_slide_duration = 2131296259;
  
  public static final int cancel_button_image_alpha = 2131296260;
  
  public static final int config_tooltipAnimTime = 2131296261;
  
  public static final int design_snackbar_text_max_lines = 2131296262;
  
  public static final int design_tab_indicator_anim_duration_ms = 2131296263;
  
  public static final int hide_password_duration = 2131296265;
  
  public static final int mtrl_btn_anim_delay_ms = 2131296266;
  
  public static final int mtrl_btn_anim_duration_ms = 2131296267;
  
  public static final int mtrl_chip_anim_duration = 2131296268;
  
  public static final int mtrl_tab_indicator_anim_duration_ms = 2131296269;
  
  public static final int show_password_duration = 2131296270;
  
  public static final int status_bar_notification_info_maxnum = 2131296271;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$integer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */