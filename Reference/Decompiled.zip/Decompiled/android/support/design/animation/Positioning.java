package android.support.design.animation;

public class Positioning {
  public final int gravity;
  
  public final float xAdjustment;
  
  public final float yAdjustment;
  
  public Positioning(int paramInt, float paramFloat1, float paramFloat2) {
    this.gravity = paramInt;
    this.xAdjustment = paramFloat1;
    this.yAdjustment = paramFloat2;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\animation\Positioning.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */