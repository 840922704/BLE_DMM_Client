package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;

class SavedState implements Parcelable {
  public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
      public BottomNavigationPresenter.SavedState createFromParcel(Parcel param2Parcel) {
        return new BottomNavigationPresenter.SavedState(param2Parcel);
      }
      
      public BottomNavigationPresenter.SavedState[] newArray(int param2Int) {
        return new BottomNavigationPresenter.SavedState[param2Int];
      }
    };
  
  int selectedItemId;
  
  SavedState() {}
  
  SavedState(Parcel paramParcel) {
    this.selectedItemId = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.selectedItemId);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\BottomNavigationPresenter$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */