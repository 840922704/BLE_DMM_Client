package android.support.design.internal;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

class NavigationMenuAdapter extends RecyclerView.Adapter<NavigationMenuPresenter.ViewHolder> {
  private static final String STATE_ACTION_VIEWS = "android:menu:action_views";
  
  private static final String STATE_CHECKED_ITEM = "android:menu:checked";
  
  private static final int VIEW_TYPE_HEADER = 3;
  
  private static final int VIEW_TYPE_NORMAL = 0;
  
  private static final int VIEW_TYPE_SEPARATOR = 2;
  
  private static final int VIEW_TYPE_SUBHEADER = 1;
  
  private MenuItemImpl checkedItem;
  
  private final ArrayList<NavigationMenuPresenter.NavigationMenuItem> items = new ArrayList<NavigationMenuPresenter.NavigationMenuItem>();
  
  private boolean updateSuspended;
  
  NavigationMenuAdapter() {
    prepareMenuItems();
  }
  
  private void appendTransparentIconIfMissing(int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      ((NavigationMenuPresenter.NavigationMenuTextItem)this.items.get(paramInt1)).needsEmptyIcon = true;
      paramInt1++;
    } 
  }
  
  private void prepareMenuItems() {
    if (this.updateSuspended)
      return; 
    this.updateSuspended = true;
    this.items.clear();
    this.items.add(new NavigationMenuPresenter.NavigationMenuHeaderItem());
    int i = NavigationMenuPresenter.this.menu.getVisibleItems().size();
    byte b = 0;
    int j = -1;
    boolean bool = false;
    int k;
    for (k = 0; b < i; k = n) {
      int m;
      boolean bool1;
      int n;
      MenuItemImpl menuItemImpl = NavigationMenuPresenter.this.menu.getVisibleItems().get(b);
      if (menuItemImpl.isChecked())
        setCheckedItem(menuItemImpl); 
      if (menuItemImpl.isCheckable())
        menuItemImpl.setExclusiveCheckable(false); 
      if (menuItemImpl.hasSubMenu()) {
        SubMenu subMenu = menuItemImpl.getSubMenu();
        m = j;
        bool1 = bool;
        n = k;
        if (subMenu.hasVisibleItems()) {
          if (b != 0)
            this.items.add(new NavigationMenuPresenter.NavigationMenuSeparatorItem(NavigationMenuPresenter.this.paddingSeparator, 0)); 
          this.items.add(new NavigationMenuPresenter.NavigationMenuTextItem(menuItemImpl));
          int i1 = this.items.size();
          int i2 = subMenu.size();
          m = 0;
          int i3;
          for (i3 = 0; m < i2; i3 = n) {
            MenuItemImpl menuItemImpl1 = (MenuItemImpl)subMenu.getItem(m);
            n = i3;
            if (menuItemImpl1.isVisible()) {
              n = i3;
              if (!i3) {
                n = i3;
                if (menuItemImpl1.getIcon() != null)
                  n = 1; 
              } 
              if (menuItemImpl1.isCheckable())
                menuItemImpl1.setExclusiveCheckable(false); 
              if (menuItemImpl.isChecked())
                setCheckedItem(menuItemImpl); 
              this.items.add(new NavigationMenuPresenter.NavigationMenuTextItem(menuItemImpl1));
            } 
            m++;
          } 
          m = j;
          bool1 = bool;
          n = k;
          if (i3) {
            appendTransparentIconIfMissing(i1, this.items.size());
            m = j;
            bool1 = bool;
            n = k;
          } 
        } 
      } else {
        int i1;
        m = menuItemImpl.getGroupId();
        if (m != j) {
          k = this.items.size();
          if (menuItemImpl.getIcon() != null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          i1 = k;
          if (b != 0) {
            i1 = k + 1;
            this.items.add(new NavigationMenuPresenter.NavigationMenuSeparatorItem(NavigationMenuPresenter.this.paddingSeparator, NavigationMenuPresenter.this.paddingSeparator));
          } 
        } else {
          bool1 = bool;
          i1 = k;
          if (!bool) {
            bool1 = bool;
            i1 = k;
            if (menuItemImpl.getIcon() != null) {
              appendTransparentIconIfMissing(k, this.items.size());
              bool1 = true;
              i1 = k;
            } 
          } 
        } 
        NavigationMenuPresenter.NavigationMenuTextItem navigationMenuTextItem = new NavigationMenuPresenter.NavigationMenuTextItem(menuItemImpl);
        navigationMenuTextItem.needsEmptyIcon = bool1;
        this.items.add(navigationMenuTextItem);
        n = i1;
      } 
      b++;
      j = m;
      bool = bool1;
    } 
    this.updateSuspended = false;
  }
  
  public Bundle createInstanceState() {
    Bundle bundle = new Bundle();
    MenuItemImpl menuItemImpl = this.checkedItem;
    if (menuItemImpl != null)
      bundle.putInt("android:menu:checked", menuItemImpl.getItemId()); 
    SparseArray sparseArray = new SparseArray();
    byte b = 0;
    int i = this.items.size();
    while (b < i) {
      NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = this.items.get(b);
      if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
        MenuItemImpl menuItemImpl1 = ((NavigationMenuPresenter.NavigationMenuTextItem)navigationMenuItem).getMenuItem();
        if (menuItemImpl1 != null) {
          View view = menuItemImpl1.getActionView();
        } else {
          navigationMenuItem = null;
        } 
        if (navigationMenuItem != null) {
          ParcelableSparseArray parcelableSparseArray = new ParcelableSparseArray();
          navigationMenuItem.saveHierarchyState(parcelableSparseArray);
          sparseArray.put(menuItemImpl1.getItemId(), parcelableSparseArray);
        } 
      } 
      b++;
    } 
    bundle.putSparseParcelableArray("android:menu:action_views", sparseArray);
    return bundle;
  }
  
  public MenuItemImpl getCheckedItem() {
    return this.checkedItem;
  }
  
  public int getItemCount() {
    return this.items.size();
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public int getItemViewType(int paramInt) {
    NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = this.items.get(paramInt);
    if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuSeparatorItem)
      return 2; 
    if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuHeaderItem)
      return 3; 
    if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem)
      return ((NavigationMenuPresenter.NavigationMenuTextItem)navigationMenuItem).getMenuItem().hasSubMenu() ? 1 : 0; 
    throw new RuntimeException("Unknown item type.");
  }
  
  public void onBindViewHolder(NavigationMenuPresenter.ViewHolder paramViewHolder, int paramInt) {
    int i = getItemViewType(paramInt);
    if (i != 0) {
      if (i != 1) {
        if (i == 2) {
          NavigationMenuPresenter.NavigationMenuSeparatorItem navigationMenuSeparatorItem = (NavigationMenuPresenter.NavigationMenuSeparatorItem)this.items.get(paramInt);
          paramViewHolder.itemView.setPadding(0, navigationMenuSeparatorItem.getPaddingTop(), 0, navigationMenuSeparatorItem.getPaddingBottom());
        } 
      } else {
        ((TextView)paramViewHolder.itemView).setText(((NavigationMenuPresenter.NavigationMenuTextItem)this.items.get(paramInt)).getMenuItem().getTitle());
      } 
    } else {
      NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView)paramViewHolder.itemView;
      navigationMenuItemView.setIconTintList(NavigationMenuPresenter.this.iconTintList);
      if (NavigationMenuPresenter.this.textAppearanceSet)
        navigationMenuItemView.setTextAppearance(NavigationMenuPresenter.this.textAppearance); 
      if (NavigationMenuPresenter.this.textColor != null)
        navigationMenuItemView.setTextColor(NavigationMenuPresenter.this.textColor); 
      if (NavigationMenuPresenter.this.itemBackground != null) {
        Drawable drawable = NavigationMenuPresenter.this.itemBackground.getConstantState().newDrawable();
      } else {
        paramViewHolder = null;
      } 
      ViewCompat.setBackground((View)navigationMenuItemView, (Drawable)paramViewHolder);
      NavigationMenuPresenter.NavigationMenuTextItem navigationMenuTextItem = (NavigationMenuPresenter.NavigationMenuTextItem)this.items.get(paramInt);
      navigationMenuItemView.setNeedsEmptyIcon(navigationMenuTextItem.needsEmptyIcon);
      navigationMenuItemView.setHorizontalPadding(NavigationMenuPresenter.this.itemHorizontalPadding);
      navigationMenuItemView.setIconPadding(NavigationMenuPresenter.this.itemIconPadding);
      navigationMenuItemView.initialize(navigationMenuTextItem.getMenuItem(), 0);
    } 
  }
  
  public NavigationMenuPresenter.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) {
    return (NavigationMenuPresenter.ViewHolder)((paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? null : new NavigationMenuPresenter.HeaderViewHolder((View)NavigationMenuPresenter.this.headerLayout)) : new NavigationMenuPresenter.SeparatorViewHolder(NavigationMenuPresenter.this.layoutInflater, paramViewGroup)) : new NavigationMenuPresenter.SubheaderViewHolder(NavigationMenuPresenter.this.layoutInflater, paramViewGroup)) : new NavigationMenuPresenter.NormalViewHolder(NavigationMenuPresenter.this.layoutInflater, paramViewGroup, NavigationMenuPresenter.this.onClickListener));
  }
  
  public void onViewRecycled(NavigationMenuPresenter.ViewHolder paramViewHolder) {
    if (paramViewHolder instanceof NavigationMenuPresenter.NormalViewHolder)
      ((NavigationMenuItemView)paramViewHolder.itemView).recycle(); 
  }
  
  public void restoreInstanceState(Bundle paramBundle) {
    byte b = 0;
    int i = paramBundle.getInt("android:menu:checked", 0);
    if (i != 0) {
      this.updateSuspended = true;
      int j = this.items.size();
      for (byte b1 = 0; b1 < j; b1++) {
        NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = this.items.get(b1);
        if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
          MenuItemImpl menuItemImpl = ((NavigationMenuPresenter.NavigationMenuTextItem)navigationMenuItem).getMenuItem();
          if (menuItemImpl != null && menuItemImpl.getItemId() == i) {
            setCheckedItem(menuItemImpl);
            break;
          } 
        } 
      } 
      this.updateSuspended = false;
      prepareMenuItems();
    } 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:action_views");
    if (sparseArray != null) {
      i = this.items.size();
      for (byte b1 = b; b1 < i; b1++) {
        NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = this.items.get(b1);
        if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
          MenuItemImpl menuItemImpl = ((NavigationMenuPresenter.NavigationMenuTextItem)navigationMenuItem).getMenuItem();
          if (menuItemImpl != null) {
            View view = menuItemImpl.getActionView();
            if (view != null) {
              ParcelableSparseArray parcelableSparseArray = (ParcelableSparseArray)sparseArray.get(menuItemImpl.getItemId());
              if (parcelableSparseArray != null)
                view.restoreHierarchyState(parcelableSparseArray); 
            } 
          } 
        } 
      } 
    } 
  }
  
  public void setCheckedItem(MenuItemImpl paramMenuItemImpl) {
    if (this.checkedItem != paramMenuItemImpl && paramMenuItemImpl.isCheckable()) {
      MenuItemImpl menuItemImpl = this.checkedItem;
      if (menuItemImpl != null)
        menuItemImpl.setChecked(false); 
      this.checkedItem = paramMenuItemImpl;
      paramMenuItemImpl.setChecked(true);
    } 
  }
  
  public void setUpdateSuspended(boolean paramBoolean) {
    this.updateSuspended = paramBoolean;
  }
  
  public void update() {
    prepareMenuItems();
    notifyDataSetChanged();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$NavigationMenuAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */