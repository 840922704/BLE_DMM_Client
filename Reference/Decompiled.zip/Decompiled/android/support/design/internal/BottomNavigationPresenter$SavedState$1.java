package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.Creator<BottomNavigationPresenter.SavedState> {
  public BottomNavigationPresenter.SavedState createFromParcel(Parcel paramParcel) {
    return new BottomNavigationPresenter.SavedState(paramParcel);
  }
  
  public BottomNavigationPresenter.SavedState[] newArray(int paramInt) {
    return new BottomNavigationPresenter.SavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\BottomNavigationPresenter$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */