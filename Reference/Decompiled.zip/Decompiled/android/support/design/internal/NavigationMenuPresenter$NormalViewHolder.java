package android.support.design.internal;

import android.support.design.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

class NormalViewHolder extends NavigationMenuPresenter.ViewHolder {
  public NormalViewHolder(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, View.OnClickListener paramOnClickListener) {
    super(paramLayoutInflater.inflate(R.layout.design_navigation_item, paramViewGroup, false));
    this.itemView.setOnClickListener(paramOnClickListener);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$NormalViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */