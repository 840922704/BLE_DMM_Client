package android.support.design.internal;

import android.support.v7.view.menu.MenuItemImpl;
import android.view.MenuItem;
import android.view.View;

class null implements View.OnClickListener {
  public void onClick(View paramView) {
    NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView)paramView;
    NavigationMenuPresenter.this.setUpdateSuspended(true);
    MenuItemImpl menuItemImpl = navigationMenuItemView.getItemData();
    boolean bool = NavigationMenuPresenter.this.menu.performItemAction((MenuItem)menuItemImpl, NavigationMenuPresenter.this, 0);
    if (menuItemImpl != null && menuItemImpl.isCheckable() && bool)
      NavigationMenuPresenter.this.adapter.setCheckedItem(menuItemImpl); 
    NavigationMenuPresenter.this.setUpdateSuspended(false);
    NavigationMenuPresenter.this.updateMenuView(false);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */