package android.support.design.internal;

import android.support.v7.view.menu.MenuItemImpl;

class NavigationMenuTextItem implements NavigationMenuPresenter.NavigationMenuItem {
  private final MenuItemImpl menuItem;
  
  boolean needsEmptyIcon;
  
  NavigationMenuTextItem(MenuItemImpl paramMenuItemImpl) {
    this.menuItem = paramMenuItemImpl;
  }
  
  public MenuItemImpl getMenuItem() {
    return this.menuItem;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$NavigationMenuTextItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */