package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<ParcelableSparseArray> {
  public ParcelableSparseArray createFromParcel(Parcel paramParcel) {
    return new ParcelableSparseArray(paramParcel, null);
  }
  
  public ParcelableSparseArray createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new ParcelableSparseArray(paramParcel, paramClassLoader);
  }
  
  public ParcelableSparseArray[] newArray(int paramInt) {
    return new ParcelableSparseArray[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\ParcelableSparseArray$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */