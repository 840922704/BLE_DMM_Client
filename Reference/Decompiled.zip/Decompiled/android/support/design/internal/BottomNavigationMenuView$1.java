package android.support.design.internal;

import android.support.v7.view.menu.MenuItemImpl;
import android.view.MenuItem;
import android.view.View;

class null implements View.OnClickListener {
  public void onClick(View paramView) {
    MenuItemImpl menuItemImpl = ((BottomNavigationItemView)paramView).getItemData();
    if (!BottomNavigationMenuView.access$100(BottomNavigationMenuView.this).performItemAction((MenuItem)menuItemImpl, BottomNavigationMenuView.access$000(BottomNavigationMenuView.this), 0))
      menuItemImpl.setChecked(true); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\BottomNavigationMenuView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */