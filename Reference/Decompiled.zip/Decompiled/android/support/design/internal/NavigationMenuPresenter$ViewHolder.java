package android.support.design.internal;

import android.support.v7.widget.RecyclerView;
import android.view.View;

abstract class ViewHolder extends RecyclerView.ViewHolder {
  public ViewHolder(View paramView) {
    super(paramView);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$ViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */