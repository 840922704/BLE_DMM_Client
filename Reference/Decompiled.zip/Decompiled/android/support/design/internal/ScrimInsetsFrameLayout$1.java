package android.support.design.internal;

import android.graphics.Rect;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.view.View;

class null implements OnApplyWindowInsetsListener {
  public WindowInsetsCompat onApplyWindowInsets(View paramView, WindowInsetsCompat paramWindowInsetsCompat) {
    if (ScrimInsetsFrameLayout.this.insets == null)
      ScrimInsetsFrameLayout.this.insets = new Rect(); 
    ScrimInsetsFrameLayout.this.insets.set(paramWindowInsetsCompat.getSystemWindowInsetLeft(), paramWindowInsetsCompat.getSystemWindowInsetTop(), paramWindowInsetsCompat.getSystemWindowInsetRight(), paramWindowInsetsCompat.getSystemWindowInsetBottom());
    ScrimInsetsFrameLayout.this.onInsetsChanged(paramWindowInsetsCompat);
    ScrimInsetsFrameLayout scrimInsetsFrameLayout = ScrimInsetsFrameLayout.this;
    if (!paramWindowInsetsCompat.hasSystemWindowInsets() || ScrimInsetsFrameLayout.this.insetForeground == null) {
      boolean bool1 = true;
      scrimInsetsFrameLayout.setWillNotDraw(bool1);
      ViewCompat.postInvalidateOnAnimation((View)ScrimInsetsFrameLayout.this);
      return paramWindowInsetsCompat.consumeSystemWindowInsets();
    } 
    boolean bool = false;
    scrimInsetsFrameLayout.setWillNotDraw(bool);
    ViewCompat.postInvalidateOnAnimation((View)ScrimInsetsFrameLayout.this);
    return paramWindowInsetsCompat.consumeSystemWindowInsets();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\ScrimInsetsFrameLayout$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */