package android.support.design.internal;

class NavigationMenuSeparatorItem implements NavigationMenuPresenter.NavigationMenuItem {
  private final int paddingBottom;
  
  private final int paddingTop;
  
  public NavigationMenuSeparatorItem(int paramInt1, int paramInt2) {
    this.paddingTop = paramInt1;
    this.paddingBottom = paramInt2;
  }
  
  public int getPaddingBottom() {
    return this.paddingBottom;
  }
  
  public int getPaddingTop() {
    return this.paddingTop;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$NavigationMenuSeparatorItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */