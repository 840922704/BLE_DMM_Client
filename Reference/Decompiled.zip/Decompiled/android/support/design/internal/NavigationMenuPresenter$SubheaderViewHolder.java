package android.support.design.internal;

import android.support.design.R;
import android.view.LayoutInflater;
import android.view.ViewGroup;

class SubheaderViewHolder extends NavigationMenuPresenter.ViewHolder {
  public SubheaderViewHolder(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup) {
    super(paramLayoutInflater.inflate(R.layout.design_navigation_item_subheader, paramViewGroup, false));
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\internal\NavigationMenuPresenter$SubheaderViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */