package android.support.design;

public final class animator {
  public static final int design_appbar_state_list_animator = 2130837504;
  
  public static final int design_fab_hide_motion_spec = 2130837505;
  
  public static final int design_fab_show_motion_spec = 2130837506;
  
  public static final int mtrl_btn_state_list_anim = 2130837507;
  
  public static final int mtrl_btn_unelevated_state_list_anim = 2130837508;
  
  public static final int mtrl_chip_state_list_anim = 2130837509;
  
  public static final int mtrl_fab_hide_motion_spec = 2130837510;
  
  public static final int mtrl_fab_show_motion_spec = 2130837511;
  
  public static final int mtrl_fab_transformation_sheet_collapse_spec = 2130837512;
  
  public static final int mtrl_fab_transformation_sheet_expand_spec = 2130837513;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$animator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */