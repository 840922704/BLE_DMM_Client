package android.support.design;

public final class dimen {
  public static final int abc_action_bar_content_inset_material = 2131100981;
  
  public static final int abc_action_bar_content_inset_with_nav = 2131100982;
  
  public static final int abc_action_bar_default_height_material = 2131100983;
  
  public static final int abc_action_bar_default_padding_end_material = 2131100984;
  
  public static final int abc_action_bar_default_padding_start_material = 2131100985;
  
  public static final int abc_action_bar_elevation_material = 2131100986;
  
  public static final int abc_action_bar_icon_vertical_padding_material = 2131100987;
  
  public static final int abc_action_bar_overflow_padding_end_material = 2131100988;
  
  public static final int abc_action_bar_overflow_padding_start_material = 2131100989;
  
  public static final int abc_action_bar_stacked_max_height = 2131100990;
  
  public static final int abc_action_bar_stacked_tab_max_width = 2131100991;
  
  public static final int abc_action_bar_subtitle_bottom_margin_material = 2131100992;
  
  public static final int abc_action_bar_subtitle_top_margin_material = 2131100993;
  
  public static final int abc_action_button_min_height_material = 2131100994;
  
  public static final int abc_action_button_min_width_material = 2131100995;
  
  public static final int abc_action_button_min_width_overflow_material = 2131100996;
  
  public static final int abc_alert_dialog_button_bar_height = 2131100997;
  
  public static final int abc_alert_dialog_button_dimen = 2131100998;
  
  public static final int abc_button_inset_horizontal_material = 2131100999;
  
  public static final int abc_button_inset_vertical_material = 2131101000;
  
  public static final int abc_button_padding_horizontal_material = 2131101001;
  
  public static final int abc_button_padding_vertical_material = 2131101002;
  
  public static final int abc_cascading_menus_min_smallest_width = 2131101003;
  
  public static final int abc_config_prefDialogWidth = 2131101004;
  
  public static final int abc_control_corner_material = 2131101005;
  
  public static final int abc_control_inset_material = 2131101006;
  
  public static final int abc_control_padding_material = 2131101007;
  
  public static final int abc_dialog_corner_radius_material = 2131101008;
  
  public static final int abc_dialog_fixed_height_major = 2131101009;
  
  public static final int abc_dialog_fixed_height_minor = 2131101010;
  
  public static final int abc_dialog_fixed_width_major = 2131101011;
  
  public static final int abc_dialog_fixed_width_minor = 2131101012;
  
  public static final int abc_dialog_list_padding_bottom_no_buttons = 2131101013;
  
  public static final int abc_dialog_list_padding_top_no_title = 2131101014;
  
  public static final int abc_dialog_min_width_major = 2131101015;
  
  public static final int abc_dialog_min_width_minor = 2131101016;
  
  public static final int abc_dialog_padding_material = 2131101017;
  
  public static final int abc_dialog_padding_top_material = 2131101018;
  
  public static final int abc_dialog_title_divider_material = 2131101019;
  
  public static final int abc_disabled_alpha_material_dark = 2131101020;
  
  public static final int abc_disabled_alpha_material_light = 2131101021;
  
  public static final int abc_dropdownitem_icon_width = 2131101022;
  
  public static final int abc_dropdownitem_text_padding_left = 2131101023;
  
  public static final int abc_dropdownitem_text_padding_right = 2131101024;
  
  public static final int abc_edit_text_inset_bottom_material = 2131101025;
  
  public static final int abc_edit_text_inset_horizontal_material = 2131101026;
  
  public static final int abc_edit_text_inset_top_material = 2131101027;
  
  public static final int abc_floating_window_z = 2131101028;
  
  public static final int abc_list_item_padding_horizontal_material = 2131101029;
  
  public static final int abc_panel_menu_list_width = 2131101030;
  
  public static final int abc_progress_bar_height_material = 2131101031;
  
  public static final int abc_search_view_preferred_height = 2131101032;
  
  public static final int abc_search_view_preferred_width = 2131101033;
  
  public static final int abc_seekbar_track_background_height_material = 2131101034;
  
  public static final int abc_seekbar_track_progress_height_material = 2131101035;
  
  public static final int abc_select_dialog_padding_start_material = 2131101036;
  
  public static final int abc_switch_padding = 2131101037;
  
  public static final int abc_text_size_body_1_material = 2131101038;
  
  public static final int abc_text_size_body_2_material = 2131101039;
  
  public static final int abc_text_size_button_material = 2131101040;
  
  public static final int abc_text_size_caption_material = 2131101041;
  
  public static final int abc_text_size_display_1_material = 2131101042;
  
  public static final int abc_text_size_display_2_material = 2131101043;
  
  public static final int abc_text_size_display_3_material = 2131101044;
  
  public static final int abc_text_size_display_4_material = 2131101045;
  
  public static final int abc_text_size_headline_material = 2131101046;
  
  public static final int abc_text_size_large_material = 2131101047;
  
  public static final int abc_text_size_medium_material = 2131101048;
  
  public static final int abc_text_size_menu_header_material = 2131101049;
  
  public static final int abc_text_size_menu_material = 2131101050;
  
  public static final int abc_text_size_small_material = 2131101051;
  
  public static final int abc_text_size_subhead_material = 2131101052;
  
  public static final int abc_text_size_subtitle_material_toolbar = 2131101053;
  
  public static final int abc_text_size_title_material = 2131101054;
  
  public static final int abc_text_size_title_material_toolbar = 2131101055;
  
  public static final int cardview_compat_inset_shadow = 2131101056;
  
  public static final int cardview_default_elevation = 2131101057;
  
  public static final int cardview_default_radius = 2131101058;
  
  public static final int compat_button_inset_horizontal_material = 2131101059;
  
  public static final int compat_button_inset_vertical_material = 2131101060;
  
  public static final int compat_button_padding_horizontal_material = 2131101061;
  
  public static final int compat_button_padding_vertical_material = 2131101062;
  
  public static final int compat_control_corner_material = 2131101063;
  
  public static final int compat_notification_large_icon_max_height = 2131101064;
  
  public static final int compat_notification_large_icon_max_width = 2131101065;
  
  public static final int design_appbar_elevation = 2131101067;
  
  public static final int design_bottom_navigation_active_item_max_width = 2131101068;
  
  public static final int design_bottom_navigation_active_item_min_width = 2131101069;
  
  public static final int design_bottom_navigation_active_text_size = 2131101070;
  
  public static final int design_bottom_navigation_elevation = 2131101071;
  
  public static final int design_bottom_navigation_height = 2131101072;
  
  public static final int design_bottom_navigation_icon_size = 2131101073;
  
  public static final int design_bottom_navigation_item_max_width = 2131101074;
  
  public static final int design_bottom_navigation_item_min_width = 2131101075;
  
  public static final int design_bottom_navigation_margin = 2131101076;
  
  public static final int design_bottom_navigation_shadow_height = 2131101077;
  
  public static final int design_bottom_navigation_text_size = 2131101078;
  
  public static final int design_bottom_sheet_modal_elevation = 2131101079;
  
  public static final int design_bottom_sheet_peek_height_min = 2131101080;
  
  public static final int design_fab_border_width = 2131101081;
  
  public static final int design_fab_elevation = 2131101082;
  
  public static final int design_fab_image_size = 2131101083;
  
  public static final int design_fab_size_mini = 2131101084;
  
  public static final int design_fab_size_normal = 2131101085;
  
  public static final int design_fab_translation_z_hovered_focused = 2131101086;
  
  public static final int design_fab_translation_z_pressed = 2131101087;
  
  public static final int design_navigation_elevation = 2131101088;
  
  public static final int design_navigation_icon_padding = 2131101089;
  
  public static final int design_navigation_icon_size = 2131101090;
  
  public static final int design_navigation_item_horizontal_padding = 2131101091;
  
  public static final int design_navigation_item_icon_padding = 2131101092;
  
  public static final int design_navigation_max_width = 2131101093;
  
  public static final int design_navigation_padding_bottom = 2131101094;
  
  public static final int design_navigation_separator_vertical_padding = 2131101095;
  
  public static final int design_snackbar_action_inline_max_width = 2131101096;
  
  public static final int design_snackbar_background_corner_radius = 2131101097;
  
  public static final int design_snackbar_elevation = 2131101098;
  
  public static final int design_snackbar_extra_spacing_horizontal = 2131101099;
  
  public static final int design_snackbar_max_width = 2131101100;
  
  public static final int design_snackbar_min_width = 2131101101;
  
  public static final int design_snackbar_padding_horizontal = 2131101102;
  
  public static final int design_snackbar_padding_vertical = 2131101103;
  
  public static final int design_snackbar_padding_vertical_2lines = 2131101104;
  
  public static final int design_snackbar_text_size = 2131101105;
  
  public static final int design_tab_max_width = 2131101106;
  
  public static final int design_tab_scrollable_min_width = 2131101107;
  
  public static final int design_tab_text_size = 2131101108;
  
  public static final int design_tab_text_size_2line = 2131101109;
  
  public static final int design_textinput_caption_translate_y = 2131101110;
  
  public static final int disabled_alpha_material_dark = 2131101111;
  
  public static final int disabled_alpha_material_light = 2131101112;
  
  public static final int fastscroll_default_thickness = 2131101116;
  
  public static final int fastscroll_margin = 2131101117;
  
  public static final int fastscroll_minimum_range = 2131101118;
  
  public static final int highlight_alpha_material_colored = 2131101119;
  
  public static final int highlight_alpha_material_dark = 2131101120;
  
  public static final int highlight_alpha_material_light = 2131101121;
  
  public static final int hint_alpha_material_dark = 2131101122;
  
  public static final int hint_alpha_material_light = 2131101123;
  
  public static final int hint_pressed_alpha_material_dark = 2131101124;
  
  public static final int hint_pressed_alpha_material_light = 2131101125;
  
  public static final int item_touch_helper_max_drag_scroll_per_frame = 2131101126;
  
  public static final int item_touch_helper_swipe_escape_max_velocity = 2131101127;
  
  public static final int item_touch_helper_swipe_escape_velocity = 2131101128;
  
  public static final int mtrl_bottomappbar_fabOffsetEndMode = 2131101129;
  
  public static final int mtrl_bottomappbar_fab_cradle_margin = 2131101130;
  
  public static final int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 2131101131;
  
  public static final int mtrl_bottomappbar_fab_cradle_vertical_offset = 2131101132;
  
  public static final int mtrl_bottomappbar_height = 2131101133;
  
  public static final int mtrl_btn_corner_radius = 2131101134;
  
  public static final int mtrl_btn_dialog_btn_min_width = 2131101135;
  
  public static final int mtrl_btn_disabled_elevation = 2131101136;
  
  public static final int mtrl_btn_disabled_z = 2131101137;
  
  public static final int mtrl_btn_elevation = 2131101138;
  
  public static final int mtrl_btn_focused_z = 2131101139;
  
  public static final int mtrl_btn_hovered_z = 2131101140;
  
  public static final int mtrl_btn_icon_btn_padding_left = 2131101141;
  
  public static final int mtrl_btn_icon_padding = 2131101142;
  
  public static final int mtrl_btn_inset = 2131101143;
  
  public static final int mtrl_btn_letter_spacing = 2131101144;
  
  public static final int mtrl_btn_padding_bottom = 2131101145;
  
  public static final int mtrl_btn_padding_left = 2131101146;
  
  public static final int mtrl_btn_padding_right = 2131101147;
  
  public static final int mtrl_btn_padding_top = 2131101148;
  
  public static final int mtrl_btn_pressed_z = 2131101149;
  
  public static final int mtrl_btn_stroke_size = 2131101150;
  
  public static final int mtrl_btn_text_btn_icon_padding = 2131101151;
  
  public static final int mtrl_btn_text_btn_padding_left = 2131101152;
  
  public static final int mtrl_btn_text_btn_padding_right = 2131101153;
  
  public static final int mtrl_btn_text_size = 2131101154;
  
  public static final int mtrl_btn_z = 2131101155;
  
  public static final int mtrl_card_elevation = 2131101156;
  
  public static final int mtrl_card_spacing = 2131101157;
  
  public static final int mtrl_chip_pressed_translation_z = 2131101158;
  
  public static final int mtrl_chip_text_size = 2131101159;
  
  public static final int mtrl_fab_elevation = 2131101160;
  
  public static final int mtrl_fab_translation_z_hovered_focused = 2131101161;
  
  public static final int mtrl_fab_translation_z_pressed = 2131101162;
  
  public static final int mtrl_navigation_elevation = 2131101163;
  
  public static final int mtrl_navigation_item_horizontal_padding = 2131101164;
  
  public static final int mtrl_navigation_item_icon_padding = 2131101165;
  
  public static final int mtrl_snackbar_background_corner_radius = 2131101166;
  
  public static final int mtrl_snackbar_margin = 2131101167;
  
  public static final int mtrl_textinput_box_bottom_offset = 2131101168;
  
  public static final int mtrl_textinput_box_corner_radius_medium = 2131101169;
  
  public static final int mtrl_textinput_box_corner_radius_small = 2131101170;
  
  public static final int mtrl_textinput_box_label_cutout_padding = 2131101171;
  
  public static final int mtrl_textinput_box_padding_end = 2131101172;
  
  public static final int mtrl_textinput_box_stroke_width_default = 2131101173;
  
  public static final int mtrl_textinput_box_stroke_width_focused = 2131101174;
  
  public static final int mtrl_textinput_outline_box_expanded_padding = 2131101175;
  
  public static final int mtrl_toolbar_default_height = 2131101176;
  
  public static final int notification_action_icon_size = 2131101177;
  
  public static final int notification_action_text_size = 2131101178;
  
  public static final int notification_big_circle_margin = 2131101179;
  
  public static final int notification_content_margin_start = 2131101180;
  
  public static final int notification_large_icon_height = 2131101181;
  
  public static final int notification_large_icon_width = 2131101182;
  
  public static final int notification_main_column_padding_top = 2131101183;
  
  public static final int notification_media_narrow_margin = 2131101184;
  
  public static final int notification_right_icon_size = 2131101185;
  
  public static final int notification_right_side_padding_top = 2131101186;
  
  public static final int notification_small_icon_background_padding = 2131101187;
  
  public static final int notification_small_icon_size_as_large = 2131101188;
  
  public static final int notification_subtext_size = 2131101189;
  
  public static final int notification_top_pad = 2131101190;
  
  public static final int notification_top_pad_large_text = 2131101191;
  
  public static final int tooltip_corner_radius = 2131101262;
  
  public static final int tooltip_horizontal_padding = 2131101263;
  
  public static final int tooltip_margin = 2131101264;
  
  public static final int tooltip_precise_anchor_extra_offset = 2131101265;
  
  public static final int tooltip_precise_anchor_threshold = 2131101266;
  
  public static final int tooltip_vertical_padding = 2131101267;
  
  public static final int tooltip_y_offset_non_touch = 2131101268;
  
  public static final int tooltip_y_offset_touch = 2131101269;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$dimen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */