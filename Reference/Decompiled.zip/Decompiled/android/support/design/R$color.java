package android.support.design;

public final class color {
  public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
  
  public static final int abc_background_cache_hint_selector_material_light = 2131034113;
  
  public static final int abc_btn_colored_borderless_text_material = 2131034114;
  
  public static final int abc_btn_colored_text_material = 2131034115;
  
  public static final int abc_color_highlight_material = 2131034116;
  
  public static final int abc_hint_foreground_material_dark = 2131034117;
  
  public static final int abc_hint_foreground_material_light = 2131034118;
  
  public static final int abc_input_method_navigation_guard = 2131034119;
  
  public static final int abc_primary_text_disable_only_material_dark = 2131034120;
  
  public static final int abc_primary_text_disable_only_material_light = 2131034121;
  
  public static final int abc_primary_text_material_dark = 2131034122;
  
  public static final int abc_primary_text_material_light = 2131034123;
  
  public static final int abc_search_url_text = 2131034124;
  
  public static final int abc_search_url_text_normal = 2131034125;
  
  public static final int abc_search_url_text_pressed = 2131034126;
  
  public static final int abc_search_url_text_selected = 2131034127;
  
  public static final int abc_secondary_text_material_dark = 2131034128;
  
  public static final int abc_secondary_text_material_light = 2131034129;
  
  public static final int abc_tint_btn_checkable = 2131034130;
  
  public static final int abc_tint_default = 2131034131;
  
  public static final int abc_tint_edittext = 2131034132;
  
  public static final int abc_tint_seek_thumb = 2131034133;
  
  public static final int abc_tint_spinner = 2131034134;
  
  public static final int abc_tint_switch_track = 2131034135;
  
  public static final int accent_material_dark = 2131034136;
  
  public static final int accent_material_light = 2131034137;
  
  public static final int background_floating_material_dark = 2131034138;
  
  public static final int background_floating_material_light = 2131034139;
  
  public static final int background_material_dark = 2131034140;
  
  public static final int background_material_light = 2131034141;
  
  public static final int bright_foreground_disabled_material_dark = 2131034146;
  
  public static final int bright_foreground_disabled_material_light = 2131034147;
  
  public static final int bright_foreground_inverse_material_dark = 2131034148;
  
  public static final int bright_foreground_inverse_material_light = 2131034149;
  
  public static final int bright_foreground_material_dark = 2131034150;
  
  public static final int bright_foreground_material_light = 2131034151;
  
  public static final int button_material_dark = 2131034154;
  
  public static final int button_material_light = 2131034155;
  
  public static final int cardview_dark_background = 2131034156;
  
  public static final int cardview_light_background = 2131034157;
  
  public static final int cardview_shadow_end_color = 2131034158;
  
  public static final int cardview_shadow_start_color = 2131034159;
  
  public static final int design_bottom_navigation_shadow_color = 2131034176;
  
  public static final int design_default_color_primary = 2131034177;
  
  public static final int design_default_color_primary_dark = 2131034178;
  
  public static final int design_error = 2131034179;
  
  public static final int design_fab_shadow_end_color = 2131034180;
  
  public static final int design_fab_shadow_mid_color = 2131034181;
  
  public static final int design_fab_shadow_start_color = 2131034182;
  
  public static final int design_fab_stroke_end_inner_color = 2131034183;
  
  public static final int design_fab_stroke_end_outer_color = 2131034184;
  
  public static final int design_fab_stroke_top_inner_color = 2131034185;
  
  public static final int design_fab_stroke_top_outer_color = 2131034186;
  
  public static final int design_snackbar_background_color = 2131034187;
  
  public static final int design_tint_password_toggle = 2131034188;
  
  public static final int dim_foreground_disabled_material_dark = 2131034192;
  
  public static final int dim_foreground_disabled_material_light = 2131034193;
  
  public static final int dim_foreground_material_dark = 2131034194;
  
  public static final int dim_foreground_material_light = 2131034195;
  
  public static final int error_color_material_dark = 2131034196;
  
  public static final int error_color_material_light = 2131034197;
  
  public static final int foreground_material_dark = 2131034198;
  
  public static final int foreground_material_light = 2131034199;
  
  public static final int highlighted_text_material_dark = 2131034202;
  
  public static final int highlighted_text_material_light = 2131034203;
  
  public static final int material_blue_grey_800 = 2131034204;
  
  public static final int material_blue_grey_900 = 2131034205;
  
  public static final int material_blue_grey_950 = 2131034206;
  
  public static final int material_deep_teal_200 = 2131034207;
  
  public static final int material_deep_teal_500 = 2131034208;
  
  public static final int material_grey_100 = 2131034209;
  
  public static final int material_grey_300 = 2131034210;
  
  public static final int material_grey_50 = 2131034211;
  
  public static final int material_grey_600 = 2131034212;
  
  public static final int material_grey_800 = 2131034213;
  
  public static final int material_grey_850 = 2131034214;
  
  public static final int material_grey_900 = 2131034215;
  
  public static final int mtrl_bottom_nav_colored_item_tint = 2131034216;
  
  public static final int mtrl_bottom_nav_item_tint = 2131034217;
  
  public static final int mtrl_btn_bg_color_disabled = 2131034218;
  
  public static final int mtrl_btn_bg_color_selector = 2131034219;
  
  public static final int mtrl_btn_ripple_color = 2131034220;
  
  public static final int mtrl_btn_stroke_color_selector = 2131034221;
  
  public static final int mtrl_btn_text_btn_ripple_color = 2131034222;
  
  public static final int mtrl_btn_text_color_disabled = 2131034223;
  
  public static final int mtrl_btn_text_color_selector = 2131034224;
  
  public static final int mtrl_btn_transparent_bg_color = 2131034225;
  
  public static final int mtrl_chip_background_color = 2131034226;
  
  public static final int mtrl_chip_close_icon_tint = 2131034227;
  
  public static final int mtrl_chip_ripple_color = 2131034228;
  
  public static final int mtrl_chip_text_color = 2131034229;
  
  public static final int mtrl_fab_ripple_color = 2131034230;
  
  public static final int mtrl_scrim_color = 2131034231;
  
  public static final int mtrl_tabs_colored_ripple_color = 2131034232;
  
  public static final int mtrl_tabs_icon_color_selector = 2131034233;
  
  public static final int mtrl_tabs_icon_color_selector_colored = 2131034234;
  
  public static final int mtrl_tabs_legacy_text_color_selector = 2131034235;
  
  public static final int mtrl_tabs_ripple_color = 2131034236;
  
  public static final int mtrl_text_btn_text_color_selector = 2131034237;
  
  public static final int mtrl_textinput_default_box_stroke_color = 2131034238;
  
  public static final int mtrl_textinput_disabled_color = 2131034239;
  
  public static final int mtrl_textinput_filled_box_default_background_color = 2131034240;
  
  public static final int mtrl_textinput_hovered_box_stroke_color = 2131034241;
  
  public static final int notification_action_color_filter = 2131034242;
  
  public static final int notification_icon_bg_color = 2131034243;
  
  public static final int primary_dark_material_dark = 2131034245;
  
  public static final int primary_dark_material_light = 2131034246;
  
  public static final int primary_material_dark = 2131034247;
  
  public static final int primary_material_light = 2131034248;
  
  public static final int primary_text_default_material_dark = 2131034249;
  
  public static final int primary_text_default_material_light = 2131034250;
  
  public static final int primary_text_disabled_material_dark = 2131034251;
  
  public static final int primary_text_disabled_material_light = 2131034252;
  
  public static final int ripple_material_dark = 2131034254;
  
  public static final int ripple_material_light = 2131034255;
  
  public static final int secondary_text_default_material_dark = 2131034256;
  
  public static final int secondary_text_default_material_light = 2131034257;
  
  public static final int secondary_text_disabled_material_dark = 2131034258;
  
  public static final int secondary_text_disabled_material_light = 2131034259;
  
  public static final int switch_thumb_disabled_material_dark = 2131034262;
  
  public static final int switch_thumb_disabled_material_light = 2131034263;
  
  public static final int switch_thumb_material_dark = 2131034264;
  
  public static final int switch_thumb_material_light = 2131034265;
  
  public static final int switch_thumb_normal_material_dark = 2131034266;
  
  public static final int switch_thumb_normal_material_light = 2131034267;
  
  public static final int tooltip_background_dark = 2131034269;
  
  public static final int tooltip_background_light = 2131034270;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$color.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */