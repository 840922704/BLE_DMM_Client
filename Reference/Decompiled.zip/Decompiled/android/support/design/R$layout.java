package android.support.design;

public final class layout {
  public static final int abc_action_bar_title_item = 2131427328;
  
  public static final int abc_action_bar_up_container = 2131427329;
  
  public static final int abc_action_menu_item_layout = 2131427330;
  
  public static final int abc_action_menu_layout = 2131427331;
  
  public static final int abc_action_mode_bar = 2131427332;
  
  public static final int abc_action_mode_close_item_material = 2131427333;
  
  public static final int abc_activity_chooser_view = 2131427334;
  
  public static final int abc_activity_chooser_view_list_item = 2131427335;
  
  public static final int abc_alert_dialog_button_bar_material = 2131427336;
  
  public static final int abc_alert_dialog_material = 2131427337;
  
  public static final int abc_alert_dialog_title_material = 2131427338;
  
  public static final int abc_cascading_menu_item_layout = 2131427339;
  
  public static final int abc_dialog_title_material = 2131427340;
  
  public static final int abc_expanded_menu_layout = 2131427341;
  
  public static final int abc_list_menu_item_checkbox = 2131427342;
  
  public static final int abc_list_menu_item_icon = 2131427343;
  
  public static final int abc_list_menu_item_layout = 2131427344;
  
  public static final int abc_list_menu_item_radio = 2131427345;
  
  public static final int abc_popup_menu_header_item_layout = 2131427346;
  
  public static final int abc_popup_menu_item_layout = 2131427347;
  
  public static final int abc_screen_content_include = 2131427348;
  
  public static final int abc_screen_simple = 2131427349;
  
  public static final int abc_screen_simple_overlay_action_mode = 2131427350;
  
  public static final int abc_screen_toolbar = 2131427351;
  
  public static final int abc_search_dropdown_item_icons_2line = 2131427352;
  
  public static final int abc_search_view = 2131427353;
  
  public static final int abc_select_dialog_material = 2131427354;
  
  public static final int abc_tooltip = 2131427355;
  
  public static final int design_bottom_navigation_item = 2131427384;
  
  public static final int design_bottom_sheet_dialog = 2131427385;
  
  public static final int design_layout_snackbar = 2131427386;
  
  public static final int design_layout_snackbar_include = 2131427387;
  
  public static final int design_layout_tab_icon = 2131427388;
  
  public static final int design_layout_tab_text = 2131427389;
  
  public static final int design_menu_item_action_area = 2131427390;
  
  public static final int design_navigation_item = 2131427391;
  
  public static final int design_navigation_item_header = 2131427392;
  
  public static final int design_navigation_item_separator = 2131427393;
  
  public static final int design_navigation_item_subheader = 2131427394;
  
  public static final int design_navigation_menu = 2131427395;
  
  public static final int design_navigation_menu_item = 2131427396;
  
  public static final int design_text_input_password_icon = 2131427397;
  
  public static final int mtrl_layout_snackbar = 2131427415;
  
  public static final int mtrl_layout_snackbar_include = 2131427416;
  
  public static final int notification_action = 2131427417;
  
  public static final int notification_action_tombstone = 2131427418;
  
  public static final int notification_template_custom_big = 2131427419;
  
  public static final int notification_template_icon_group = 2131427420;
  
  public static final int notification_template_part_chronometer = 2131427421;
  
  public static final int notification_template_part_time = 2131427422;
  
  public static final int select_dialog_item_material = 2131427427;
  
  public static final int select_dialog_multichoice_material = 2131427428;
  
  public static final int select_dialog_singlechoice_material = 2131427429;
  
  public static final int support_simple_spinner_dropdown_item = 2131427432;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\R$layout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */