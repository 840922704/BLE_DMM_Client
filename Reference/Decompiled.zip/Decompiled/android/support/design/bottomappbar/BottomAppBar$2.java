package android.support.design.bottomappbar;

import android.animation.ValueAnimator;

class null implements ValueAnimator.AnimatorUpdateListener {
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    BottomAppBar.access$100(BottomAppBar.this).setHorizontalOffset(((Float)paramValueAnimator.getAnimatedValue()).floatValue());
    BottomAppBar.access$200(BottomAppBar.this).invalidateSelf();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */