package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class null extends AnimatorListenerAdapter {
  public void onAnimationEnd(Animator paramAnimator) {
    BottomAppBar.access$302(BottomAppBar.this, null);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */