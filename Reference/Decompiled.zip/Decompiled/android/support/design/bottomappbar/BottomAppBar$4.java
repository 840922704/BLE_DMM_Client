package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.ActionMenuView;

class null extends AnimatorListenerAdapter {
  public boolean cancelled;
  
  public void onAnimationCancel(Animator paramAnimator) {
    this.cancelled = true;
  }
  
  public void onAnimationEnd(Animator paramAnimator) {
    if (!this.cancelled)
      BottomAppBar.access$400(BottomAppBar.this, actionMenuView, targetMode, targetAttached); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */