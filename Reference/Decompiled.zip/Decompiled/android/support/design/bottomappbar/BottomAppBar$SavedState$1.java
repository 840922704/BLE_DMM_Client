package android.support.design.bottomappbar;

import android.os.Parcel;
import android.os.Parcelable;

final class null implements Parcelable.ClassLoaderCreator<BottomAppBar.SavedState> {
  public BottomAppBar.SavedState createFromParcel(Parcel paramParcel) {
    return new BottomAppBar.SavedState(paramParcel, null);
  }
  
  public BottomAppBar.SavedState createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new BottomAppBar.SavedState(paramParcel, paramClassLoader);
  }
  
  public BottomAppBar.SavedState[] newArray(int paramInt) {
    return new BottomAppBar.SavedState[paramInt];
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */