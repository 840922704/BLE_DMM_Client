package android.support.design.bottomappbar;

import android.animation.ValueAnimator;

class null implements ValueAnimator.AnimatorUpdateListener {
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    BottomAppBar.access$200(BottomAppBar.this).setInterpolation(((Float)paramValueAnimator.getAnimatedValue()).floatValue());
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */