package android.support.design.bottomappbar;

import android.content.Context;
import android.graphics.Rect;
import android.support.design.animation.AnimationUtils;
import android.support.design.behavior.HideBottomViewOnScrollBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.util.AttributeSet;
import android.view.View;

public class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {
  private final Rect fabContentRect = new Rect();
  
  public Behavior() {}
  
  public Behavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private boolean updateFabPositionAndVisibility(FloatingActionButton paramFloatingActionButton, BottomAppBar paramBottomAppBar) {
    ((CoordinatorLayout.LayoutParams)paramFloatingActionButton.getLayoutParams()).anchorGravity = 17;
    BottomAppBar.access$1000(paramBottomAppBar, paramFloatingActionButton);
    return true;
  }
  
  public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, BottomAppBar paramBottomAppBar, int paramInt) {
    FloatingActionButton floatingActionButton = BottomAppBar.access$1100(paramBottomAppBar);
    if (floatingActionButton != null) {
      updateFabPositionAndVisibility(floatingActionButton, paramBottomAppBar);
      floatingActionButton.getMeasuredContentRect(this.fabContentRect);
      paramBottomAppBar.setFabDiameter(this.fabContentRect.height());
    } 
    if (!BottomAppBar.access$1200(paramBottomAppBar))
      BottomAppBar.access$1300(paramBottomAppBar); 
    paramCoordinatorLayout.onLayoutChild((View)paramBottomAppBar, paramInt);
    return super.onLayoutChild(paramCoordinatorLayout, (View)paramBottomAppBar, paramInt);
  }
  
  public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, BottomAppBar paramBottomAppBar, View paramView1, View paramView2, int paramInt1, int paramInt2) {
    boolean bool;
    if (paramBottomAppBar.getHideOnScroll() && super.onStartNestedScroll(paramCoordinatorLayout, (View)paramBottomAppBar, paramView1, paramView2, paramInt1, paramInt2)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected void slideDown(BottomAppBar paramBottomAppBar) {
    super.slideDown((View)paramBottomAppBar);
    FloatingActionButton floatingActionButton = BottomAppBar.access$1100(paramBottomAppBar);
    if (floatingActionButton != null) {
      floatingActionButton.getContentRect(this.fabContentRect);
      float f = (floatingActionButton.getMeasuredHeight() - this.fabContentRect.height());
      floatingActionButton.clearAnimation();
      floatingActionButton.animate().translationY(-floatingActionButton.getPaddingBottom() + f).setInterpolator(AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR).setDuration(175L);
    } 
  }
  
  protected void slideUp(BottomAppBar paramBottomAppBar) {
    super.slideUp((View)paramBottomAppBar);
    FloatingActionButton floatingActionButton = BottomAppBar.access$1100(paramBottomAppBar);
    if (floatingActionButton != null) {
      floatingActionButton.clearAnimation();
      floatingActionButton.animate().translationY(BottomAppBar.access$1400(paramBottomAppBar)).setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR).setDuration(225L);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */