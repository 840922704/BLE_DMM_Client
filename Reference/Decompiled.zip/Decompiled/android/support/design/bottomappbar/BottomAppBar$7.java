package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class null extends AnimatorListenerAdapter {
  public void onAnimationStart(Animator paramAnimator) {
    BottomAppBar bottomAppBar = BottomAppBar.this;
    BottomAppBar.access$700(bottomAppBar, BottomAppBar.access$600(bottomAppBar));
    bottomAppBar = BottomAppBar.this;
    BottomAppBar.access$900(bottomAppBar, BottomAppBar.access$800(bottomAppBar), BottomAppBar.access$600(BottomAppBar.this));
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */