package android.support.design.bottomappbar;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.AbsSavedState;

class SavedState extends AbsSavedState {
  public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
      public BottomAppBar.SavedState createFromParcel(Parcel param2Parcel) {
        return new BottomAppBar.SavedState(param2Parcel, null);
      }
      
      public BottomAppBar.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new BottomAppBar.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public BottomAppBar.SavedState[] newArray(int param2Int) {
        return new BottomAppBar.SavedState[param2Int];
      }
    };
  
  int fabAlignmentMode;
  
  boolean fabAttached;
  
  public SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    boolean bool;
    this.fabAlignmentMode = paramParcel.readInt();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.fabAttached = bool;
  }
  
  public SavedState(Parcelable paramParcelable) {
    super(paramParcelable);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.fabAlignmentMode);
    paramParcel.writeInt(this.fabAttached);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\bottomappbar\BottomAppBar$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */