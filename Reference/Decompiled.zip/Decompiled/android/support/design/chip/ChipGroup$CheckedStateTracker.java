package android.support.design.chip;

import android.widget.CompoundButton;

class CheckedStateTracker implements CompoundButton.OnCheckedChangeListener {
  private CheckedStateTracker() {}
  
  public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean) {
    if (ChipGroup.access$300(ChipGroup.this))
      return; 
    int i = paramCompoundButton.getId();
    if (paramBoolean) {
      if (ChipGroup.access$400(ChipGroup.this) != -1 && ChipGroup.access$400(ChipGroup.this) != i && ChipGroup.access$500(ChipGroup.this)) {
        ChipGroup chipGroup = ChipGroup.this;
        ChipGroup.access$600(chipGroup, ChipGroup.access$400(chipGroup), false);
      } 
      ChipGroup.access$700(ChipGroup.this, i);
    } else if (ChipGroup.access$400(ChipGroup.this) == i) {
      ChipGroup.access$700(ChipGroup.this, -1);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\ChipGroup$CheckedStateTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */