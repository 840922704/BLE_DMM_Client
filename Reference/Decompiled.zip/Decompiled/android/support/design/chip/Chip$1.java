package android.support.design.chip;

import android.graphics.Typeface;
import android.support.v4.content.res.ResourcesCompat;

class null extends ResourcesCompat.FontCallback {
  public void onFontRetrievalFailed(int paramInt) {}
  
  public void onFontRetrieved(Typeface paramTypeface) {
    Chip chip = Chip.this;
    chip.setText(chip.getText());
    Chip.this.requestLayout();
    Chip.this.invalidate();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\Chip$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */