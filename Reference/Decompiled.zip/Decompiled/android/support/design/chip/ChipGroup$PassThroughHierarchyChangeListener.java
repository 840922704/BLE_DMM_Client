package android.support.design.chip;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;

class PassThroughHierarchyChangeListener implements ViewGroup.OnHierarchyChangeListener {
  private ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener;
  
  private PassThroughHierarchyChangeListener() {}
  
  public void onChildViewAdded(View paramView1, View paramView2) {
    if (paramView1 == ChipGroup.this && paramView2 instanceof Chip) {
      if (paramView2.getId() == -1) {
        int i;
        if (Build.VERSION.SDK_INT >= 17) {
          i = View.generateViewId();
        } else {
          i = paramView2.hashCode();
        } 
        paramView2.setId(i);
      } 
      ((Chip)paramView2).setOnCheckedChangeListenerInternal(ChipGroup.access$800(ChipGroup.this));
    } 
    ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.onHierarchyChangeListener;
    if (onHierarchyChangeListener != null)
      onHierarchyChangeListener.onChildViewAdded(paramView1, paramView2); 
  }
  
  public void onChildViewRemoved(View paramView1, View paramView2) {
    if (paramView1 == ChipGroup.this && paramView2 instanceof Chip)
      ((Chip)paramView2).setOnCheckedChangeListenerInternal(null); 
    ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.onHierarchyChangeListener;
    if (onHierarchyChangeListener != null)
      onHierarchyChangeListener.onChildViewRemoved(paramView1, paramView2); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\ChipGroup$PassThroughHierarchyChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */