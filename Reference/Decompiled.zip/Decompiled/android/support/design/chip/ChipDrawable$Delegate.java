package android.support.design.chip;

public interface Delegate {
  void onChipDrawableSizeChange();
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\ChipDrawable$Delegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */