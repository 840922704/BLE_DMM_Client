package android.support.design.chip;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

class null extends ViewOutlineProvider {
  public void getOutline(View paramView, Outline paramOutline) {
    if (Chip.access$000(Chip.this) != null) {
      Chip.access$000(Chip.this).getOutline(paramOutline);
    } else {
      paramOutline.setAlpha(0.0F);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\Chip$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */