package android.support.design.chip;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.design.R;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.ExploreByTouchHelper;
import android.text.TextUtils;
import android.view.View;
import java.util.List;

class ChipTouchHelper extends ExploreByTouchHelper {
  ChipTouchHelper(Chip paramChip2) {
    super((View)paramChip2);
  }
  
  protected int getVirtualViewAt(float paramFloat1, float paramFloat2) {
    byte b;
    if (Chip.access$100(Chip.this) && Chip.access$200(Chip.this).contains(paramFloat1, paramFloat2)) {
      b = 0;
    } else {
      b = -1;
    } 
    return b;
  }
  
  protected void getVisibleVirtualViews(List<Integer> paramList) {
    if (Chip.access$100(Chip.this))
      paramList.add(Integer.valueOf(0)); 
  }
  
  protected boolean onPerformActionForVirtualView(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt2 == 16 && paramInt1 == 0) ? Chip.this.performCloseIconClick() : false;
  }
  
  protected void onPopulateNodeForHost(AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    boolean bool;
    if (Chip.access$000(Chip.this) != null && Chip.access$000(Chip.this).isCheckable()) {
      bool = true;
    } else {
      bool = false;
    } 
    paramAccessibilityNodeInfoCompat.setCheckable(bool);
    paramAccessibilityNodeInfoCompat.setClassName(Chip.class.getName());
    CharSequence charSequence = Chip.this.getText();
    if (Build.VERSION.SDK_INT >= 23) {
      paramAccessibilityNodeInfoCompat.setText(charSequence);
    } else {
      paramAccessibilityNodeInfoCompat.setContentDescription(charSequence);
    } 
  }
  
  protected void onPopulateNodeForVirtualView(int paramInt, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    if (Chip.access$100(Chip.this)) {
      CharSequence charSequence = Chip.this.getCloseIconContentDescription();
      if (charSequence != null) {
        paramAccessibilityNodeInfoCompat.setContentDescription(charSequence);
      } else {
        charSequence = Chip.this.getText();
        Context context = Chip.this.getContext();
        paramInt = R.string.mtrl_chip_close_icon_content_description;
        if (TextUtils.isEmpty(charSequence))
          charSequence = ""; 
        paramAccessibilityNodeInfoCompat.setContentDescription(context.getString(paramInt, new Object[] { charSequence }).trim());
      } 
      paramAccessibilityNodeInfoCompat.setBoundsInParent(Chip.access$300(Chip.this));
      paramAccessibilityNodeInfoCompat.addAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_CLICK);
      paramAccessibilityNodeInfoCompat.setEnabled(Chip.this.isEnabled());
    } else {
      paramAccessibilityNodeInfoCompat.setContentDescription("");
      paramAccessibilityNodeInfoCompat.setBoundsInParent(Chip.access$400());
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\design\chip\Chip$ChipTouchHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */