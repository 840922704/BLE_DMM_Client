package android.support.asynclayoutinflater;

public final class id {
  public static final int action_container = 2131230744;
  
  public static final int action_divider = 2131230746;
  
  public static final int action_image = 2131230747;
  
  public static final int action_text = 2131230753;
  
  public static final int actions = 2131230754;
  
  public static final int async = 2131230766;
  
  public static final int blocking = 2131230771;
  
  public static final int chronometer = 2131230796;
  
  public static final int forever = 2131230866;
  
  public static final int icon = 2131230881;
  
  public static final int icon_group = 2131230882;
  
  public static final int info = 2131230887;
  
  public static final int italic = 2131230889;
  
  public static final int line1 = 2131230899;
  
  public static final int line3 = 2131230900;
  
  public static final int normal = 2131230941;
  
  public static final int notification_background = 2131230947;
  
  public static final int notification_main_column = 2131230948;
  
  public static final int notification_main_column_container = 2131230949;
  
  public static final int right_icon = 2131230997;
  
  public static final int right_side = 2131230998;
  
  public static final int tag_transition_group = 2131231070;
  
  public static final int tag_unhandled_key_event_manager = 2131231071;
  
  public static final int tag_unhandled_key_listeners = 2131231072;
  
  public static final int text = 2131231075;
  
  public static final int text2 = 2131231076;
  
  public static final int time = 2131231086;
  
  public static final int title = 2131231088;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\asynclayoutinflater\R$id.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */