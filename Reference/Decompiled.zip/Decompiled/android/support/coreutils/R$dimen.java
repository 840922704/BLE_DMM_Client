package android.support.coreutils;

public final class dimen {
  public static final int compat_button_inset_horizontal_material = 2131101059;
  
  public static final int compat_button_inset_vertical_material = 2131101060;
  
  public static final int compat_button_padding_horizontal_material = 2131101061;
  
  public static final int compat_button_padding_vertical_material = 2131101062;
  
  public static final int compat_control_corner_material = 2131101063;
  
  public static final int compat_notification_large_icon_max_height = 2131101064;
  
  public static final int compat_notification_large_icon_max_width = 2131101065;
  
  public static final int notification_action_icon_size = 2131101177;
  
  public static final int notification_action_text_size = 2131101178;
  
  public static final int notification_big_circle_margin = 2131101179;
  
  public static final int notification_content_margin_start = 2131101180;
  
  public static final int notification_large_icon_height = 2131101181;
  
  public static final int notification_large_icon_width = 2131101182;
  
  public static final int notification_main_column_padding_top = 2131101183;
  
  public static final int notification_media_narrow_margin = 2131101184;
  
  public static final int notification_right_icon_size = 2131101185;
  
  public static final int notification_right_side_padding_top = 2131101186;
  
  public static final int notification_small_icon_background_padding = 2131101187;
  
  public static final int notification_small_icon_size_as_large = 2131101188;
  
  public static final int notification_subtext_size = 2131101189;
  
  public static final int notification_top_pad = 2131101190;
  
  public static final int notification_top_pad_large_text = 2131101191;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreutils\R$dimen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */