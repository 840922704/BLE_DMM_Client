package android.support.coreutils;

public final class drawable {
  public static final int notification_action_background = 2131165432;
  
  public static final int notification_bg = 2131165433;
  
  public static final int notification_bg_low = 2131165434;
  
  public static final int notification_bg_low_normal = 2131165435;
  
  public static final int notification_bg_low_pressed = 2131165436;
  
  public static final int notification_bg_normal = 2131165437;
  
  public static final int notification_bg_normal_pressed = 2131165438;
  
  public static final int notification_icon_background = 2131165439;
  
  public static final int notification_template_icon_bg = 2131165440;
  
  public static final int notification_template_icon_low_bg = 2131165441;
  
  public static final int notification_tile_bg = 2131165442;
  
  public static final int notify_panel_notification_icon_bg = 2131165443;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreutils\R$drawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */