package android.support.coreutils;

public final class styleable {
  public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130903079 };
  
  public static final int ColorStateListItem_alpha = 2;
  
  public static final int ColorStateListItem_android_alpha = 1;
  
  public static final int ColorStateListItem_android_color = 0;
  
  public static final int[] FontFamily = new int[] { 2130903265, 2130903266, 2130903267, 2130903268, 2130903269, 2130903270 };
  
  public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903263, 2130903271, 2130903272, 2130903273, 2130903645 };
  
  public static final int FontFamilyFont_android_font = 0;
  
  public static final int FontFamilyFont_android_fontStyle = 2;
  
  public static final int FontFamilyFont_android_fontVariationSettings = 4;
  
  public static final int FontFamilyFont_android_fontWeight = 1;
  
  public static final int FontFamilyFont_android_ttcIndex = 3;
  
  public static final int FontFamilyFont_font = 5;
  
  public static final int FontFamilyFont_fontStyle = 6;
  
  public static final int FontFamilyFont_fontVariationSettings = 7;
  
  public static final int FontFamilyFont_fontWeight = 8;
  
  public static final int FontFamilyFont_ttcIndex = 9;
  
  public static final int FontFamily_fontProviderAuthority = 0;
  
  public static final int FontFamily_fontProviderCerts = 1;
  
  public static final int FontFamily_fontProviderFetchStrategy = 2;
  
  public static final int FontFamily_fontProviderFetchTimeout = 3;
  
  public static final int FontFamily_fontProviderPackage = 4;
  
  public static final int FontFamily_fontProviderQuery = 5;
  
  public static final int[] GradientColor = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
  
  public static final int GradientColorItem_android_color = 0;
  
  public static final int GradientColorItem_android_offset = 1;
  
  public static final int GradientColor_android_centerColor = 7;
  
  public static final int GradientColor_android_centerX = 3;
  
  public static final int GradientColor_android_centerY = 4;
  
  public static final int GradientColor_android_endColor = 1;
  
  public static final int GradientColor_android_endX = 10;
  
  public static final int GradientColor_android_endY = 11;
  
  public static final int GradientColor_android_gradientRadius = 5;
  
  public static final int GradientColor_android_startColor = 0;
  
  public static final int GradientColor_android_startX = 8;
  
  public static final int GradientColor_android_startY = 9;
  
  public static final int GradientColor_android_tileMode = 6;
  
  public static final int GradientColor_android_type = 2;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreutils\R$styleable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */