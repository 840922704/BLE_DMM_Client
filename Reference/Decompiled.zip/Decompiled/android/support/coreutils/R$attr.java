package android.support.coreutils;

public final class attr {
  public static final int alpha = 2130903079;
  
  public static final int font = 2130903263;
  
  public static final int fontProviderAuthority = 2130903265;
  
  public static final int fontProviderCerts = 2130903266;
  
  public static final int fontProviderFetchStrategy = 2130903267;
  
  public static final int fontProviderFetchTimeout = 2130903268;
  
  public static final int fontProviderPackage = 2130903269;
  
  public static final int fontProviderQuery = 2130903270;
  
  public static final int fontStyle = 2130903271;
  
  public static final int fontVariationSettings = 2130903272;
  
  public static final int fontWeight = 2130903273;
  
  public static final int ttcIndex = 2130903645;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\coreutils\R$attr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */