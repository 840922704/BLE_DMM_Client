package android.support.customview;

public final class layout {
  public static final int notification_action = 2131427417;
  
  public static final int notification_action_tombstone = 2131427418;
  
  public static final int notification_template_custom_big = 2131427419;
  
  public static final int notification_template_icon_group = 2131427420;
  
  public static final int notification_template_part_chronometer = 2131427421;
  
  public static final int notification_template_part_time = 2131427422;
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\support\customview\R$layout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */