package android.arch.lifecycle;

public interface Factory {
  <T extends ViewModel> T create(Class<T> paramClass);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\ViewModelProvider$Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */