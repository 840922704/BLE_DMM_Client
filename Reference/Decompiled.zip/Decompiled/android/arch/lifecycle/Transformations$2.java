package android.arch.lifecycle;

import android.arch.core.util.Function;

final class null implements Observer<X> {
  LiveData<Y> mSource;
  
  public void onChanged(X paramX) {
    LiveData<Y> liveData1 = (LiveData)func.apply(paramX);
    LiveData<Y> liveData2 = this.mSource;
    if (liveData2 == liveData1)
      return; 
    if (liveData2 != null)
      result.removeSource(liveData2); 
    this.mSource = liveData1;
    liveData1 = this.mSource;
    if (liveData1 != null)
      result.addSource(liveData1, new Observer() {
            public void onChanged(Y param2Y) {
              result.setValue(param2Y);
            }
          }); 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\Transformations$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */