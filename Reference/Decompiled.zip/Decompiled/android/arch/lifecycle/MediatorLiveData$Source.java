package android.arch.lifecycle;

class Source<V> implements Observer<V> {
  final LiveData<V> mLiveData;
  
  final Observer<V> mObserver;
  
  int mVersion = -1;
  
  Source(LiveData<V> paramLiveData, Observer<V> paramObserver) {
    this.mLiveData = paramLiveData;
    this.mObserver = paramObserver;
  }
  
  public void onChanged(V paramV) {
    if (this.mVersion != this.mLiveData.getVersion()) {
      this.mVersion = this.mLiveData.getVersion();
      this.mObserver.onChanged(paramV);
    } 
  }
  
  void plug() {
    this.mLiveData.observeForever(this);
  }
  
  void unplug() {
    this.mLiveData.removeObserver(this);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\MediatorLiveData$Source.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */