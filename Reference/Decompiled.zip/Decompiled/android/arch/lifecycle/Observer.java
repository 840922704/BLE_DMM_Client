package android.arch.lifecycle;

public interface Observer<T> {
  void onChanged(T paramT);
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\Observer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */