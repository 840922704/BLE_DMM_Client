package android.arch.lifecycle;

class AlwaysActiveObserver extends LiveData<T>.ObserverWrapper {
  AlwaysActiveObserver(Observer<T> paramObserver) {
    super(paramObserver);
  }
  
  boolean shouldBeActive() {
    return true;
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\LiveData$AlwaysActiveObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */