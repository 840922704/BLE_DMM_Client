package android.arch.lifecycle;

abstract class ObserverWrapper {
  boolean mActive;
  
  int mLastVersion = -1;
  
  final Observer<T> mObserver;
  
  ObserverWrapper(Observer<T> paramObserver) {
    this.mObserver = paramObserver;
  }
  
  void activeStateChanged(boolean paramBoolean) {
    if (paramBoolean == this.mActive)
      return; 
    this.mActive = paramBoolean;
    int i = LiveData.access$300(LiveData.this);
    byte b = 1;
    if (i == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    LiveData liveData = LiveData.this;
    int j = LiveData.access$300(liveData);
    if (!this.mActive)
      b = -1; 
    LiveData.access$302(liveData, j + b);
    if (i != 0 && this.mActive)
      LiveData.this.onActive(); 
    if (LiveData.access$300(LiveData.this) == 0 && !this.mActive)
      LiveData.this.onInactive(); 
    if (this.mActive)
      LiveData.access$400(LiveData.this, this); 
  }
  
  void detachObserver() {}
  
  boolean isAttachedTo(LifecycleOwner paramLifecycleOwner) {
    return false;
  }
  
  abstract boolean shouldBeActive();
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\LiveData$ObserverWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */