package android.arch.lifecycle;

public class NewInstanceFactory implements ViewModelProvider.Factory {
  public <T extends ViewModel> T create(Class<T> paramClass) {
    try {
      return paramClass.newInstance();
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot create an instance of ");
      stringBuilder.append(paramClass);
      throw new RuntimeException(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot create an instance of ");
      stringBuilder.append(paramClass);
      throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\ViewModelProvider$NewInstanceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */