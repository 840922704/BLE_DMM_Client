package android.arch.lifecycle;

class null implements Runnable {
  public void run() {
    synchronized (LiveData.access$000(LiveData.this)) {
      Object object = LiveData.access$100(LiveData.this);
      LiveData.access$102(LiveData.this, LiveData.access$200());
      LiveData.this.setValue(object);
      return;
    } 
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\LiveData$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */