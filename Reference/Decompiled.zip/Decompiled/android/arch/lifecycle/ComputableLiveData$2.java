package android.arch.lifecycle;

class null implements Runnable {
  public void run() {
    boolean bool;
    do {
      if (ComputableLiveData.access$100(ComputableLiveData.this).compareAndSet(false, true)) {
        null = null;
        bool = false;
        try {
          while (ComputableLiveData.access$200(ComputableLiveData.this).compareAndSet(true, false)) {
            null = (Exception)ComputableLiveData.this.compute();
            bool = true;
          } 
          if (bool)
            ComputableLiveData.access$300(ComputableLiveData.this).postValue(null); 
        } finally {
          ComputableLiveData.access$100(ComputableLiveData.this).set(false);
        } 
      } else {
        bool = false;
      } 
    } while (bool && ComputableLiveData.access$200(ComputableLiveData.this).get());
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\ComputableLiveData$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */