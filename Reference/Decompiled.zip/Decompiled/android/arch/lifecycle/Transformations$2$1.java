package android.arch.lifecycle;

class null implements Observer<Y> {
  public void onChanged(Y paramY) {
    result.setValue(paramY);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\lifecycle\Transformations$2$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */