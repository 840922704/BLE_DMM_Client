package android.arch.core.executor;

import java.util.concurrent.Executor;

final class null implements Executor {
  public void execute(Runnable paramRunnable) {
    ArchTaskExecutor.getInstance().postToMainThread(paramRunnable);
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\core\executor\ArchTaskExecutor$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */