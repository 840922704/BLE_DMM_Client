package android.arch.core.internal;

import java.util.Map;

class Entry<K, V> implements Map.Entry<K, V> {
  final K mKey;
  
  Entry<K, V> mNext;
  
  Entry<K, V> mPrevious;
  
  final V mValue;
  
  Entry(K paramK, V paramV) {
    this.mKey = paramK;
    this.mValue = paramV;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof Entry))
      return false; 
    paramObject = paramObject;
    if (!this.mKey.equals(((Entry)paramObject).mKey) || !this.mValue.equals(((Entry)paramObject).mValue))
      bool = false; 
    return bool;
  }
  
  public K getKey() {
    return this.mKey;
  }
  
  public V getValue() {
    return this.mValue;
  }
  
  public V setValue(V paramV) {
    throw new UnsupportedOperationException("An entry modification is not supported");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mKey);
    stringBuilder.append("=");
    stringBuilder.append(this.mValue);
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\xy790\Desktop\decode\dex-tools-2.1\output\!\android\arch\core\internal\SafeIterableMap$Entry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */